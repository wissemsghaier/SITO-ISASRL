* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_krx                                                        *
*              IMPORTAZIONE FATTURA ELETTRONICA                                *
*                                                                              *
*      Author: DIP                                                             *
*      Client: FatturaPA                                                       *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2012-09-13                                                      *
* Last revis.: 2015-09-25                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
private i_secdef
i_secdef = ""
do cplu_stb with "gopa_krx"
* --- Controllo di permesso di accesso alla procedura
w_s = 1
do cplu_sec with 50,"",w_s
if .not. w_s
  return
endif
* ----------------------------------------
* variabile pubblica che conterra' lo stato del programma
* in modo che possa riprendere da dove si era interrotto
public array s_gopa_krx[10]

private i_op
#define OP_QUERY     1
#define OP_LOAD      2
#define OP_EDITMOD   3
#define OP_EDITLOAD  4
#define OP_ZOOM      5
#define OP_QUIT      6
#define OP_INTR      7
i_op = OP_QUERY

* --- Variabili locali
i_3d = iif(type("i_3d")="U",.t.,i_3d)
private i_shx,i_shsz
store 0 to i_shx,i_shsz
private i_loaded,w_s,i_campo,i_campoq,i_docreco, i_campg, i_accpt, i_zoomrec
private i_rdvars,i_rdkvars,i_rdkey, i_zoompars, i_zbrow, i_paint, i_oldarea
private i_pag,i_button,i_function,i_oldop,i_zoomprg, i_openfail, i_help, i_twind
private i_posyx1, i_size1, i_font1, i_style1
dimension i_posyx1[8,2], i_size1[8,2], i_font1[8,2], i_style1[8]
dimension i_campg[1]
dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 1 to i_pag, i_button, i_campoq
i_campo  = i_nbtntbar+1
store .f. to i_loaded, i_zbrow, i_paint, i_accpt, i_openfail
store 0 to i_oldop, i_docreco
store " " to i_function, w_s, i_zoomprg, i_rdkey, i_help
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
i_campg[1] = 4
private wnd_gopa_krx
wnd_gopa_krx = ' '

***
* Descrizione analisi IMPORTAZIONE FATTURA ELETTRONICA
***

private i_fngopa_krx


private w_FILEXML,w_FILEMET
store " " to w_FILEXML,w_FILEMET
private o_FILEXML
store " " to o_FILEXML


i_oldarea = select()
if .not. wexist("gopa_krx")
  * --- se non esiste la finestra prova
  *     allora il programma non e' gia' attivo
  if .not. OpenProc()
    return
  endif
  * --- Event = Program Start
  * --- End Event
  i_op = OP_QUERY
  * --- Area Manuale = Init
  * --- Fine Area Manuale
  do F_Blank
  do Ass_pos
  do F_Paint with 0
else
  private i_ay
  i_ay = 0
  if _windows
    activate window "gopa_krx" noshow same
    modify window "gopa_krx" at wlrow(),wlcol() ;
      size at_y(154,"Arial",9,"")+i_ay,at_x(576,"Arial",9,"")
  else
    if _mac
      activate window "gopa_krx" noshow same
      modify window "gopa_krx" at wlrow(),wlcol() ;
        size at_y(154,"Arial",9*4/3,"")+i_ay,at_x(576,"Arial",9*4/3,"")
    endif
  endif
  do RestoreStatus
endif
do while i_op<>OP_QUIT .and. i_op<>OP_INTR
  do case
    case i_op=OP_QUERY .or. i_op=OP_EDITMOD
      i_op = OP_EDITMOD
      do F_Edit
    case i_op=OP_ZOOM
      &i_zoomprg
      do RestoreFilters
      i_op = iif(.not. empty(i_todo),OP_INTR,i_oldop)
  endcase
enddo
if i_op=OP_QUIT
  * --- Area Manuale = End
  * --- Fine Area Manuale
  * --- Event = Program End
  * --- End Event
  do CloseProc
else
  do SaveStatus
endif
i_warea = alltrim(str(i_oldarea))
select (i_oldarea)
return

* === OpenProc
*     definisce la finestra, blank alle variabili di lavoro
procedure OpenProc
  private i_ok,i_ay,i_pv,i_wnd
  i_ok = OpenFiles()
  i_ay = 0
  i_wnd = iif(empty(wontop()) or wontop()="BUTTONS","","in window ('"+wontop()+"')")
  if i_ok
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
    i_twind = "system name wnd_gopa_krx"
    i_pv=at_y(18)
    #else
    i_twind = "close grow"
    i_pv=iif(i_vtoolbar,at_y(18),max(at_y(18),2.8))
    #endif
    * ---
    do case
      case _windows
        define window "gopa_krx" at i_pv,at_x(11) size at_y(154,"Arial",9,"")+i_ay,at_x(576,"Arial",9,"");
          font "Arial",9;
          title "IMPORTAZIONE FATTURA ELETTRONICA";
          minimize float &i_twind icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

        modify window "gopa_krx" at i_pv,at_x(11) size at_y(154,"Arial",9,"")+i_ay,at_x(576,"Arial",9,"")
      case _mac
        i_pv=iif(i_vtoolbar,at_y(18),max(at_y(18),2.8))
        define window "gopa_krx" at i_pv,at_x(11) size at_y(154,"Arial",9*4/3,"")+i_ay,at_x(576,"Arial",9*4/3,"");
          font "Arial",9*4/3;
          title "IMPORTAZIONE FATTURA ELETTRONICA";
          minimize float close grow icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

      otherwise
        define window "gopa_krx" from 1,1 to 24,80;
          title "  IMPORTAZIONE FATTURA ELETTRONICA  ";
          minimize float close  "�","�","�","�","�","�","�","�";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

    endcase
set topic to 'IMPORTAZIONE FATTURA ELETTRONICA (programma)'
  endif
  return i_ok

* === OpenFiles
function OpenFiles
  private i_ok
  i_ok = .t.
  * --- Apertura dei files
set exclusive off
  return i_ok

* === CloseProc
procedure CloseProc
  release window "gopa_krx"
  do CloseFiles
  * --- Fp3
  #if left(version(),13)="Visual FoxPro"
    oCpToolBar.Enable(.f.)
  #endif
  * ---
  return

* === CloseFiles
procedure CloseFiles
  return

procedure RestoreStatus
  private i_zop
  i_docreco = s_gopa_krx[1]
  i_oldop   = s_gopa_krx[2]
  i_zoomprg = s_gopa_krx[3]
  i_campo   = s_gopa_krx[4]
  i_campoq  = s_gopa_krx[5]
  i_pag     = s_gopa_krx[6]
  i_loaded  = s_gopa_krx[7]
  i_zbrow   = s_gopa_krx[8]
  i_zop     = substr(i_zoomprg,4,len(i_zoomprg)-3)
  i_op      = iif(.not. empty(i_zoomprg) .and. (wvisible(i_zop) .or. .not. i_zbrow),OP_ZOOM,i_oldop)
  w_FILEXML = s_gopa_krx[9]
  w_FILEMET = s_gopa_krx[10]
  o_FILEXML = w_FILEXML
  do RestoreFilters
  do Ass_pos
  return

procedure RestoreFilters
  do Set_Radio
set topic to 'IMPORTAZIONE FATTURA ELETTRONICA (programma)'
  return

procedure SaveStatus
  s_gopa_krx[1] = i_docreco
  s_gopa_krx[2] = i_oldop
  s_gopa_krx[3] = i_zoomprg
  s_gopa_krx[4] = i_campo
  s_gopa_krx[5] = i_campoq
  s_gopa_krx[6] = i_pag
  s_gopa_krx[7] = i_loaded
  s_gopa_krx[8] = i_zbrow
  s_gopa_krx[9] = w_FILEXML
  s_gopa_krx[10] = w_FILEMET
  return

* === Ass_Pos
procedure Ass_Pos
  private i_wx, i_wy, i_ay
  activate window "gopa_krx" noshow same
  i_wx = fontmetric(6)
  i_wy = fontmetric(1)
  i_ay = 0
  do case
    case _windows
      do Ass_Pos_Win
    case _mac
      do Ass_Pos_Mac
    otherwise
      do Ass_Pos_Unkn
  endcase
  return

procedure Ass_Pos_Win
      i_posyx1[1,1] = i_ay+(31/i_wy) && at_y(31)
      i_posyx1[1,2] = 8/i_wx && at_x(8)
      i_size1[1,1] = cp_intsz(at_y(17))
      i_size1[1,2] = cp_intsz(510/i_wx)
      i_posyx1[2,1] = i_ay+(20/i_wy) && at_y(20)
      i_posyx1[2,2] = 525/i_wx && at_x(525)
      i_size1[2,1] = at_y(41)
      i_size1[2,2] = cp_intsz(47/i_wx)
      i_posyx1[3,1] = i_ay+(113/i_wy) && at_y(113)
      i_posyx1[3,2] = 465/i_wx && at_x(465)
      i_size1[3,1] = at_y(31)
      i_size1[3,2] = cp_intsz(53/i_wx)
      i_posyx1[4,1] = i_ay+(113/i_wy) && at_y(113)
      i_posyx1[4,2] = 519/i_wx && at_x(519)
      i_size1[4,1] = at_y(31)
      i_size1[4,2] = cp_intsz(53/i_wx)
      i_posyx1[5,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[5,2] = 7/i_wx && at_x(7)
      i_posyx1[6,1] = i_ay+(78/i_wy) && at_y(78)
      i_posyx1[6,2] = 8/i_wx && at_x(8)
      i_size1[6,1] = cp_intsz(at_y(17))
      i_size1[6,2] = cp_intsz(510/i_wx)
      i_posyx1[7,1] = i_ay+(67/i_wy) && at_y(67)
      i_posyx1[7,2] = 525/i_wx && at_x(525)
      i_size1[7,1] = at_y(41)
      i_size1[7,2] = cp_intsz(47/i_wx)
      i_posyx1[8,1] = i_ay+(61/i_wy) && at_y(61)
      i_posyx1[8,2] = 7/i_wx && at_x(7)
  return
procedure Ass_Pos_Mac
      i_posyx1[1,1] = i_ay+at_y(31)
      i_posyx1[1,2] = at_x(8)
      i_size1[1,1] = cp_intsz(at_y(17))
      i_size1[1,2] = cp_intsz(at_x(510))
      i_posyx1[2,1] = i_ay+at_y(20)
      i_posyx1[2,2] = at_x(525)
      i_size1[2,1] = at_y(41)
      i_size1[2,2] = cp_intsz(at_x(47))
      i_posyx1[3,1] = i_ay+at_y(113)
      i_posyx1[3,2] = at_x(465)
      i_size1[3,1] = at_y(31)
      i_size1[3,2] = cp_intsz(at_x(53))
      i_posyx1[4,1] = i_ay+at_y(113)
      i_posyx1[4,2] = at_x(519)
      i_size1[4,1] = at_y(31)
      i_size1[4,2] = cp_intsz(at_x(53))
      i_posyx1[5,1] = i_ay+at_y(14)
      i_posyx1[5,2] = at_x(7)
      i_posyx1[6,1] = i_ay+at_y(78)
      i_posyx1[6,2] = at_x(8)
      i_size1[6,1] = cp_intsz(at_y(17))
      i_size1[6,2] = cp_intsz(at_x(510))
      i_posyx1[7,1] = i_ay+at_y(67)
      i_posyx1[7,2] = at_x(525)
      i_size1[7,1] = at_y(41)
      i_size1[7,2] = cp_intsz(at_x(47))
      i_posyx1[8,1] = i_ay+at_y(61)
      i_posyx1[8,2] = at_x(7)
  return
procedure Ass_Pos_Unkn
      i_posyx1[1,1] = -2
      i_posyx1[1,2] = -2
      i_size1[1,1]  = 1
      i_size1[1,2]  = 1
      i_posyx1[2,1] = -2
      i_posyx1[2,2] = -2
      i_size1[2,1]  = 1
      i_size1[2,2]  = 9
      i_posyx1[3,1] = -2
      i_posyx1[3,2] = -2
      i_size1[3,1]  = 1
      i_size1[3,2]  = 6
      i_posyx1[4,1] = -2
      i_posyx1[4,2] = -2
      i_size1[4,1]  = 1
      i_size1[4,2]  = 8
      i_posyx1[5,1] = -2
      i_posyx1[5,2] = -2
      i_posyx1[6,1] = -2
      i_posyx1[6,2] = -2
      i_size1[6,1]  = 1
      i_size1[6,2]  = 1
      i_posyx1[7,1] = -2
      i_posyx1[7,2] = -2
      i_size1[7,1]  = 1
      i_size1[7,2]  = 9
      i_posyx1[8,1] = -2
      i_posyx1[8,2] = -2
return

function cp_intsz
  param i_sz
  return(iif(i_sz>=5,int(i_sz),i_sz))

* === F_Paint
procedure F_Paint
  parameters i_tutto
  private i_ay
  i_ay = 0
  activate window "gopa_krx" noshow same
  * --- Area Manuale = Paint Init
  * --- Fine Area Manuale
  if i_tutto=0
    clear
  endif
  do case
    case i_pag=1
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx1(5,1),i_posyx1(5,2) say "Selezione Fattura PA";

        @ i_posyx1(8,1),i_posyx1(8,2) say "Selezione file Metadati .xml (per creazione messaggio di esito committente)";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx1(1,1),i_posyx1(1,2),i_size1[1,1],i_size1[1,2]
           do cplu_3d with i_posyx1(6,1),i_posyx1(6,2),i_size1[6,1],i_size1[6,2]
         endif
       else
       endif
        if i_vidgrf
        @ i_posyx1(2,1),i_posyx1(2,2) get i_button picture '@*B BMP\FOLDER.BMP';
          size i_size1[2,1],i_size1[2,2] disable;

        else
        @ i_posyx1(2,1),i_posyx1(2,2) get i_button picture '@* . . .';
          size i_size1[2,1],i_size1[2,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(3,1),i_posyx1(3,2) get i_button picture '@*B T_OK.BMP';
          size i_size1[3,1],i_size1[3,2] disable;

        else
        @ i_posyx1(3,1),i_posyx1(3,2) get i_button picture '@* Ok';
          size i_size1[3,1],i_size1[3,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(4,1),i_posyx1(4,2) get i_button picture '@*B BMP\T_CANCEL.BMP';
          size i_size1[4,1],i_size1[4,2] disable;

        else
        @ i_posyx1(4,1),i_posyx1(4,2) get i_button picture '@* Esci';
          size i_size1[4,1],i_size1[4,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(7,1),i_posyx1(7,2) get i_button picture '@*B BMP\FOLDER.BMP';
          size i_size1[7,1],i_size1[7,2] disable;

        else
        @ i_posyx1(7,1),i_posyx1(7,2) get i_button picture '@* . . .';
          size i_size1[7,1],i_size1[7,2] disable;

        endif
        clear gets
      endif
      @ i_posyx1(1,1),i_posyx1(1,2) edit w_FILEXML;
        size i_size1[1,1],i_size1[1,2] disable ;
        color (w_t_col004)
      @ i_posyx1(6,1),i_posyx1(6,2) edit w_FILEMET;
        size i_size1[6,1],i_size1[6,2] disable ;
        color (w_t_col004)
      clear gets
  endcase
  activate window "gopa_krx" same
  * --- Area Manuale = Paint End
  * --- Fine Area Manuale
  return

* === F_Replace
function F_Replace
  * --- Area Manuale = Func Replace Init
  * --- Fine Area Manuale
  * --- Area Manuale = Func Replace End
  * --- Fine Area Manuale
  return

* === F_Blank
function F_Blank
  * --- Area Manuale = Func Blank Init
  * --- Fine Area Manuale
  w_FILEXML = space(0)
  w_FILEMET = space(0)
  w_FILEMET = iif(upper(right(w_FILEXML,8)) = '.XML.P7M', left(w_FILEXML,len(w_FILEXML)-8),left(w_FILEXML,len(w_FILEXML)-4)  ) + '_MT_001.xml'
  * --- Area Manuale = Func Blank End
  * --- Fine Area Manuale
  do Set_Radio
  return

function F_Edit
  private i_esci, i_upda
  i_upda = .f.
  i_help = "gopa_krx edit"
  if i_vidgrf
    if i_op=OP_EDITMOD
      modify window "gopa_krx" title "IMPORTAZIONE FATTURA ELETTRONICA / Varia"
    endif
  endif
  * --- Area Manuale = Func Edit Init
  * --- Fine Area Manuale
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
  do while i_op=OP_EDITMOD .or. i_op=OP_EDITLOAD
    i_function = ""
    i_zoomprg  = ""
    if i_zbrow
      i_function = "Zoom"
    else
      activate window "gopa_krx"
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with i_op, .f.
      #endif
      * ---
      do case
        case i_pag=1
      @ i_posyx1[1,1],i_posyx1[1,2] edit w_FILEXML;
        size i_size1[1,1],i_size1[1,2] ;
       color (w_t_col004);
     disable
            @ i_posyx1[2,1],i_posyx1[2,2] get i_button picture iif(i_vidgrf,'@*B BMP\FOLDER.BMP','@* . . .');
              size i_size1[2,1],i_size1[2,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

            @ i_posyx1[3,1],i_posyx1[3,2] get i_button picture iif(i_vidgrf,'@*B T_OK.BMP','@* Ok');
              size i_size1[3,1],i_size1[3,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Save");

            @ i_posyx1[4,1],i_posyx1[4,2] get i_button picture iif(i_vidgrf,'@*B BMP\T_CANCEL.BMP','@* Esci');
              size i_size1[4,1],i_size1[4,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Quit");

      @ i_posyx1[6,1],i_posyx1[6,2] edit w_FILEMET;
        size i_size1[6,1],i_size1[6,2] ;
       color (w_t_col004);
     disable
            @ i_posyx1[7,1],i_posyx1[7,2] get i_button picture iif(i_vidgrf,'@*B BMP\FOLDER.BMP','@* . . .');
              size i_size1[7,1],i_size1[7,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      endcase
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gopa_krx")
      * --- Area Manuale = Func Edit Chkread2
      * --- Fine Area Manuale
    endif
    do case
      * --- Area Manuale = Func Edit Funckeys
      * --- Fine Area Manuale
      case .not. empty(i_todo)
        i_oldop = i_op
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Save"
        i_esci = .f.
        do case
          * --- Area Manuale = Func Edit Confirm
          * --- Fine Area Manuale
          * --- Controllo dei campi obbligatori nelle righe del corpo
          case F_ChkAutoLock()
            i_esci = .t.
            * --- Area Manuale = Func Edit Save
            * --- Fine Area Manuale
        endcase
        if i_esci
          do F_Replace
          * --- Event = Mask Confirmed
          * --- End Event
          * --- Area Manuale = Print Init
          * --- Fine Area Manuale
  do GOPA_BRX
          * --- Area Manuale = Print End
          * --- gopa_krx
          loop
          * --- Fine Area Manuale
  i_op = OP_QUIT
else
  do F_Paint with 0
endif
      case i_function="Prior" .or. i_function="Next"
      case i_function="Delete"
      case i_function="Zoom"
        i_oldop = i_op
        i_op = OP_ZOOM
        do case
          case i_pag=1
            do case
              case i_campo=2+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do SALVA'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=6+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do SALVAE'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
            endcase
        endcase
        if .not. i_zbrow
          do F_Calc with .t.
          i_op = i_oldop
        endif
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
i_op = OP_QUIT
        * --- Event = Mask Rejected
        * --- End Event
    endcase
  enddo
  * --- Area Manuale = Func Edit End
  * --- Fine Area Manuale
  return

function F_dep
  parameter i_skip,i_zoom
  if _curobj>i_nbtntbar
    i_campo = _curobj
  endif
  i_accpt = .t.
  o_FILEXML = w_FILEXML
  if .not. chrsaw()
    * --- FP3
    #if .not. (left(version(),13)="Visual FoxPro")
      show object 4 disable
      if i_skip
        show object 6 enable
        show object 7 enable
      else
        show object 6 disable
        show object 7 disable
      endif
      if i_zoom
        show object 8 enable
      else
        show object 8 disable
      endif
      if i_pag<>1
        show object 9 enable
      else
        show object 9 disable
      endif
      if i_pag<>1
        show object 10 enable
      else
        show object 10 disable
      endif
    #else
      * --- Parte per FoxPro3
      if i_skip
        oCPToolBar.b7.enabled = .t.
        oCPToolBar.b8.enabled = .t.
      else
        oCPToolBar.b7.enabled = .f.
        oCPToolBar.b8.enabled = .f.
      endif
      if i_zoom
        oCPToolBar.b9.enabled = .t.
      else
        oCPToolBar.b9.enabled = .f.
      endif
    #endif
    * ---
  endif
  * --- Area Manuale = Function Dep
  * --- Fine Area Manuale
  return .t.

function F_calc
  parameter i_upd
  * --- Area Manuale = Func Edit Calc Alws
  * --- Fine Area Manuale
  if updated() .or. i_upd .or. i_upda
    * --- Area Manuale = Func Edit Calc
    * --- Fine Area Manuale
    if o_FILEXML<>w_FILEXML
      w_FILEMET = iif(upper(right(w_FILEXML,8)) = '.XML.P7M', left(w_FILEXML,len(w_FILEXML)-8),left(w_FILEXML,len(w_FILEXML)-4)  ) + '_MT_001.xml'
    endif
    do Set_Radio
    show gets
  endif
  i_upda = .f.
  return .t.

function Set_Radio
  return .t.

function Get_Radio
  return .t.

function at_x
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(6)
  else
    i_pos = i_pos / fontmetric(6,i_fnt,i_h,i_s)
  endif
  return i_pos

function at_y
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(1)
  else
    i_pos = i_pos / fontmetric(1,i_fnt,i_h,i_s)
  endif
  return i_pos

function F_Check
  parameter i_chk, i_obbl, i_var, i_value, i_msg
  i_accpt = i_chk .and. (.not. i_obbl .or. &i_var<>i_value)
  if .not. i_accpt
    if wontop()<>'BUTTONS'
      _curobj = _curobj
    endif
    if .not.("|"+i_function+"|"$"|Zoom|Prior|Next|")
      do cplu_erm with iif(empty(i_msg),iif(.not.i_chk,w_t_mseerr,w_t_mseobl),i_msg)
    endif
    &i_var = i_value
    if i_function = "Save"
      i_function = ""
    endif
  endif
  return .t.

procedure F_ChkAutoLock
  private i_rsp
  i_rsp = .t.
  return i_rsp

procedure Paint_Pag
  if i_pag>1
    i_pag = 1
    do F_Paint with 0
  else
    do F_Paint with 1
  endif
  return

procedure cplu_pn
  if i_function="Next"
    if .not. eof()
      skip
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    else
      do cplu_erm with w_t_msqefl
      i_loaded = .f.
      i_docreco = 0
    endif
  else
    if .not. bof()
      skip -1
    endif
    if .not. bof()
      i_loaded = .t.
      i_docreco = recno()
    else
      do cplu_erm with w_t_msqsfl
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    endif
  endif
  do F_Read
  do F_Paint with 1
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  return

procedure f_r
  #if left(version(),13)="Visual FoxPro"
  _curobj = _curobj
  #endif
  if .not. found()
    do cplu_erm with w_t_msmnr
    i_loaded = .f.
    i_docreco = 0
  else
    i_docreco = recno()
    i_loaded = .t.
    do F_Read
    do F_Paint with 1
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  clear read
  return

procedure cplu_3d
  parameter i_y,i_x,i_h,i_w,rilievo,fontn,fontp,fonts
  private i_color1,i_color2,i_ww,i_hh,i_olderror
  if parameters()>4 .and. rilievo
    i_color2 =  "rgb(92,92,92,92,92,92)"
    i_color1 =  "rgb(255,255,255,255,255,255)"
  else
    i_color1 =  "rgb(92,92,92,92,92,92)"
    i_color2 =  "rgb(255,255,255,255,255,255)"
  endif
  if parameters()>5
    i_h = i_h*fontmetric(1,fontn,fontp,fonts)/fontmetric(1)
    i_w = i_w*fontmetric(6,fontn,fontp,fonts)/fontmetric(6)
  endif
  i_olderror=on('ERROR')
  on error =.f.
  i_hh = 1/fontmetric(1)
  i_ww = 1/fontmetric(6)
  @ i_y-i_hh,i_x-i_ww     to i_y-i_hh,i_x+i_w+i_ww pen 1 color (i_color1)
  @ i_y-i_hh,i_x-i_ww     to i_y+i_h+i_hh,i_x-i_ww pen 1 color (i_color1)
  @ i_y+i_h+i_hh,i_x-i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  @ i_y-i_hh,i_x+i_w+i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  on error &i_olderror
  return

function cplu_tag
  param p
  i_pag=p
  i_campo = i_nbtntbar+1
  i_function="Repaint"
  return(.t.)

procedure gettab
  param wh,ntab
  private TABSZ,i,cwh,cntab,ci
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ci=alltrim(str(i))
    @ 0.4,TABSZ*(i-1)+1 get i_button size 1,TABSZ-2 pict "@*IT" valid cplu_tag(&ci)
  next
  return

procedure paintcurrtab
  param wh,ntab,ct
  private TABSZ
  TABSZ=min(int(wh/ntab),20)
  ct=ct-1
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  @ 1.5,ct*TABSZ to 1.5,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  @ 1.6,ct*TABSZ to 1.6,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  return

procedure painttab
  param wh,ntab
  private i,TABSZ
  TABSZ=min(int(wh/ntab),20)
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  for i=1 to ntab
    * --- linea orizzontale
    @ 0,(i-1)*TABSZ to 0,i*TABSZ-0.5 color rgb(255,255,255)
    * --- linee vericali
    @ 0,(i-1)*TABSZ to 1.5,(i-1)*TABSZ color rgb(255,255,255)
    @ 0.1,i*TABSZ-0.4 to 1.5,i*TABSZ-0.4
  next
  return

procedure painttabtitle
  param wh,ntab,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10
  private TABSZ,i,ii
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ii=alltrim(str(i))
    @ 0.3,TABSZ*(i-1)+1 say t&ii size 1,TABSZ-2 pict "@I"
  next
  return

* --- Area Manuale = Functions & Procedures
* --- gopa_krx
PROCEDURE SALVA
w_ERR = .f.
on error w_ERR=.t.
w_FILEXML = GETFILE("*")
on error
RETURN

PROCEDURE SALVAE
w_ERR = .f.
on error w_ERR=.t.
w_FILEMET = GETFILE("*")
on error
RETURN
* --- Fine Area Manuale
