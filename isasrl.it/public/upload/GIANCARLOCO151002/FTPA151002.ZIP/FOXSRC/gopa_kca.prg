* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_kca                                                        *
*              CARICAMENTO FATTURE PA                                          *
*                                                                              *
*      Author: DIP                                                             *
*      Client: FATTURA PA                                                      *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2015-09-29                                                      *
* Last revis.: 2015-09-30                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
private i_secdef
i_secdef = ""
do cplu_stb with "gopa_kca"
* --- Controllo di permesso di accesso alla procedura
w_s = 1
do cplu_sec with 50,"",w_s
if .not. w_s
  return
endif
* ----------------------------------------
* variabile pubblica che conterra' lo stato del programma
* in modo che possa riprendere da dove si era interrotto
public array s_gopa_kca[29]

private i_op
#define OP_QUERY     1
#define OP_LOAD      2
#define OP_EDITMOD   3
#define OP_EDITLOAD  4
#define OP_ZOOM      5
#define OP_QUIT      6
#define OP_INTR      7
i_op = OP_QUERY

* --- Variabili locali
private i_modal
i_modal = .t.
i_3d = iif(type("i_3d")="U",.t.,i_3d)
private i_shx,i_shsz
store 0 to i_shx,i_shsz
private i_loaded,w_s,i_campo,i_campoq,i_docreco, i_campg, i_accpt, i_zoomrec
private i_rdvars,i_rdkvars,i_rdkey, i_zoompars, i_zbrow, i_paint, i_oldarea
private i_pag,i_button,i_function,i_oldop,i_zoomprg, i_openfail, i_help, i_twind
private i_posyx1, i_size1, i_font1, i_style1
dimension i_posyx1[36,2], i_size1[36,2], i_font1[36,2], i_style1[36]
dimension i_campg[1]
dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 1 to i_pag, i_button, i_campoq
i_campo  = i_nbtntbar+1
store .f. to i_loaded, i_zbrow, i_paint, i_accpt, i_openfail
store 0 to i_oldop, i_docreco
store " " to i_function, w_s, i_zoomprg, i_rdkey, i_help
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
i_campg[1] = 14
private wnd_gopa_kca
wnd_gopa_kca = ' '

***
* Descrizione analisi CARICAMENTO FATTURE PA
***

private i_fngopa_kca


private w_PA1111,w_PA1112,w_PA112,w_PANRPROT,w_CVG
private w_PADTPROT,w_PA2114,w_PA2113,w_PACODBEN,w_PA12131
private w_PA1212,w_PA12112,w_PA21111,w_PA2119,w_PA2425
private w_NUMIMP,w_ANNOIMP,w_PA2127,w_PA2126,w_PAIMPEGN
private w_PAANPROT
store " " to w_PA1111,w_PA1112,w_PA112,w_PANRPROT,w_CVG
store " " to w_PADTPROT,w_PA2114,w_PA2113,w_PACODBEN,w_PA12131
store " " to w_PA1212,w_PA12112,w_PA21111,w_PA2119,w_PA2425
store " " to w_NUMIMP,w_ANNOIMP,w_PA2127,w_PA2126,w_PAIMPEGN
store " " to w_PAANPROT
private o_PADTPROT,o_PA2114,o_PA2113,o_PACODBEN,o_NUMIMP
private o_ANNOIMP
store " " to o_PADTPROT,o_PA2114,o_PA2113,o_PACODBEN,o_NUMIMP
store " " to o_ANNOIMP


i_oldarea = select()
if .not. wexist("gopa_kca")
  * --- se non esiste la finestra prova
  *     allora il programma non e' gia' attivo
  if .not. OpenProc()
    return
  endif
  * --- Event = Program Start
  * --- End Event
  i_op = OP_QUERY
  * --- Area Manuale = Init
  * --- Fine Area Manuale
  do F_Blank
  do Ass_pos
  do F_Paint with 0
else
  private i_ay
  i_ay = 0
  if _windows
    activate window "gopa_kca" noshow same
    modify window "gopa_kca" at wlrow(),wlcol() ;
      size at_y(350,"Arial",9,"")+i_ay,at_x(682,"Arial",9,"")
  else
    if _mac
      activate window "gopa_kca" noshow same
      modify window "gopa_kca" at wlrow(),wlcol() ;
        size at_y(350,"Arial",9*4/3,"")+i_ay,at_x(682,"Arial",9*4/3,"")
    endif
  endif
  do RestoreStatus
endif
do while i_op<>OP_QUIT .and. i_op<>OP_INTR
  do case
    case i_op=OP_QUERY .or. i_op=OP_EDITMOD
      i_op = OP_EDITMOD
      do F_Edit
    case i_op=OP_ZOOM
      &i_zoomprg
      do RestoreFilters
      i_op = iif(.not. empty(i_todo),OP_INTR,i_oldop)
  endcase
enddo
if i_op=OP_QUIT
  * --- Area Manuale = End
  * --- Fine Area Manuale
  * --- Event = Program End
  * --- End Event
  do CloseProc
else
  do SaveStatus
endif
i_warea = alltrim(str(i_oldarea))
select (i_oldarea)
return

* === OpenProc
*     definisce la finestra, blank alle variabili di lavoro
procedure OpenProc
  private i_ok,i_ay,i_pv,i_wnd
  i_ok = OpenFiles()
  i_ay = 0
  i_wnd = iif(empty(wontop()) or wontop()="BUTTONS","","in window ('"+wontop()+"')")
  if i_ok
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
    i_twind = "system name wnd_gopa_kca"
    i_pv=at_y(10)
    #else
    i_twind = "close grow"
    i_pv=iif(i_vtoolbar,at_y(10),max(at_y(10),2.8))
    #endif
    * ---
    do case
      case _windows
        define window "gopa_kca" at i_pv,at_x(10) size at_y(350,"Arial",9,"")+i_ay,at_x(682,"Arial",9,"");
          font "Arial",9;
          title "CARICAMENTO FATTURE PA";
          minimize float &i_twind icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

        modify window "gopa_kca" at i_pv,at_x(10) size at_y(350,"Arial",9,"")+i_ay,at_x(682,"Arial",9,"")
      case _mac
        i_pv=iif(i_vtoolbar,at_y(10),max(at_y(10),2.8))
        define window "gopa_kca" at i_pv,at_x(10) size at_y(350,"Arial",9*4/3,"")+i_ay,at_x(682,"Arial",9*4/3,"");
          font "Arial",9*4/3;
          title "CARICAMENTO FATTURE PA";
          minimize float close grow icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

      otherwise
        define window "gopa_kca" from 1,1 to 24,80;
          title "  CARICAMENTO FATTURE PA  ";
          minimize float close  "�","�","�","�","�","�","�","�";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

    endcase
set topic to 'CARICAMENTO FATTURE PA (programma)'
  endif
  return i_ok

* === OpenFiles
function OpenFiles
  private i_ok,i_w1
  i_ok = .t.
  * --- Apertura dei files
  i_w1 = cplu_opf("BEN_EFIC",'')
set exclusive off
  if .not.(i_w1)
    i_ok = .f.
    do cplu_clf with "BEN_EFIC",i_w1,''
  endif
  return i_ok

* === CloseProc
procedure CloseProc
  release window "gopa_kca"
  do CloseFiles
  * --- Fp3
  #if left(version(),13)="Visual FoxPro"
    oCpToolBar.Enable(.f.)
  #endif
  * ---
  return

* === CloseFiles
procedure CloseFiles
  do cplu_clf with "BEN_EFIC",.t.,''
  return

procedure RestoreStatus
  private i_zop
  i_docreco = s_gopa_kca[1]
  i_oldop   = s_gopa_kca[2]
  i_zoomprg = s_gopa_kca[3]
  i_campo   = s_gopa_kca[4]
  i_campoq  = s_gopa_kca[5]
  i_pag     = s_gopa_kca[6]
  i_loaded  = s_gopa_kca[7]
  i_zbrow   = s_gopa_kca[8]
  i_zop     = substr(i_zoomprg,4,len(i_zoomprg)-3)
  i_op      = iif(.not. empty(i_zoomprg) .and. (wvisible(i_zop) .or. .not. i_zbrow),OP_ZOOM,i_oldop)
  w_PA1111 = s_gopa_kca[9]
  w_PA1112 = s_gopa_kca[10]
  w_PA112 = s_gopa_kca[11]
  w_PANRPROT = s_gopa_kca[12]
  w_CVG = s_gopa_kca[13]
  w_PADTPROT = s_gopa_kca[14]
  w_PA2114 = s_gopa_kca[15]
  w_PA2113 = s_gopa_kca[16]
  w_PACODBEN = s_gopa_kca[17]
  w_PA12131 = s_gopa_kca[18]
  w_PA1212 = s_gopa_kca[19]
  w_PA12112 = s_gopa_kca[20]
  w_PA21111 = s_gopa_kca[21]
  w_PA2119 = s_gopa_kca[22]
  w_PA2425 = s_gopa_kca[23]
  w_NUMIMP = s_gopa_kca[24]
  w_ANNOIMP = s_gopa_kca[25]
  w_PA2127 = s_gopa_kca[26]
  w_PA2126 = s_gopa_kca[27]
  w_PAIMPEGN = s_gopa_kca[28]
  w_PAANPROT = s_gopa_kca[29]
  o_PADTPROT = w_PADTPROT
  o_PA2114 = w_PA2114
  o_PA2113 = w_PA2113
  o_PACODBEN = w_PACODBEN
  o_NUMIMP = w_NUMIMP
  o_ANNOIMP = w_ANNOIMP
  do RestoreFilters
  do Ass_pos
  return

procedure RestoreFilters
  do Set_Radio
set topic to 'CARICAMENTO FATTURE PA (programma)'
  return

procedure SaveStatus
  s_gopa_kca[1] = i_docreco
  s_gopa_kca[2] = i_oldop
  s_gopa_kca[3] = i_zoomprg
  s_gopa_kca[4] = i_campo
  s_gopa_kca[5] = i_campoq
  s_gopa_kca[6] = i_pag
  s_gopa_kca[7] = i_loaded
  s_gopa_kca[8] = i_zbrow
  s_gopa_kca[9] = w_PA1111
  s_gopa_kca[10] = w_PA1112
  s_gopa_kca[11] = w_PA112
  s_gopa_kca[12] = w_PANRPROT
  s_gopa_kca[13] = w_CVG
  s_gopa_kca[14] = w_PADTPROT
  s_gopa_kca[15] = w_PA2114
  s_gopa_kca[16] = w_PA2113
  s_gopa_kca[17] = w_PACODBEN
  s_gopa_kca[18] = w_PA12131
  s_gopa_kca[19] = w_PA1212
  s_gopa_kca[20] = w_PA12112
  s_gopa_kca[21] = w_PA21111
  s_gopa_kca[22] = w_PA2119
  s_gopa_kca[23] = w_PA2425
  s_gopa_kca[24] = w_NUMIMP
  s_gopa_kca[25] = w_ANNOIMP
  s_gopa_kca[26] = w_PA2127
  s_gopa_kca[27] = w_PA2126
  s_gopa_kca[28] = w_PAIMPEGN
  s_gopa_kca[29] = w_PAANPROT
  return

* === Ass_Pos
procedure Ass_Pos
  private i_wx, i_wy, i_ay
  activate window "gopa_kca" noshow same
  i_wx = fontmetric(6)
  i_wy = fontmetric(1)
  i_ay = 0
  do case
    case _windows
      do Ass_Pos_Win
    case _mac
      do Ass_Pos_Mac
    otherwise
      do Ass_Pos_Unkn
  endcase
  return

procedure Ass_Pos_Win
      i_posyx1[4,1] = i_ay+(16/i_wy) && at_y(16)
      i_posyx1[4,2] = 215/i_wx && at_x(215)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(77/i_wx)
      i_posyx1[6,1] = i_ay+(16/i_wy) && at_y(16)
      i_posyx1[6,2] = 103/i_wx && at_x(103)
      i_posyx1[7,1] = i_ay+(43/i_wy) && at_y(43)
      i_posyx1[7,2] = 215/i_wx && at_x(215)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(70/i_wx)
      i_posyx1[8,1] = i_ay+(43/i_wy) && at_y(43)
      i_posyx1[8,2] = 122/i_wx && at_x(122)
      i_posyx1[9,1] = i_ay+(70/i_wy) && at_y(70)
      i_posyx1[9,2] = 153/i_wx && at_x(153)
      i_posyx1[10,1] = i_ay+(70/i_wy) && at_y(70)
      i_posyx1[10,2] = 215/i_wx && at_x(215)
      i_size1[10,1] = 1
      i_size1[10,2] = cp_intsz(154/i_wx)
      i_posyx1[11,1] = i_ay+(97/i_wy) && at_y(97)
      i_posyx1[11,2] = 139/i_wx && at_x(139)
      i_posyx1[12,1] = i_ay+(97/i_wy) && at_y(97)
      i_posyx1[12,2] = 215/i_wx && at_x(215)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(70/i_wx)
      i_posyx1[13,1] = i_ay+(124/i_wy) && at_y(124)
      i_posyx1[13,2] = 215/i_wx && at_x(215)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(59/i_wx)
      i_posyx1[14,1] = i_ay+(151/i_wy) && at_y(151)
      i_posyx1[14,2] = 215/i_wx && at_x(215)
      i_size1[14,1] = 1
      i_size1[14,2] = cp_intsz(458/i_wx)
      i_posyx1[15,1] = i_ay+(151/i_wy) && at_y(151)
      i_posyx1[15,2] = 24/i_wx && at_x(24)
      i_posyx1[16,1] = i_ay+(178/i_wy) && at_y(178)
      i_posyx1[16,2] = 215/i_wx && at_x(215)
      i_size1[16,1] = 1
      i_size1[16,2] = cp_intsz(126/i_wx)
      i_posyx1[17,1] = i_ay+(178/i_wy) && at_y(178)
      i_posyx1[17,2] = 124/i_wx && at_x(124)
      i_posyx1[18,1] = i_ay+(205/i_wy) && at_y(205)
      i_posyx1[18,2] = 215/i_wx && at_x(215)
      i_size1[18,1] = 1
      i_size1[18,2] = cp_intsz(91/i_wx)
      i_posyx1[19,1] = i_ay+(205/i_wy) && at_y(205)
      i_posyx1[19,2] = 124/i_wx && at_x(124)
      i_posyx1[20,1] = i_ay+(232/i_wy) && at_y(232)
      i_posyx1[20,2] = 215/i_wx && at_x(215)
      i_size1[20,1] = 1
      i_size1[20,2] = cp_intsz(457/i_wx)
      i_posyx1[21,1] = i_ay+(232/i_wy) && at_y(232)
      i_posyx1[21,2] = 32/i_wx && at_x(32)
      i_posyx1[22,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx1[22,2] = 215/i_wx && at_x(215)
      i_size1[22,1] = 1
      i_size1[22,2] = cp_intsz(77/i_wx)
      i_posyx1[23,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx1[23,2] = 32/i_wx && at_x(32)
      i_posyx1[24,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx1[24,2] = 379/i_wx && at_x(379)
      i_size1[24,1] = 1
      i_size1[24,2] = cp_intsz(77/i_wx)
      i_posyx1[25,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx1[25,2] = 294/i_wx && at_x(294)
      i_posyx1[26,1] = i_ay+(286/i_wy) && at_y(286)
      i_posyx1[26,2] = 215/i_wx && at_x(215)
      i_size1[26,1] = 1
      i_size1[26,2] = cp_intsz(56/i_wx)
      i_posyx1[27,1] = i_ay+(286/i_wy) && at_y(286)
      i_posyx1[27,2] = 379/i_wx && at_x(379)
      i_size1[27,1] = 1
      i_size1[27,2] = cp_intsz(42/i_wx)
      i_posyx1[28,1] = i_ay+(286/i_wy) && at_y(286)
      i_posyx1[28,2] = 142/i_wx && at_x(142)
      i_posyx1[29,1] = i_ay+(286/i_wy) && at_y(286)
      i_posyx1[29,2] = 344/i_wx && at_x(344)
      i_posyx1[30,1] = i_ay+(313/i_wy) && at_y(313)
      i_posyx1[30,2] = 185/i_wx && at_x(185)
      i_posyx1[31,1] = i_ay+(313/i_wy) && at_y(313)
      i_posyx1[31,2] = 215/i_wx && at_x(215)
      i_size1[31,1] = 1
      i_size1[31,2] = cp_intsz(91/i_wx)
      i_posyx1[32,1] = i_ay+(313/i_wy) && at_y(313)
      i_posyx1[32,2] = 346/i_wx && at_x(346)
      i_posyx1[33,1] = i_ay+(313/i_wy) && at_y(313)
      i_posyx1[33,2] = 379/i_wx && at_x(379)
      i_size1[33,1] = 1
      i_size1[33,2] = cp_intsz(91/i_wx)
      i_posyx1[34,1] = i_ay+(124/i_wy) && at_y(124)
      i_posyx1[34,2] = 101/i_wx && at_x(101)
      i_font1[34,1] = "Arial"
      i_font1[34,2] = 9
      i_style1[34]  = ""
      i_posyx1[35,1] = i_ay+(307/i_wy) && at_y(307)
      i_posyx1[35,2] = 555/i_wx && at_x(555)
      i_size1[35,1] = at_y(31)
      i_size1[35,2] = cp_intsz(53/i_wx)
      i_posyx1[36,1] = i_ay+(307/i_wy) && at_y(307)
      i_posyx1[36,2] = 609/i_wx && at_x(609)
      i_size1[36,1] = at_y(31)
      i_size1[36,2] = cp_intsz(53/i_wx)
  return
procedure Ass_Pos_Mac
      i_posyx1[4,1] = i_ay+at_y(16)
      i_posyx1[4,2] = at_x(215)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(at_x(77))
      i_posyx1[6,1] = i_ay+at_y(16)
      i_posyx1[6,2] = at_x(103)
      i_posyx1[7,1] = i_ay+at_y(43)
      i_posyx1[7,2] = at_x(215)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(at_x(70))
      i_posyx1[8,1] = i_ay+at_y(43)
      i_posyx1[8,2] = at_x(122)
      i_posyx1[9,1] = i_ay+at_y(70)
      i_posyx1[9,2] = at_x(153)
      i_posyx1[10,1] = i_ay+at_y(70)
      i_posyx1[10,2] = at_x(215)
      i_size1[10,1] = 1
      i_size1[10,2] = cp_intsz(at_x(154))
      i_posyx1[11,1] = i_ay+at_y(97)
      i_posyx1[11,2] = at_x(139)
      i_posyx1[12,1] = i_ay+at_y(97)
      i_posyx1[12,2] = at_x(215)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(at_x(70))
      i_posyx1[13,1] = i_ay+at_y(124)
      i_posyx1[13,2] = at_x(215)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(at_x(59))
      i_posyx1[14,1] = i_ay+at_y(151)
      i_posyx1[14,2] = at_x(215)
      i_size1[14,1] = 1
      i_size1[14,2] = cp_intsz(at_x(458))
      i_posyx1[15,1] = i_ay+at_y(151)
      i_posyx1[15,2] = at_x(24)
      i_posyx1[16,1] = i_ay+at_y(178)
      i_posyx1[16,2] = at_x(215)
      i_size1[16,1] = 1
      i_size1[16,2] = cp_intsz(at_x(126))
      i_posyx1[17,1] = i_ay+at_y(178)
      i_posyx1[17,2] = at_x(124)
      i_posyx1[18,1] = i_ay+at_y(205)
      i_posyx1[18,2] = at_x(215)
      i_size1[18,1] = 1
      i_size1[18,2] = cp_intsz(at_x(91))
      i_posyx1[19,1] = i_ay+at_y(205)
      i_posyx1[19,2] = at_x(124)
      i_posyx1[20,1] = i_ay+at_y(232)
      i_posyx1[20,2] = at_x(215)
      i_size1[20,1] = 1
      i_size1[20,2] = cp_intsz(at_x(457))
      i_posyx1[21,1] = i_ay+at_y(232)
      i_posyx1[21,2] = at_x(32)
      i_posyx1[22,1] = i_ay+at_y(259)
      i_posyx1[22,2] = at_x(215)
      i_size1[22,1] = 1
      i_size1[22,2] = cp_intsz(at_x(77))
      i_posyx1[23,1] = i_ay+at_y(259)
      i_posyx1[23,2] = at_x(32)
      i_posyx1[24,1] = i_ay+at_y(259)
      i_posyx1[24,2] = at_x(379)
      i_size1[24,1] = 1
      i_size1[24,2] = cp_intsz(at_x(77))
      i_posyx1[25,1] = i_ay+at_y(259)
      i_posyx1[25,2] = at_x(294)
      i_posyx1[26,1] = i_ay+at_y(286)
      i_posyx1[26,2] = at_x(215)
      i_size1[26,1] = 1
      i_size1[26,2] = cp_intsz(at_x(56))
      i_posyx1[27,1] = i_ay+at_y(286)
      i_posyx1[27,2] = at_x(379)
      i_size1[27,1] = 1
      i_size1[27,2] = cp_intsz(at_x(42))
      i_posyx1[28,1] = i_ay+at_y(286)
      i_posyx1[28,2] = at_x(142)
      i_posyx1[29,1] = i_ay+at_y(286)
      i_posyx1[29,2] = at_x(344)
      i_posyx1[30,1] = i_ay+at_y(313)
      i_posyx1[30,2] = at_x(185)
      i_posyx1[31,1] = i_ay+at_y(313)
      i_posyx1[31,2] = at_x(215)
      i_size1[31,1] = 1
      i_size1[31,2] = cp_intsz(at_x(91))
      i_posyx1[32,1] = i_ay+at_y(313)
      i_posyx1[32,2] = at_x(346)
      i_posyx1[33,1] = i_ay+at_y(313)
      i_posyx1[33,2] = at_x(379)
      i_size1[33,1] = 1
      i_size1[33,2] = cp_intsz(at_x(91))
      i_posyx1[34,1] = i_ay+at_y(124)
      i_posyx1[34,2] = at_x(101)
      i_font1[34,1] = "Arial"
      i_font1[34,2] = 9*4/3
      i_style1[34]  = ""
      i_posyx1[35,1] = i_ay+at_y(307)
      i_posyx1[35,2] = at_x(555)
      i_size1[35,1] = at_y(31)
      i_size1[35,2] = cp_intsz(at_x(53))
      i_posyx1[36,1] = i_ay+at_y(307)
      i_posyx1[36,2] = at_x(609)
      i_size1[36,1] = at_y(31)
      i_size1[36,2] = cp_intsz(at_x(53))
  return
procedure Ass_Pos_Unkn
      i_posyx1[4,1] = -2
      i_posyx1[4,2] = -2
      i_size1[4,1]  = 1
      i_size1[4,2]  = 10
      i_posyx1[6,1] = -2
      i_posyx1[6,2] = -2
      i_posyx1[7,1] = -2
      i_posyx1[7,2] = -2
      i_size1[7,1]  = 1
      i_size1[7,2]  = 9
      i_posyx1[8,1] = -2
      i_posyx1[8,2] = -2
      i_posyx1[9,1] = -2
      i_posyx1[9,2] = -2
      i_posyx1[10,1] = -2
      i_posyx1[10,2] = -2
      i_size1[10,1]  = 1
      i_size1[10,2]  = 21
      i_posyx1[11,1] = -2
      i_posyx1[11,2] = -2
      i_posyx1[12,1] = -2
      i_posyx1[12,2] = -2
      i_size1[12,1]  = 1
      i_size1[12,2]  = 9
      i_posyx1[13,1] = 0
      i_posyx1[13,2] = 12
      i_size1[13,1]  = 1
      i_size1[13,2]  = 8
      i_posyx1[14,1] = -2
      i_posyx1[14,2] = -2
      i_size1[14,1]  = 1
      i_size1[14,2]  = 17
      i_posyx1[15,1] = -2
      i_posyx1[15,2] = -2
      i_posyx1[16,1] = -2
      i_posyx1[16,2] = -2
      i_size1[16,1]  = 1
      i_size1[16,2]  = 17
      i_posyx1[17,1] = -2
      i_posyx1[17,2] = -2
      i_posyx1[18,1] = -2
      i_posyx1[18,2] = -2
      i_size1[18,1]  = 1
      i_size1[18,2]  = 12
      i_posyx1[19,1] = -2
      i_posyx1[19,2] = -2
      i_posyx1[20,1] = -2
      i_posyx1[20,2] = -2
      i_size1[20,1]  = 1
      i_size1[20,2]  = 11
      i_posyx1[21,1] = -2
      i_posyx1[21,2] = -2
      i_posyx1[22,1] = -2
      i_posyx1[22,2] = -2
      i_size1[22,1]  = 1
      i_size1[22,2]  = 10
      i_posyx1[23,1] = -2
      i_posyx1[23,2] = -2
      i_posyx1[24,1] = -2
      i_posyx1[24,2] = -2
      i_size1[24,1]  = 1
      i_size1[24,2]  = 10
      i_posyx1[25,1] = -2
      i_posyx1[25,2] = -2
      i_posyx1[26,1] = -2
      i_posyx1[26,2] = -2
      i_size1[26,1]  = 1
      i_size1[26,2]  = 7
      i_posyx1[27,1] = -2
      i_posyx1[27,2] = -2
      i_size1[27,1]  = 1
      i_size1[27,2]  = 5
      i_posyx1[28,1] = -2
      i_posyx1[28,2] = -2
      i_posyx1[29,1] = -2
      i_posyx1[29,2] = -2
      i_posyx1[30,1] = -2
      i_posyx1[30,2] = -2
      i_posyx1[31,1] = -2
      i_posyx1[31,2] = -2
      i_size1[31,1]  = 1
      i_size1[31,2]  = 12
      i_posyx1[32,1] = -2
      i_posyx1[32,2] = -2
      i_posyx1[33,1] = -2
      i_posyx1[33,2] = -2
      i_size1[33,1]  = 1
      i_size1[33,2]  = 12
      i_posyx1[34,1] = 0
      i_posyx1[34,2] = 1
      i_font1[34,1] = ""
      i_font1[34,2] = 0
      i_style1[34]  = ""
      i_posyx1[35,1] = -2
      i_posyx1[35,2] = -2
      i_size1[35,1]  = 1
      i_size1[35,2]  = 6
      i_posyx1[36,1] = -2
      i_posyx1[36,2] = -2
      i_size1[36,1]  = 1
      i_size1[36,2]  = 8
return

function cp_intsz
  param i_sz
  return(iif(i_sz>=5,int(i_sz),i_sz))

* === F_Paint
procedure F_Paint
  parameters i_tutto
  private i_ay
  i_ay = 0
  activate window "gopa_kca" noshow same
  * --- Area Manuale = Paint Init
  * --- Fine Area Manuale
  if i_tutto=0
    clear
  endif
  do case
    case i_pag=1
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx1(6,1),i_posyx1(6,2) say "Numero Protocollo: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(109),19);
         picture "@J";

        @ i_posyx1(8,1),i_posyx1(8,2) say "Data Protocollo: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(90),17);
         picture "@J";

        @ i_posyx1(9,1),i_posyx1(9,2) say "N. Fattura: ";

        @ i_posyx1(11,1),i_posyx1(11,2) say "Data Fattura: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(73),14);
         picture "@J";

        @ i_posyx1(15,1),i_posyx1(15,2) say "Denominazione/Cognome Nome: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(188),28);
         picture "@J";

        @ i_posyx1(17,1),i_posyx1(17,2) say "Codice Fiscale: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(88),16);
         picture "@J";

        @ i_posyx1(19,1),i_posyx1(19,2) say "Partita IVA: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(88),13);
         picture "@J";

        @ i_posyx1(21,1),i_posyx1(21,2) say "Causale/ Oggetto della fornitura: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(180),34);
         picture "@J";

        @ i_posyx1(23,1),i_posyx1(23,2) say "Importo totale: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(180),16);
         picture "@J";

        @ i_posyx1(25,1),i_posyx1(25,2) say "Scadenza: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(84),10);
         picture "@J";

        @ i_posyx1(28,1),i_posyx1(28,2) say "N. Impegno: ";

        @ i_posyx1(29,1),i_posyx1(29,2) say "Anno: ";

        @ i_posyx1(30,1),i_posyx1(30,2) say "CIG: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(27),5);
         picture "@J";

        @ i_posyx1(32,1),i_posyx1(32,2) say "CUP: ";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(32),5);
         picture "@J";

        @ i_posyx1(34,1),i_posyx1(34,2) say "Beneficiario (Cofin): ";
         size iif(i_vidgrf,max(1.1,at_y(18,i_font1(34,1),i_font1(34,2),'')),1);
             ,iif(i_vidgrf,at_x(111,i_font1(34,1),i_font1(34,2),''),22);
         picture "@J";
          font i_font1(34,1), i_font1(34,2);

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx1(4,1),i_posyx1(4,2),i_size1[4,1],i_size1[4,2]
           do cplu_3d with i_posyx1(7,1),i_posyx1(7,2),i_size1[7,1],i_size1[7,2]
           do cplu_3d with i_posyx1(10,1),i_posyx1(10,2),i_size1[10,1],i_size1[10,2]
           do cplu_3d with i_posyx1(12,1),i_posyx1(12,2),i_size1[12,1],i_size1[12,2]
           do cplu_3d with i_posyx1(13,1),i_posyx1(13,2),i_size1[13,1],i_size1[13,2]
           do cplu_3d with i_posyx1(14,1),i_posyx1(14,2),i_size1[14,1],i_size1[14,2]
           do cplu_3d with i_posyx1(16,1),i_posyx1(16,2),i_size1[16,1],i_size1[16,2]
           do cplu_3d with i_posyx1(18,1),i_posyx1(18,2),i_size1[18,1],i_size1[18,2]
           do cplu_3d with i_posyx1(20,1),i_posyx1(20,2),i_size1[20,1],i_size1[20,2]
           do cplu_3d with i_posyx1(22,1),i_posyx1(22,2),i_size1[22,1],i_size1[22,2]
           do cplu_3d with i_posyx1(24,1),i_posyx1(24,2),i_size1[24,1],i_size1[24,2]
           do cplu_3d with i_posyx1(26,1),i_posyx1(26,2),i_size1[26,1],i_size1[26,2]
           do cplu_3d with i_posyx1(27,1),i_posyx1(27,2),i_size1[27,1],i_size1[27,2]
           do cplu_3d with i_posyx1(31,1),i_posyx1(31,2),i_size1[31,1],i_size1[31,2]
           do cplu_3d with i_posyx1(33,1),i_posyx1(33,2),i_size1[33,1],i_size1[33,2]
         endif
       else
       endif
        if i_vidgrf
        @ i_posyx1(35,1),i_posyx1(35,2) get i_button picture '@*B T_OK.BMP';
          size i_size1[35,1],i_size1[35,2] disable;

        else
        @ i_posyx1(35,1),i_posyx1(35,2) get i_button picture '@* Ok';
          size i_size1[35,1],i_size1[35,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(36,1),i_posyx1(36,2) get i_button picture '@*B BMP\T_CANCEL.BMP';
          size i_size1[36,1],i_size1[36,2] disable;

        else
        @ i_posyx1(36,1),i_posyx1(36,2) get i_button picture '@* Esci';
          size i_size1[36,1],i_size1[36,2] disable;

        endif
        clear gets
      endif
      @ i_posyx1(4,1),i_posyx1(4,2) say w_PANRPROT picture '@Z 9999999999';
        size i_size1[4,1],i_size1[4,2];
        color (w_t_col004)
      @ i_posyx1(7,1),i_posyx1(7,2) say w_PADTPROT;
        size i_size1[7,1],i_size1[7,2];
        color (w_t_col004)
      @ i_posyx1(10,1),i_posyx1(10,2) say w_PA2114 picture repl("X",20);
        size i_size1[10,1],i_size1[10,2];
        color (w_t_col004)
      @ i_posyx1(12,1),i_posyx1(12,2) say w_PA2113;
        size i_size1[12,1],i_size1[12,2];
        color (w_t_col004)
      @ i_posyx1(13,1),i_posyx1(13,2) say w_PACODBEN picture repl("X",7);
        size i_size1[13,1],i_size1[13,2];
        color (w_t_col004)
      @ i_posyx1(14,1),i_posyx1(14,2) say w_PA12131 picture repl("X",16);
        size i_size1[14,1],i_size1[14,2];
        color (w_t_col004)
      @ i_posyx1(16,1),i_posyx1(16,2) say w_PA1212 picture repl("X",16);
        size i_size1[16,1],i_size1[16,2];
        color (w_t_col004)
      @ i_posyx1(18,1),i_posyx1(18,2) say w_PA12112 picture '@Z 99999999999';
        size i_size1[18,1],i_size1[18,2];
        color (w_t_col004)
      @ i_posyx1(20,1),i_posyx1(20,2) say w_PA21111 picture repl("X",10);
        size i_size1[20,1],i_size1[20,2];
        color (w_t_col004)
      @ i_posyx1(22,1),i_posyx1(22,2) say w_PA2119 picture v_ZR+PS(15,w_CVG);
        size i_size1[22,1],i_size1[22,2];
        color (w_t_col004)
      @ i_posyx1(24,1),i_posyx1(24,2) say w_PA2425;
        size i_size1[24,1],i_size1[24,2];
        color (w_t_col004)
      @ i_posyx1(26,1),i_posyx1(26,2) say w_NUMIMP picture '@Z 999999';
        size i_size1[26,1],i_size1[26,2];
        color (w_t_col004)
      @ i_posyx1(27,1),i_posyx1(27,2) say w_ANNOIMP picture '@Z 9999';
        size i_size1[27,1],i_size1[27,2];
        color (w_t_col004)
      @ i_posyx1(31,1),i_posyx1(31,2) say w_PA2127 picture repl("X",10);
        size i_size1[31,1],i_size1[31,2];
        color (w_t_col004)
      @ i_posyx1(33,1),i_posyx1(33,2) say w_PA2126 picture repl("X",10);
        size i_size1[33,1],i_size1[33,2];
        color (w_t_col004)
  endcase
  activate window "gopa_kca" same
  * --- Area Manuale = Paint End
  * --- Fine Area Manuale
  return

* === F_Replace
function F_Replace
  * --- Area Manuale = Func Replace Init
  * --- Fine Area Manuale
  * --- Area Manuale = Func Replace End
  * --- Fine Area Manuale
  return

* === F_Blank
function F_Blank
  * --- Area Manuale = Func Blank Init
  * --- Fine Area Manuale
  w_PA1111 = space(2)
  w_PA1112 = space(28)
  w_PA112 = space(10)
  w_PANRPROT = 0
  w_CVG = space(10)
  w_PADTPROT = ctod("  /  /  ")
  w_PA2114 = space(20)
  w_PA2113 = ctod("  /  /  ")
  w_PACODBEN = space(7)
  w_PA12131 = space(16)
  w_PA1212 = space(16)
  w_PA12112 = space(11)
  w_PA21111 = space(10)
  w_PA2119 = 0
  w_PA2425 = ctod("  /  /  ")
  w_NUMIMP = 0
  w_ANNOIMP = space(4)
  w_PA2127 = space(10)
  w_PA2126 = space(10)
  w_PAIMPEGN = space(10)
  w_PAANPROT = space(4)
  w_PA1111 = '@@'
  w_PA1112 = ALLTRIM(w_PACODBEN) + ALLTRIM(w_PA2114)+ DTOC(w_PA2113)
  w_PA112 = ''
  w_CVG = NDecVal(ValCon(ytos(I_DATLAV)),'G')
  w_ANNOIMP = ytos(i_datlav)
  w_PAIMPEGN = w_ANNOIMP+ALLTRIM(STR(w_NUMIMP,6,0))
  w_PAANPROT = ytos(w_PADTPROT)
  * --- Area Manuale = Func Blank End
  * --- Fine Area Manuale
  do Set_Radio
  return

function F_Edit
  private i_esci, i_upda
  i_upda = .f.
  i_help = "gopa_kca edit"
  if i_vidgrf
    if i_op=OP_EDITMOD
      modify window "gopa_kca" title "CARICAMENTO FATTURE PA / Varia"
    endif
  endif
  * --- Area Manuale = Func Edit Init
  * --- Fine Area Manuale
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
  do while i_op=OP_EDITMOD .or. i_op=OP_EDITLOAD
    i_function = ""
    i_zoomprg  = ""
    if i_zbrow
      i_function = "Zoom"
    else
      activate window "gopa_kca"
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with i_op, .f.
      #endif
      * ---
      do case
        case i_pag=1
      @ i_posyx1[4,1],i_posyx1[4,2]+i_shx get w_PANRPROT picture '@Z 9999999999';
        size i_size1[4,1],i_size1[4,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PANRPROT",;
                0) .and.;
              F_Calc(.f.)
      @ i_posyx1[7,1],i_posyx1[7,2]+i_shx get w_PADTPROT;
        size i_size1[7,1],i_size1[7,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.t.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PADTPROT",;
                ctod("  /  /  ")) .and.;
              F_Calc(.f.)
      @ i_posyx1[10,1],i_posyx1[10,2]+i_shx get w_PA2114 picture repl("X",20);
        size i_size1[10,1],i_size1[10,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PA2114",;
                space(20)) .and.;
              F_Calc(.f.)
      @ i_posyx1[12,1],i_posyx1[12,2]+i_shx get w_PA2113;
        size i_size1[12,1],i_size1[12,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.t.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PA2113",;
                ctod("  /  /  ")) .and.;
              F_Calc(.f.)
      @ i_posyx1[13,1],i_posyx1[13,2]+i_shx get w_PACODBEN picture repl("X",7);
        size i_size1[13,1],i_size1[13,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.t.,.t.);
              ,.t.);
            valid;
              Cplu_zfi(7,"w_PACODBEN") .and.;
              F_aft1_13() .and.;
              F_Check(;
                .not.(updated().or.i_upda) .or.;
                F_Lnk1_13(),;
                .t.,;
                "w_PACODBEN",;
                space(7)) .and.;
              F_Calc(.f.)
      @ i_posyx1[14,1],i_posyx1[14,2]+i_shx get w_PA12131 picture repl("X",16);
        size i_size1[14,1],i_size1[14,2]+i_shsz;
     disable
      @ i_posyx1[16,1],i_posyx1[16,2]+i_shx get w_PA1212 picture repl("X",16);
        size i_size1[16,1],i_size1[16,2]+i_shsz;
     disable
      @ i_posyx1[18,1],i_posyx1[18,2]+i_shx get w_PA12112 picture '@Z 99999999999';
        size i_size1[18,1],i_size1[18,2]+i_shsz;
     disable
      @ i_posyx1[20,1],i_posyx1[20,2]+i_shx get w_PA21111 picture repl("X",10);
        size i_size1[20,1],i_size1[20,2]+i_shsz;
            message "Causale, oggetto della fornitura";
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PA21111",;
                space(10)) .and.;
              F_Calc(.f.)
      @ i_posyx1[22,1],i_posyx1[22,2]+i_shx get w_PA2119 picture v_ZR+PS(15,w_CVG);
        size i_size1[22,1],i_size1[22,2]+i_shsz;
            message "Importo Totale";
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .t.,;
                "w_PA2119",;
                0) .and.;
              F_Calc(.f.)
      @ i_posyx1[24,1],i_posyx1[24,2]+i_shx get w_PA2425;
        size i_size1[24,1],i_size1[24,2]+i_shsz;
            message "SCADENZA PAGAMENTO";
            when;
              iif(empty(i_function),;
                F_dep(.f.,.t.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PA2425",;
                ctod("  /  /  ")) .and.;
              F_Calc(.f.)
      @ i_posyx1[26,1],i_posyx1[26,2]+i_shx get w_NUMIMP picture '@Z 999999';
        size i_size1[26,1],i_size1[26,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_NUMIMP",;
                0) .and.;
              F_Calc(.f.)
      @ i_posyx1[27,1],i_posyx1[27,2]+i_shx get w_ANNOIMP picture '@Z 9999';
        size i_size1[27,1],i_size1[27,2]+i_shsz;
            message "ANNO IMPEGNO";
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_ANNOIMP",;
                space(4)) .and.;
              F_Calc(.f.)
      @ i_posyx1[31,1],i_posyx1[31,2]+i_shx get w_PA2127 picture repl("X",10);
        size i_size1[31,1],i_size1[31,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PA2127",;
                space(10)) .and.;
              F_Calc(.f.)
      @ i_posyx1[33,1],i_posyx1[33,2]+i_shx get w_PA2126 picture repl("X",10);
        size i_size1[33,1],i_size1[33,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PA2126",;
                space(10)) .and.;
              F_Calc(.f.)
            @ i_posyx1[35,1],i_posyx1[35,2] get i_button picture iif(i_vidgrf,'@*B T_OK.BMP','@* Ok');
              size i_size1[35,1],i_size1[35,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Save");

            @ i_posyx1[36,1],i_posyx1[36,2] get i_button picture iif(i_vidgrf,'@*B BMP\T_CANCEL.BMP','@* Esci');
              size i_size1[36,1],i_size1[36,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Quit");

      endcase
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gopa_kca")
      * --- Area Manuale = Func Edit Chkread2
      * --- Fine Area Manuale
    endif
    do case
      * --- Area Manuale = Func Edit Funckeys
      * --- Fine Area Manuale
      case .not. empty(i_todo)
        i_oldop = i_op
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Save"
        i_esci = .f.
        do case
          * --- Area Manuale = Func Edit Confirm
          * --- Fine Area Manuale
          * --- Controllo dei campi obbligatori nelle righe del corpo
          case empty(w_PANRPROT)
            i_pag = 1
            i_campo = 1+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PADTPROT)
            i_pag = 1
            i_campo = 2+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PA2114)
            i_pag = 1
            i_campo = 3+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PA2113)
            i_pag = 1
            i_campo = 4+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PACODBEN)
            i_pag = 1
            i_campo = 5+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PA12131)
            i_pag = 1
            i_campo = 6+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PA21111)
            i_pag = 1
            i_campo = 9+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case empty(w_PA2119)
            i_pag = 1
            i_campo = 10+i_nbtntbar
            do cplu_erm with w_t_mseobl
          case F_ChkAutoLock()
            i_esci = .t.
            * --- Area Manuale = Func Edit Save
            * --- Fine Area Manuale
        endcase
        if i_esci
          do F_Replace
          * --- Event = Mask Confirmed
          * --- End Event
          * --- Area Manuale = Print Init
          * --- Fine Area Manuale
  do GOPA_BFS with  'C' , w_PA1111, w_PA1112, w_PA112
          * --- Area Manuale = Print End
          * --- gopa_kca
          loop
          * --- Fine Area Manuale
  i_op = OP_QUIT
else
  do F_Paint with 0
endif
      case i_function="Prior" .or. i_function="Next"
        do case
          case i_pag=1
            do case
              case i_campo=5+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[2,1] = "w_PA1212"
i_rdvars[2,2] = "BECODFIS"
i_rdvars[3,1] = "w_PA12112"
i_rdvars[3,2] = "BEPARIVA"
i_rdvars[1,1] = 2
do cplu_fsk with "w_PACODBEN","BEN_EFIC",2,"BECODBEN","w_PA12131","BERAGSOC",w_s
            endcase
        endcase
        do F_Calc with .t.
      case i_function="Delete"
      case i_function="Zoom"
        i_oldop = i_op
        i_op = OP_ZOOM
        do case
          case i_pag=1
            do case
              case i_campo=2+i_nbtntbar
              case i_campo=4+i_nbtntbar
              case i_campo=5+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[2,1] = "w_PA1212"
i_rdvars[2,2] = "BECODFIS"
i_rdvars[3,1] = "w_PA12112"
i_rdvars[3,2] = "BEPARIVA"
i_rdvars[1,1] = 2
i_zoompars[1] = 2
i_zoompars[2] = 2
i_zoompars[3] = "Selezione Beneficiario"
do cplu_zom with "BEN_EFIC","BECODBEN","BERAGSOC","1","w_PACODBEN","w_PA12131","GOAR_ABE"
i_zbrow = .not. empty(i_zoomprg)
              case i_campo=11+i_nbtntbar
            endcase
        endcase
        if .not. i_zbrow
          do F_Calc with .t.
          i_op = i_oldop
        endif
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
i_op = OP_QUIT
        * --- Event = Mask Rejected
        * --- End Event
    endcase
  enddo
  * --- Area Manuale = Func Edit End
  * --- Fine Area Manuale
  return

function F_aft1_13
  do CPLU_ZER with w_PACODBEN
  return .t.

function F_dep
  parameter i_skip,i_zoom
  if _curobj>i_nbtntbar
    i_campo = _curobj
  endif
  i_accpt = .t.
  o_PADTPROT = w_PADTPROT
  o_PA2114 = w_PA2114
  o_PA2113 = w_PA2113
  o_PACODBEN = w_PACODBEN
  o_NUMIMP = w_NUMIMP
  o_ANNOIMP = w_ANNOIMP
  if .not. chrsaw()
    * --- FP3
    #if .not. (left(version(),13)="Visual FoxPro")
      show object 4 disable
      if i_skip
        show object 6 enable
        show object 7 enable
      else
        show object 6 disable
        show object 7 disable
      endif
      if i_zoom
        show object 8 enable
      else
        show object 8 disable
      endif
      if i_pag<>1
        show object 9 enable
      else
        show object 9 disable
      endif
      if i_pag<>1
        show object 10 enable
      else
        show object 10 disable
      endif
    #else
      * --- Parte per FoxPro3
      if i_skip
        oCPToolBar.b7.enabled = .t.
        oCPToolBar.b8.enabled = .t.
      else
        oCPToolBar.b7.enabled = .f.
        oCPToolBar.b8.enabled = .f.
      endif
      if i_zoom
        oCPToolBar.b9.enabled = .t.
      else
        oCPToolBar.b9.enabled = .f.
      endif
    #endif
    * ---
  endif
  * --- Area Manuale = Function Dep
  * --- Fine Area Manuale
  return .t.

function F_calc
  parameter i_upd
  * --- Area Manuale = Func Edit Calc Alws
  * --- Fine Area Manuale
  if updated() .or. i_upd .or. i_upda
    * --- Area Manuale = Func Edit Calc
    * --- Fine Area Manuale
    if o_PACODBEN<>w_PACODBEN.or. o_PA2114<>w_PA2114.or. o_PA2113<>w_PA2113
      w_PA1112 = ALLTRIM(w_PACODBEN) + ALLTRIM(w_PA2114)+ DTOC(w_PA2113)
    endif
      w_CVG = NDecVal(ValCon(ytos(I_DATLAV)),'G')
    if o_ANNOIMP<>w_ANNOIMP.or. o_NUMIMP<>w_NUMIMP
      w_PAIMPEGN = w_ANNOIMP+ALLTRIM(STR(w_NUMIMP,6,0))
    endif
    if o_PADTPROT<>w_PADTPROT
      w_PAANPROT = ytos(w_PADTPROT)
    endif
    do Set_Radio
    show gets
  endif
  i_upda = .f.
  return .t.

function F_Lnk1_13
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[2,1] = "w_PA1212"
  i_rdvars[2,2] = "BECODFIS"
  i_rdvars[3,1] = "w_PA12112"
  i_rdvars[3,2] = "BEPARIVA"
  i_rdvars[1,1] = 2
  do cplu_fld with "w_PACODBEN","BEN_EFIC",2,"BECODBEN","w_PA12131","BERAGSOC",w_s
  return w_s

function Set_Radio
  return .t.

function Get_Radio
  return .t.

function at_x
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(6)
  else
    i_pos = i_pos / fontmetric(6,i_fnt,i_h,i_s)
  endif
  return i_pos

function at_y
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(1)
  else
    i_pos = i_pos / fontmetric(1,i_fnt,i_h,i_s)
  endif
  return i_pos

function F_Check
  parameter i_chk, i_obbl, i_var, i_value, i_msg
  i_accpt = i_chk .and. (.not. i_obbl .or. &i_var<>i_value)
  if .not. i_accpt
    if wontop()<>'BUTTONS'
      _curobj = _curobj
    endif
    if .not.("|"+i_function+"|"$"|Zoom|Prior|Next|")
      do cplu_erm with iif(empty(i_msg),iif(.not.i_chk,w_t_mseerr,w_t_mseobl),i_msg)
    endif
    &i_var = i_value
    if i_function = "Save"
      i_function = ""
    endif
  endif
  return .t.

procedure F_ChkAutoLock
  private i_rsp
  i_rsp = .t.
  return i_rsp

procedure Paint_Pag
  if i_pag>1
    i_pag = 1
    do F_Paint with 0
  else
    do F_Paint with 1
  endif
  return

procedure cplu_pn
  if i_function="Next"
    if .not. eof()
      skip
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    else
      do cplu_erm with w_t_msqefl
      i_loaded = .f.
      i_docreco = 0
    endif
  else
    if .not. bof()
      skip -1
    endif
    if .not. bof()
      i_loaded = .t.
      i_docreco = recno()
    else
      do cplu_erm with w_t_msqsfl
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    endif
  endif
  do F_Read
  do F_Paint with 1
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  return

procedure f_r
  #if left(version(),13)="Visual FoxPro"
  _curobj = _curobj
  #endif
  if .not. found()
    do cplu_erm with w_t_msmnr
    i_loaded = .f.
    i_docreco = 0
  else
    i_docreco = recno()
    i_loaded = .t.
    do F_Read
    do F_Paint with 1
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  clear read
  return

procedure cplu_3d
  parameter i_y,i_x,i_h,i_w,rilievo,fontn,fontp,fonts
  private i_color1,i_color2,i_ww,i_hh,i_olderror
  if parameters()>4 .and. rilievo
    i_color2 =  "rgb(92,92,92,92,92,92)"
    i_color1 =  "rgb(255,255,255,255,255,255)"
  else
    i_color1 =  "rgb(92,92,92,92,92,92)"
    i_color2 =  "rgb(255,255,255,255,255,255)"
  endif
  if parameters()>5
    i_h = i_h*fontmetric(1,fontn,fontp,fonts)/fontmetric(1)
    i_w = i_w*fontmetric(6,fontn,fontp,fonts)/fontmetric(6)
  endif
  i_olderror=on('ERROR')
  on error =.f.
  i_hh = 1/fontmetric(1)
  i_ww = 1/fontmetric(6)
  @ i_y-i_hh,i_x-i_ww     to i_y-i_hh,i_x+i_w+i_ww pen 1 color (i_color1)
  @ i_y-i_hh,i_x-i_ww     to i_y+i_h+i_hh,i_x-i_ww pen 1 color (i_color1)
  @ i_y+i_h+i_hh,i_x-i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  @ i_y-i_hh,i_x+i_w+i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  on error &i_olderror
  return

function cplu_tag
  param p
  i_pag=p
  i_campo = i_nbtntbar+1
  i_function="Repaint"
  return(.t.)

procedure gettab
  param wh,ntab
  private TABSZ,i,cwh,cntab,ci
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ci=alltrim(str(i))
    @ 0.4,TABSZ*(i-1)+1 get i_button size 1,TABSZ-2 pict "@*IT" valid cplu_tag(&ci)
  next
  return

procedure paintcurrtab
  param wh,ntab,ct
  private TABSZ
  TABSZ=min(int(wh/ntab),20)
  ct=ct-1
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  @ 1.5,ct*TABSZ to 1.5,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  @ 1.6,ct*TABSZ to 1.6,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  return

procedure painttab
  param wh,ntab
  private i,TABSZ
  TABSZ=min(int(wh/ntab),20)
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  for i=1 to ntab
    * --- linea orizzontale
    @ 0,(i-1)*TABSZ to 0,i*TABSZ-0.5 color rgb(255,255,255)
    * --- linee vericali
    @ 0,(i-1)*TABSZ to 1.5,(i-1)*TABSZ color rgb(255,255,255)
    @ 0.1,i*TABSZ-0.4 to 1.5,i*TABSZ-0.4
  next
  return

procedure painttabtitle
  param wh,ntab,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10
  private TABSZ,i,ii
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ii=alltrim(str(i))
    @ 0.3,TABSZ*(i-1)+1 say t&ii size 1,TABSZ-2 pict "@I"
  next
  return

* --- Area Manuale = Functions & Procedures
* --- Fine Area Manuale
