* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_srx                                                        *
*              STAMPA REGISTRO FATTURE                                         *
*                                                                              *
*      Author: DIP                                                             *
*      Client:                                                                 *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2001-10-23                                                      *
* Last revis.: 2015-09-30                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
private i_secdef
i_secdef = ""
do cplu_stb with "gopa_srx"
* --- Controllo di permesso di accesso alla procedura
w_s = 1
do cplu_sec with 50,"9",w_s
if .not. w_s
  return
endif
* ----------------------------------------
* variabile pubblica che conterra' lo stato del programma
* in modo che possa riprendere da dove si era interrotto
public array s_gopa_srx[17]

private i_op
#define OP_QUERY     1
#define OP_LOAD      2
#define OP_EDITMOD   3
#define OP_EDITLOAD  4
#define OP_ZOOM      5
#define OP_QUIT      6
#define OP_INTR      7
i_op = OP_QUERY

* --- Variabili locali
i_3d = iif(type("i_3d")="U",.t.,i_3d)
private i_shx,i_shsz
store 0 to i_shx,i_shsz
private i_loaded,w_s,i_campo,i_campoq,i_docreco, i_campg, i_accpt, i_zoomrec
private i_rdvars,i_rdkvars,i_rdkey, i_zoompars, i_zbrow, i_paint, i_oldarea
private i_pag,i_button,i_function,i_oldop,i_zoomprg, i_openfail, i_help, i_twind
private i_posyx1, i_size1, i_font1, i_style1
dimension i_posyx1[17,2], i_size1[17,2], i_font1[17,2], i_style1[17]
dimension i_campg[1]
dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 1 to i_pag, i_button, i_campoq
i_campo  = i_nbtntbar+1
store .f. to i_loaded, i_zbrow, i_paint, i_accpt, i_openfail
store 0 to i_oldop, i_docreco
store " " to i_function, w_s, i_zoomprg, i_rdkey, i_help
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
i_campg[1] = 8
private wnd_gopa_srx
wnd_gopa_srx = ' '

***
* Descrizione analisi STAMPA REGISTRO FATTURE
***

private i_fngopa_srx


private w_DATCOM,w_DACODBEN,w_COGN1,w_ACODBEN,w_COGN2
private w_DATINI,w_DATFIN,w_DATINIP,w_DATFINP
store " " to w_DATCOM,w_DACODBEN,w_COGN1,w_ACODBEN,w_COGN2
store " " to w_DATINI,w_DATFIN,w_DATINIP,w_DATFINP
private o_DATCOM
store " " to o_DATCOM


i_oldarea = select()
if .not. wexist("gopa_srx")
  * --- se non esiste la finestra prova
  *     allora il programma non e' gia' attivo
  if .not. OpenProc()
    return
  endif
  * --- Event = Program Start
  * --- End Event
  i_op = OP_QUERY
  * --- Area Manuale = Init
  * --- Fine Area Manuale
  do F_Blank
  do Ass_pos
  do F_Paint with 0
else
  private i_ay
  i_ay = 0
  if _windows
    activate window "gopa_srx" noshow same
    modify window "gopa_srx" at wlrow(),wlcol() ;
      size at_y(173,"Arial",9,"")+i_ay,at_x(447,"Arial",9,"")
  else
    if _mac
      activate window "gopa_srx" noshow same
      modify window "gopa_srx" at wlrow(),wlcol() ;
        size at_y(173,"Arial",9*4/3,"")+i_ay,at_x(447,"Arial",9*4/3,"")
    endif
  endif
  do RestoreStatus
endif
do while i_op<>OP_QUIT .and. i_op<>OP_INTR
  do case
    case i_op=OP_QUERY .or. i_op=OP_EDITMOD
      i_op = OP_EDITMOD
      do F_Edit
    case i_op=OP_ZOOM
      &i_zoomprg
      do RestoreFilters
      i_op = iif(.not. empty(i_todo),OP_INTR,i_oldop)
  endcase
enddo
if i_op=OP_QUIT
  * --- Area Manuale = End
  * --- Fine Area Manuale
  * --- Event = Program End
  * --- End Event
  do CloseProc
else
  do SaveStatus
endif
i_warea = alltrim(str(i_oldarea))
select (i_oldarea)
return

* === OpenProc
*     definisce la finestra, blank alle variabili di lavoro
procedure OpenProc
  private i_ok,i_ay,i_pv,i_wnd
  i_ok = OpenFiles()
  i_ay = 0
  i_wnd = iif(empty(wontop()) or wontop()="BUTTONS","","in window ('"+wontop()+"')")
  if i_ok
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
    i_twind = "system name wnd_gopa_srx"
    i_pv=at_y(2)
    #else
    i_twind = "close grow"
    i_pv=iif(i_vtoolbar,at_y(2),max(at_y(2),2.8))
    #endif
    * ---
    do case
      case _windows
        define window "gopa_srx" at i_pv,at_x(6) size at_y(173,"Arial",9,"")+i_ay,at_x(447,"Arial",9,"");
          font "Arial",9;
          title "STAMPA REGISTRO FATTURE";
          minimize float &i_twind icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

        modify window "gopa_srx" at i_pv,at_x(6) size at_y(173,"Arial",9,"")+i_ay,at_x(447,"Arial",9,"")
      case _mac
        i_pv=iif(i_vtoolbar,at_y(2),max(at_y(2),2.8))
        define window "gopa_srx" at i_pv,at_x(6) size at_y(173,"Arial",9*4/3,"")+i_ay,at_x(447,"Arial",9*4/3,"");
          font "Arial",9*4/3;
          title "STAMPA REGISTRO FATTURE";
          minimize float close grow icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

      otherwise
        define window "gopa_srx" from 0,0 to 13,60;
          title "  STAMPA REGISTRO FATTURE  ";
          minimize float close  "�","�","�","�","�","�","�","�";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

    endcase
set topic to 'STAMPA REGISTRO FATTURE (programma)'
  endif
  return i_ok

* === OpenFiles
function OpenFiles
  private i_ok,i_w1,i_w2,i_w3,i_w4
  i_ok = .t.
  * --- Apertura dei files
  i_w1 = cplu_opf("TIP_RICE",'')
  i_w2 = cplu_opf("PAG_INCA",'')
  i_w3 = cplu_opf("CON_TILQ",'')
  i_w4 = cplu_opf("BEN_EFIC",'')
set exclusive off
  if .not.(i_w1 .and. i_w2 .and. i_w3 .and. i_w4)
    i_ok = .f.
    do cplu_clf with "TIP_RICE",i_w1,''
    do cplu_clf with "PAG_INCA",i_w2,''
    do cplu_clf with "CON_TILQ",i_w3,''
    do cplu_clf with "BEN_EFIC",i_w4,''
  endif
  return i_ok

* === CloseProc
procedure CloseProc
  release window "gopa_srx"
  do CloseFiles
  * --- Fp3
  #if left(version(),13)="Visual FoxPro"
    oCpToolBar.Enable(.f.)
  #endif
  * ---
  return

* === CloseFiles
procedure CloseFiles
  do cplu_clf with "TIP_RICE",.t.,''
  do cplu_clf with "PAG_INCA",.t.,''
  do cplu_clf with "CON_TILQ",.t.,''
  do cplu_clf with "BEN_EFIC",.t.,''
  return

procedure RestoreStatus
  private i_zop
  i_docreco = s_gopa_srx[1]
  i_oldop   = s_gopa_srx[2]
  i_zoomprg = s_gopa_srx[3]
  i_campo   = s_gopa_srx[4]
  i_campoq  = s_gopa_srx[5]
  i_pag     = s_gopa_srx[6]
  i_loaded  = s_gopa_srx[7]
  i_zbrow   = s_gopa_srx[8]
  i_zop     = substr(i_zoomprg,4,len(i_zoomprg)-3)
  i_op      = iif(.not. empty(i_zoomprg) .and. (wvisible(i_zop) .or. .not. i_zbrow),OP_ZOOM,i_oldop)
  w_DATCOM = s_gopa_srx[9]
  w_DACODBEN = s_gopa_srx[10]
  w_COGN1 = s_gopa_srx[11]
  w_ACODBEN = s_gopa_srx[12]
  w_COGN2 = s_gopa_srx[13]
  w_DATINI = s_gopa_srx[14]
  w_DATFIN = s_gopa_srx[15]
  w_DATINIP = s_gopa_srx[16]
  w_DATFINP = s_gopa_srx[17]
  o_DATCOM = w_DATCOM
  do RestoreFilters
  do Ass_pos
  return

procedure RestoreFilters
  do Set_Radio
set topic to 'STAMPA REGISTRO FATTURE (programma)'
  return

procedure SaveStatus
  s_gopa_srx[1] = i_docreco
  s_gopa_srx[2] = i_oldop
  s_gopa_srx[3] = i_zoomprg
  s_gopa_srx[4] = i_campo
  s_gopa_srx[5] = i_campoq
  s_gopa_srx[6] = i_pag
  s_gopa_srx[7] = i_loaded
  s_gopa_srx[8] = i_zbrow
  s_gopa_srx[9] = w_DATCOM
  s_gopa_srx[10] = w_DACODBEN
  s_gopa_srx[11] = w_COGN1
  s_gopa_srx[12] = w_ACODBEN
  s_gopa_srx[13] = w_COGN2
  s_gopa_srx[14] = w_DATINI
  s_gopa_srx[15] = w_DATFIN
  s_gopa_srx[16] = w_DATINIP
  s_gopa_srx[17] = w_DATFINP
  return

* === Ass_Pos
procedure Ass_Pos
  private i_wx, i_wy, i_ay
  activate window "gopa_srx" noshow same
  i_wx = fontmetric(6)
  i_wy = fontmetric(1)
  i_ay = 0
  do case
    case _windows
      do Ass_Pos_Win
    case _mac
      do Ass_Pos_Mac
    otherwise
      do Ass_Pos_Unkn
  endcase
  return

procedure Ass_Pos_Win
      i_posyx1[2,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[2,2] = 94/i_wx && at_x(94)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(59/i_wx)
      i_posyx1[3,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[3,2] = 160/i_wx && at_x(160)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(283/i_wx)
      i_posyx1[4,1] = i_ay+(97/i_wy) && at_y(97)
      i_posyx1[4,2] = 94/i_wx && at_x(94)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(59/i_wx)
      i_posyx1[5,1] = i_ay+(97/i_wy) && at_y(97)
      i_posyx1[5,2] = 160/i_wx && at_x(160)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(283/i_wx)
      i_posyx1[6,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[6,2] = 95/i_wx && at_x(95)
      i_size1[6,1] = 1
      i_size1[6,2] = cp_intsz(73/i_wx)
      i_posyx1[7,1] = i_ay+(38/i_wy) && at_y(38)
      i_posyx1[7,2] = 94/i_wx && at_x(94)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(73/i_wx)
      i_posyx1[8,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[8,2] = 5/i_wx && at_x(5)
      i_font1[8,1] = "Arial"
      i_font1[8,2] = 9
      i_style1[8]  = ""
      i_posyx1[9,1] = i_ay+(97/i_wy) && at_y(97)
      i_posyx1[9,2] = 19/i_wx && at_x(19)
      i_posyx1[10,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[10,2] = 6/i_wx && at_x(6)
      i_posyx1[11,1] = i_ay+(38/i_wy) && at_y(38)
      i_posyx1[11,2] = 9/i_wx && at_x(9)
      i_posyx1[12,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[12,2] = 368/i_wx && at_x(368)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(73/i_wx)
      i_posyx1[13,1] = i_ay+(38/i_wy) && at_y(38)
      i_posyx1[13,2] = 367/i_wx && at_x(367)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(73/i_wx)
      i_posyx1[14,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[14,2] = 262/i_wx && at_x(262)
      i_posyx1[15,1] = i_ay+(36/i_wy) && at_y(36)
      i_posyx1[15,2] = 252/i_wx && at_x(252)
      i_posyx1[16,1] = i_ay+(128/i_wy) && at_y(128)
      i_posyx1[16,2] = 385/i_wx && at_x(385)
      i_size1[16,1] = at_y(30)
      i_size1[16,2] = cp_intsz(55/i_wx)
      i_posyx1[17,1] = i_ay+(128/i_wy) && at_y(128)
      i_posyx1[17,2] = 325/i_wx && at_x(325)
      i_size1[17,1] = at_y(30)
      i_size1[17,2] = cp_intsz(55/i_wx)
  return
procedure Ass_Pos_Mac
      i_posyx1[2,1] = i_ay+at_y(72)
      i_posyx1[2,2] = at_x(94)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(at_x(59))
      i_posyx1[3,1] = i_ay+at_y(72)
      i_posyx1[3,2] = at_x(160)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(at_x(283))
      i_posyx1[4,1] = i_ay+at_y(97)
      i_posyx1[4,2] = at_x(94)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(at_x(59))
      i_posyx1[5,1] = i_ay+at_y(97)
      i_posyx1[5,2] = at_x(160)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(at_x(283))
      i_posyx1[6,1] = i_ay+at_y(14)
      i_posyx1[6,2] = at_x(95)
      i_size1[6,1] = 1
      i_size1[6,2] = cp_intsz(at_x(73))
      i_posyx1[7,1] = i_ay+at_y(38)
      i_posyx1[7,2] = at_x(94)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(at_x(73))
      i_posyx1[8,1] = i_ay+at_y(72)
      i_posyx1[8,2] = at_x(5)
      i_font1[8,1] = "Arial"
      i_font1[8,2] = 9*4/3
      i_style1[8]  = ""
      i_posyx1[9,1] = i_ay+at_y(97)
      i_posyx1[9,2] = at_x(19)
      i_posyx1[10,1] = i_ay+at_y(14)
      i_posyx1[10,2] = at_x(6)
      i_posyx1[11,1] = i_ay+at_y(38)
      i_posyx1[11,2] = at_x(9)
      i_posyx1[12,1] = i_ay+at_y(14)
      i_posyx1[12,2] = at_x(368)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(at_x(73))
      i_posyx1[13,1] = i_ay+at_y(38)
      i_posyx1[13,2] = at_x(367)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(at_x(73))
      i_posyx1[14,1] = i_ay+at_y(14)
      i_posyx1[14,2] = at_x(262)
      i_posyx1[15,1] = i_ay+at_y(36)
      i_posyx1[15,2] = at_x(252)
      i_posyx1[16,1] = i_ay+at_y(128)
      i_posyx1[16,2] = at_x(385)
      i_size1[16,1] = at_y(30)
      i_size1[16,2] = cp_intsz(at_x(55))
      i_posyx1[17,1] = i_ay+at_y(128)
      i_posyx1[17,2] = at_x(325)
      i_size1[17,1] = at_y(30)
      i_size1[17,2] = cp_intsz(at_x(55))
  return
procedure Ass_Pos_Unkn
      i_posyx1[2,1] = 1
      i_posyx1[2,2] = 13
      i_size1[2,1]  = 1
      i_size1[2,2]  = 8
      i_posyx1[3,1] = 1
      i_posyx1[3,2] = 22
      i_size1[3,1]  = 1
      i_size1[3,2]  = 40
      i_posyx1[4,1] = 2
      i_posyx1[4,2] = 13
      i_size1[4,1]  = 1
      i_size1[4,2]  = 8
      i_posyx1[5,1] = 2
      i_posyx1[5,2] = 22
      i_size1[5,1]  = 1
      i_size1[5,2]  = 40
      i_posyx1[6,1] = 5
      i_posyx1[6,2] = 28
      i_size1[6,1]  = 1
      i_size1[6,2]  = 10
      i_posyx1[7,1] = 5
      i_posyx1[7,2] = 45
      i_size1[7,1]  = 1
      i_size1[7,2]  = 10
      i_posyx1[8,1] = 1
      i_posyx1[8,2] = 2
      i_font1[8,1] = ""
      i_font1[8,2] = 0
      i_style1[8]  = ""
      i_posyx1[9,1] = 2
      i_posyx1[9,2] = 4
      i_posyx1[10,1] = 5
      i_posyx1[10,2] = 22
      i_posyx1[11,1] = 5
      i_posyx1[11,2] = 22
      i_posyx1[12,1] = 5
      i_posyx1[12,2] = 28
      i_size1[12,1]  = 1
      i_size1[12,2]  = 10
      i_posyx1[13,1] = 5
      i_posyx1[13,2] = 45
      i_size1[13,1]  = 1
      i_size1[13,2]  = 10
      i_posyx1[14,1] = 5
      i_posyx1[14,2] = 22
      i_posyx1[15,1] = 5
      i_posyx1[15,2] = 22
      i_posyx1[16,1] = 14
      i_posyx1[16,2] = 11
      i_size1[16,1]  = 1
      i_size1[16,2]  = 11
      i_posyx1[17,1] = 14
      i_posyx1[17,2] = 11
      i_size1[17,1]  = 1
      i_size1[17,2]  = 6
return

function cp_intsz
  param i_sz
  return(iif(i_sz>=5,int(i_sz),i_sz))

* === F_Paint
procedure F_Paint
  parameters i_tutto
  private i_ay
  i_ay = 0
  activate window "gopa_srx" noshow same
  * --- Area Manuale = Paint Init
  * --- Fine Area Manuale
  if i_tutto=0
    clear
  endif
  do case
    case i_pag=1
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx1(8,1),i_posyx1(8,2) say "Da Beneficiario:";
         size iif(i_vidgrf,max(1.1,at_y(15,i_font1(8,1),i_font1(8,2),'')),1);
             ,iif(i_vidgrf,at_x(87,i_font1(8,1),i_font1(8,2),''),16);
         picture "@J";
          font i_font1(8,1), i_font1(8,2);

        @ i_posyx1(9,1),i_posyx1(9,2) say "A Benficiario:";
         size iif(i_vidgrf,max(1.1,at_y(15)),1);
             ,iif(i_vidgrf,at_x(73),14);
         picture "@J";

        @ i_posyx1(10,1),i_posyx1(10,2) say "Da data Fattura:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(87),16);
         picture "@J";

        @ i_posyx1(11,1),i_posyx1(11,2) say "A data Fattura:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(83),15);
         picture "@J";

        @ i_posyx1(14,1),i_posyx1(14,2) say "Da data Protocollo:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(104),19);
         picture "@J";

        @ i_posyx1(15,1),i_posyx1(15,2) say "A data Protocollo:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(114),18);
         picture "@J";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx1(2,1),i_posyx1(2,2),i_size1[2,1],i_size1[2,2]
           do cplu_3d with i_posyx1(3,1),i_posyx1(3,2),i_size1[3,1],i_size1[3,2]
           do cplu_3d with i_posyx1(4,1),i_posyx1(4,2),i_size1[4,1],i_size1[4,2]
           do cplu_3d with i_posyx1(5,1),i_posyx1(5,2),i_size1[5,1],i_size1[5,2]
           do cplu_3d with i_posyx1(6,1),i_posyx1(6,2),i_size1[6,1],i_size1[6,2]
           do cplu_3d with i_posyx1(7,1),i_posyx1(7,2),i_size1[7,1],i_size1[7,2]
           do cplu_3d with i_posyx1(12,1),i_posyx1(12,2),i_size1[12,1],i_size1[12,2]
           do cplu_3d with i_posyx1(13,1),i_posyx1(13,2),i_size1[13,1],i_size1[13,2]
         endif
       else
       endif
        if i_vidgrf
        @ i_posyx1(16,1),i_posyx1(16,2) get i_button picture '@*B t_cancel.bmp';
          size i_size1[16,1],i_size1[16,2] disable;

        else
        @ i_posyx1(16,1),i_posyx1(16,2) get i_button picture '@* Annulla';
          size i_size1[16,1],i_size1[16,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(17,1),i_posyx1(17,2) get i_button picture '@*B t_Ok.bmp';
          size i_size1[17,1],i_size1[17,2] disable;

        else
        @ i_posyx1(17,1),i_posyx1(17,2) get i_button picture '@* Ok';
          size i_size1[17,1],i_size1[17,2] disable;

        endif
        clear gets
      endif
      @ i_posyx1(2,1),i_posyx1(2,2) say w_DACODBEN picture repl("X",7);
        size i_size1[2,1],i_size1[2,2];
        color (w_t_col004)
      @ i_posyx1(3,1),i_posyx1(3,2) say w_COGN1 picture repl("X",40);
        size i_size1[3,1],i_size1[3,2];
        color (w_t_col004)
      @ i_posyx1(4,1),i_posyx1(4,2) say w_ACODBEN picture repl("X",7);
        size i_size1[4,1],i_size1[4,2];
        color (w_t_col004)
      @ i_posyx1(5,1),i_posyx1(5,2) say w_COGN2 picture repl("X",40);
        size i_size1[5,1],i_size1[5,2];
        color (w_t_col004)
      @ i_posyx1(6,1),i_posyx1(6,2) say w_DATINI;
        size i_size1[6,1],i_size1[6,2];
        color (w_t_col004)
      @ i_posyx1(7,1),i_posyx1(7,2) say w_DATFIN;
        size i_size1[7,1],i_size1[7,2];
        color (w_t_col004)
      @ i_posyx1(12,1),i_posyx1(12,2) say w_DATINIP;
        size i_size1[12,1],i_size1[12,2];
        color (w_t_col004)
      @ i_posyx1(13,1),i_posyx1(13,2) say w_DATFINP;
        size i_size1[13,1],i_size1[13,2];
        color (w_t_col004)
  endcase
  activate window "gopa_srx" same
  * --- Area Manuale = Paint End
  * --- Fine Area Manuale
  return

* === F_Replace
function F_Replace
  * --- Area Manuale = Func Replace Init
  * --- Fine Area Manuale
  * --- Area Manuale = Func Replace End
  * --- Fine Area Manuale
  return

* === F_Blank
function F_Blank
  * --- Area Manuale = Func Blank Init
  * --- Fine Area Manuale
  w_DATCOM = space(4)
  w_DACODBEN = space(7)
  w_COGN1 = space(40)
  w_ACODBEN = space(7)
  w_COGN2 = space(40)
  w_DATINI = ctod("  /  /  ")
  w_DATFIN = ctod("  /  /  ")
  w_DATINIP = ctod("  /  /  ")
  w_DATFINP = ctod("  /  /  ")
  w_DATCOM = str(year(i_DATLAV),4,0)
  w_DATINI = ifcc(w_DATCOM,"I")
  w_DATFIN = iif(empty(w_DATCOM),i_DATLAV,ifcc(w_DATCOM,"F"))
  * --- Area Manuale = Func Blank End
  * --- Fine Area Manuale
  do Set_Radio
  return

function F_Edit
  private i_esci, i_upda
  i_upda = .f.
  i_help = "gopa_srx edit"
  if i_vidgrf
    if i_op=OP_EDITMOD
      modify window "gopa_srx" title "STAMPA REGISTRO FATTURE / Varia"
    endif
  endif
  * --- Area Manuale = Func Edit Init
  * --- Fine Area Manuale
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
  do while i_op=OP_EDITMOD .or. i_op=OP_EDITLOAD
    i_function = ""
    i_zoomprg  = ""
    if i_zbrow
      i_function = "Zoom"
    else
      activate window "gopa_srx"
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with i_op, .f.
      #endif
      * ---
      do case
        case i_pag=1
      @ i_posyx1[2,1],i_posyx1[2,2]+i_shx get w_DACODBEN picture repl("X",7);
        size i_size1[2,1],i_size1[2,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.t.,.t.);
              ,.t.);
            valid;
              Cplu_zfi(7,"w_DACODBEN") .and.;
              F_aft1_2() .and.;
              F_Check(;
                .not.(updated().or.i_upda) .or.;
                F_Lnk1_2(),;
                .f.,;
                "w_DACODBEN",;
                space(7)) .and.;
              F_Calc(.f.)
      @ i_posyx1[3,1],i_posyx1[3,2]+i_shx get w_COGN1 picture repl("X",40);
        size i_size1[3,1],i_size1[3,2]+i_shsz;
     disable
      @ i_posyx1[4,1],i_posyx1[4,2]+i_shx get w_ACODBEN picture repl("X",7);
        size i_size1[4,1],i_size1[4,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.t.,.t.);
              ,.t.);
            valid;
              Cplu_zfi(7,"w_ACODBEN") .and.;
              F_aft1_4() .and.;
              F_Check(;
                .not.(updated().or.i_upda) .or.;
                F_Lnk1_4(),;
                .f.,;
                "w_ACODBEN",;
                space(7)) .and.;
              F_Calc(.f.)
      @ i_posyx1[5,1],i_posyx1[5,2]+i_shx get w_COGN2 picture repl("X",40);
        size i_size1[5,1],i_size1[5,2]+i_shsz;
     disable
      @ i_posyx1[6,1],i_posyx1[6,2]+i_shx get w_DATINI;
        size i_size1[6,1],i_size1[6,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_DATINI",;
                ctod("  /  /  ")," Inserire una data dell'anno di competenza") .and.;
              F_Calc(.f.)
      @ i_posyx1[7,1],i_posyx1[7,2]+i_shx get w_DATFIN;
        size i_size1[7,1],i_size1[7,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_DATFIN",;
                ctod("  /  /  ")," Inserire una data dell'anno di competenza o maggiore della data iniziale") .and.;
              F_Calc(.f.)
      @ i_posyx1[12,1],i_posyx1[12,2]+i_shx get w_DATINIP;
        size i_size1[12,1],i_size1[12,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_DATINIP",;
                ctod("  /  /  ")," Inserire una data dell'anno di competenza") .and.;
              F_Calc(.f.)
      @ i_posyx1[13,1],i_posyx1[13,2]+i_shx get w_DATFINP;
        size i_size1[13,1],i_size1[13,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_DATFINP",;
                ctod("  /  /  ")," Inserire una data dell'anno di competenza o maggiore della data iniziale") .and.;
              F_Calc(.f.)
            @ i_posyx1[16,1],i_posyx1[16,2] get i_button picture iif(i_vidgrf,'@*B t_cancel.bmp','@* Annulla');
              size i_size1[16,1],i_size1[16,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Quit");

            @ i_posyx1[17,1],i_posyx1[17,2] get i_button picture iif(i_vidgrf,'@*B t_Ok.bmp','@* Ok');
              size i_size1[17,1],i_size1[17,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Save");

      endcase
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gopa_srx")
      * --- Area Manuale = Func Edit Chkread2
      * --- Fine Area Manuale
    endif
    do case
      * --- Area Manuale = Func Edit Funckeys
      * --- Fine Area Manuale
      case .not. empty(i_todo)
        i_oldop = i_op
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Save"
        i_esci = .f.
        do case
          * --- Area Manuale = Func Edit Confirm
          * --- Fine Area Manuale
          * --- Controllo dei campi obbligatori nelle righe del corpo
          case F_ChkAutoLock()
            i_esci = .t.
            * --- Area Manuale = Func Edit Save
            * --- Fine Area Manuale
        endcase
        if i_esci
          do F_Replace
          * --- Event = Mask Confirmed
          * --- End Event
          * --- Area Manuale = Print Init
          * --- gopa_srx
          do CPI__REP with "GOPA1SRX"
          
          * --- Fine Area Manuale
          * --- Area Manuale = Print End
          * --- gopa_srx
          loop
          * --- Fine Area Manuale
  i_op = OP_QUIT
else
  do F_Paint with 0
endif
      case i_function="Prior" .or. i_function="Next"
        do case
          case i_pag=1
            do case
              case i_campo=1+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[1,1] = 0
do cplu_fsk with "w_DACODBEN","BEN_EFIC",2,"BECODBEN","w_COGN1","BERAGSOC",w_s
              case i_campo=3+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[1,1] = 0
do cplu_fsk with "w_ACODBEN","BEN_EFIC",2,"BECODBEN","w_COGN2","BERAGSOC",w_s
            endcase
        endcase
        do F_Calc with .t.
      case i_function="Delete"
      case i_function="Zoom"
        i_oldop = i_op
        i_op = OP_ZOOM
        do case
          case i_pag=1
            do case
              case i_campo=1+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[1,1] = 0
i_zoompars[1] = 2
i_zoompars[2] = 2
i_zoompars[3] = "Selezione Beneficiario"
do cplu_zom with "BEN_EFIC","BECODBEN","BERAGSOC","1","w_DACODBEN","w_COGN1","GOAR_ABE"
i_zbrow = .not. empty(i_zoomprg)
              case i_campo=3+i_nbtntbar
i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[1,1] = 0
i_zoompars[1] = 2
i_zoompars[2] = 2
i_zoompars[3] = "Selezione Beneficiario"
do cplu_zom with "BEN_EFIC","BECODBEN","BERAGSOC","1","w_ACODBEN","w_COGN2","GOAR_ABE"
i_zbrow = .not. empty(i_zoomprg)
            endcase
        endcase
        if .not. i_zbrow
          do F_Calc with .t.
          i_op = i_oldop
        endif
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
i_op = OP_QUIT
        * --- Event = Mask Rejected
        * --- End Event
    endcase
  enddo
  * --- Area Manuale = Func Edit End
  * --- Fine Area Manuale
  return

function F_aft1_2
  do CPLU_ZER with w_DACODBEN
  return .t.

function F_aft1_4
  do CPLU_ZER with w_ACODBEN
  return .t.

function F_dep
  parameter i_skip,i_zoom
  if _curobj>i_nbtntbar
    i_campo = _curobj
  endif
  i_accpt = .t.
  o_DATCOM = w_DATCOM
  if .not. chrsaw()
    * --- FP3
    #if .not. (left(version(),13)="Visual FoxPro")
      show object 4 disable
      if i_skip
        show object 6 enable
        show object 7 enable
      else
        show object 6 disable
        show object 7 disable
      endif
      if i_zoom
        show object 8 enable
      else
        show object 8 disable
      endif
      if i_pag<>1
        show object 9 enable
      else
        show object 9 disable
      endif
      if i_pag<>1
        show object 10 enable
      else
        show object 10 disable
      endif
    #else
      * --- Parte per FoxPro3
      if i_skip
        oCPToolBar.b7.enabled = .t.
        oCPToolBar.b8.enabled = .t.
      else
        oCPToolBar.b7.enabled = .f.
        oCPToolBar.b8.enabled = .f.
      endif
      if i_zoom
        oCPToolBar.b9.enabled = .t.
      else
        oCPToolBar.b9.enabled = .f.
      endif
    #endif
    * ---
  endif
  * --- Area Manuale = Function Dep
  * --- Fine Area Manuale
  return .t.

function F_calc
  parameter i_upd
  * --- Area Manuale = Func Edit Calc Alws
  * --- Fine Area Manuale
  if updated() .or. i_upd .or. i_upda
    * --- Area Manuale = Func Edit Calc
    * --- Fine Area Manuale
    if o_DATCOM<>w_DATCOM
      w_DATINI = ifcc(w_DATCOM,"I")
    endif
    if o_DATCOM<>w_DATCOM
      w_DATFIN = iif(empty(w_DATCOM),i_DATLAV,ifcc(w_DATCOM,"F"))
    endif
    do Set_Radio
    show gets
  endif
  i_upda = .f.
  return .t.

function F_Lnk1_2
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[1,1] = 0
  do cplu_fld with "w_DACODBEN","BEN_EFIC",2,"BECODBEN","w_COGN1","BERAGSOC",w_s
  return w_s

function F_Lnk1_4
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[1,1] = 0
  do cplu_fld with "w_ACODBEN","BEN_EFIC",2,"BECODBEN","w_COGN2","BERAGSOC",w_s
  return w_s

function Set_Radio
  return .t.

function Get_Radio
  return .t.

function at_x
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(6)
  else
    i_pos = i_pos / fontmetric(6,i_fnt,i_h,i_s)
  endif
  return i_pos

function at_y
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(1)
  else
    i_pos = i_pos / fontmetric(1,i_fnt,i_h,i_s)
  endif
  return i_pos

function F_Check
  parameter i_chk, i_obbl, i_var, i_value, i_msg
  i_accpt = i_chk .and. (.not. i_obbl .or. &i_var<>i_value)
  if .not. i_accpt
    if wontop()<>'BUTTONS'
      _curobj = _curobj
    endif
    if .not.("|"+i_function+"|"$"|Zoom|Prior|Next|")
      do cplu_erm with iif(empty(i_msg),iif(.not.i_chk,w_t_mseerr,w_t_mseobl),i_msg)
    endif
    &i_var = i_value
    if i_function = "Save"
      i_function = ""
    endif
  endif
  return .t.

procedure F_ChkAutoLock
  private i_rsp
  i_rsp = .t.
  return i_rsp

procedure Paint_Pag
  if i_pag>1
    i_pag = 1
    do F_Paint with 0
  else
    do F_Paint with 1
  endif
  return

procedure cplu_pn
  if i_function="Next"
    if .not. eof()
      skip
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    else
      do cplu_erm with w_t_msqefl
      i_loaded = .f.
      i_docreco = 0
    endif
  else
    if .not. bof()
      skip -1
    endif
    if .not. bof()
      i_loaded = .t.
      i_docreco = recno()
    else
      do cplu_erm with w_t_msqsfl
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    endif
  endif
  do F_Read
  do F_Paint with 1
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  return

procedure f_r
  #if left(version(),13)="Visual FoxPro"
  _curobj = _curobj
  #endif
  if .not. found()
    do cplu_erm with w_t_msmnr
    i_loaded = .f.
    i_docreco = 0
  else
    i_docreco = recno()
    i_loaded = .t.
    do F_Read
    do F_Paint with 1
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  clear read
  return

procedure cplu_3d
  parameter i_y,i_x,i_h,i_w,rilievo,fontn,fontp,fonts
  private i_color1,i_color2,i_ww,i_hh,i_olderror
  if parameters()>4 .and. rilievo
    i_color2 =  "rgb(92,92,92,92,92,92)"
    i_color1 =  "rgb(255,255,255,255,255,255)"
  else
    i_color1 =  "rgb(92,92,92,92,92,92)"
    i_color2 =  "rgb(255,255,255,255,255,255)"
  endif
  if parameters()>5
    i_h = i_h*fontmetric(1,fontn,fontp,fonts)/fontmetric(1)
    i_w = i_w*fontmetric(6,fontn,fontp,fonts)/fontmetric(6)
  endif
  i_olderror=on('ERROR')
  on error =.f.
  i_hh = 1/fontmetric(1)
  i_ww = 1/fontmetric(6)
  @ i_y-i_hh,i_x-i_ww     to i_y-i_hh,i_x+i_w+i_ww pen 1 color (i_color1)
  @ i_y-i_hh,i_x-i_ww     to i_y+i_h+i_hh,i_x-i_ww pen 1 color (i_color1)
  @ i_y+i_h+i_hh,i_x-i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  @ i_y-i_hh,i_x+i_w+i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  on error &i_olderror
  return

function cplu_tag
  param p
  i_pag=p
  i_campo = i_nbtntbar+1
  i_function="Repaint"
  return(.t.)

procedure gettab
  param wh,ntab
  private TABSZ,i,cwh,cntab,ci
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ci=alltrim(str(i))
    @ 0.4,TABSZ*(i-1)+1 get i_button size 1,TABSZ-2 pict "@*IT" valid cplu_tag(&ci)
  next
  return

procedure paintcurrtab
  param wh,ntab,ct
  private TABSZ
  TABSZ=min(int(wh/ntab),20)
  ct=ct-1
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  @ 1.5,ct*TABSZ to 1.5,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  @ 1.6,ct*TABSZ to 1.6,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  return

procedure painttab
  param wh,ntab
  private i,TABSZ
  TABSZ=min(int(wh/ntab),20)
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  for i=1 to ntab
    * --- linea orizzontale
    @ 0,(i-1)*TABSZ to 0,i*TABSZ-0.5 color rgb(255,255,255)
    * --- linee vericali
    @ 0,(i-1)*TABSZ to 1.5,(i-1)*TABSZ color rgb(255,255,255)
    @ 0.1,i*TABSZ-0.4 to 1.5,i*TABSZ-0.4
  next
  return

procedure painttabtitle
  param wh,ntab,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10
  private TABSZ,i,ii
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ii=alltrim(str(i))
    @ 0.3,TABSZ*(i-1)+1 say t&ii size 1,TABSZ-2 pict "@I"
  next
  return

* --- Area Manuale = Functions & Procedures
* --- Fine Area Manuale
