* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_brx                                                        *
*              IMPORTAZIONE FATTURA ELETTRONICA                                *
*                                                                              *
*      Author: DIP                                                             *
*      Client: FatturaPA                                                       *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2012-09-13                                                      *
* Last revis.: 2015-09-30                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
* --- Variabili locali
private i_retcode,i_oldarea,w_s,w_multi, i_modal,i_retval
private i_rdvars,i_rdkvars,i_rdkey

store ' ' to i_retcode,w_s,w_multi,i_retval
store .t. to i_modal

dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
private i_wfrec1,i_wford1
i_wfrec1=0
i_wford1=0
private i_wfrec2,i_wford2
i_wfrec2=0
i_wford2=0
private i_wfrec3,i_wford3
i_wfrec3=0
i_wford3=0

private w_IDMEXMIT,w_ReadTag,w_FineTag,w_StringaTAG,w_NomeTAG
private w_TmpTAG,w_CARATTERE,w_DATACHAR,w_PATHARCH,w_FILENAME
private w_CHKDEC,hrl_FILE,w_RECORD,w_FL_COPIA,w_TEST
private w_PATHFILE,w_LEN,w_FILENAME_VISUAL,w_PA_IDSDI,w_PA_IDCOM
private w_TESTMETADATA,w_R,w_PAPROGID,w_FatturaElettronicaHeader,w_DatiTrasmissione
private w_IdTrasmittente,w_PA1111,w_PA1112,w_PA112,w_PA113
private w_PA114,w_ContattiTrasmittente,w_PA1151,w_PA1152,w_CedentePrestatore
private w_DatiAnagrafici,w_IdFiscaleIVA,w_PA12111,w_PA12112,w_PA1212
private w_Anagrafica,w_PA12131,w_PA12132,w_PA12133,w_PA12134
private w_PA12135,w_Sede,w_PA1221,w_PA1222,w_PA1223
private w_PA1224,w_PA1225,w_PA1226,w_Contatti,w_PA1251
private w_PA1252,w_PA1253,w_PA126,w_FatturaElettronicaBody,w_DatiGenerali
private w_DatiGeneraliDocumento,w_PA2111,w_PA2112,w_PA2113,w_PA2114
private w_DatiRitenuta,w_PA21151,w_PA21152,w_PA21153,w_PA21154
private w_PA2119,w_PA21110,w_PA21111,w_PA21112,w_DatiOrdineAcquisto
private w_PA2126,w_PA2127,w_DatiPagamento,w_PA241,w_PA2421
private w_PA2422,w_PA2423,w_PA2424,w_PA2425,w_PA2426
private w_PA2427,w_PA2428,w_PA2429,w_PA24210,w_PA24211
private w_PA24212,w_PA24213,w_PA24214,w_PA24215,w_PA24216
private w_PA24217,w_PA24218,w_PA24219,w_PA24220,w_PA24221

private i_sel_9_1
private i_sel_9_2
private i_sel_9_3

w_IDMEXMIT = space(0)
w_ReadTag = space(0)
w_FineTag = space(0)
w_StringaTAG = space(256)
w_NomeTAG = space(256)
w_TmpTAG = space(256)
w_CARATTERE = space(1)
w_DATACHAR = space(10)
w_PATHARCH = space(254)
w_FILENAME = space(100)
w_CHKDEC = 0
hrl_FILE = space(10)
w_RECORD = space(254)
w_FL_COPIA = space(0)
w_TEST = space(5)
w_PATHFILE = space(254)
w_LEN = 0
w_FILENAME_VISUAL = space(0)
w_PA_IDSDI = space(15)
w_PA_IDCOM = space(15)
w_TESTMETADATA = space(100)
w_R = .f.
w_PAPROGID = 0
w_FatturaElettronicaHeader = .f.
w_DatiTrasmissione = .f.
w_IdTrasmittente = .f.
w_PA1111 = space(2)
w_PA1112 = space(28)
w_PA112 = space(10)
w_PA113 = space(5)
w_PA114 = space(8)
w_ContattiTrasmittente = .f.
w_PA1151 = space(12)
w_PA1152 = space(256)
w_CedentePrestatore = .f.
w_DatiAnagrafici = .f.
w_IdFiscaleIVA = .f.
w_PA12111 = space(2)
w_PA12112 = space(28)
w_PA1212 = space(16)
w_Anagrafica = .f.
w_PA12131 = space(80)
w_PA12132 = space(60)
w_PA12133 = space(60)
w_PA12134 = space(10)
w_PA12135 = space(17)
w_Sede = .f.
w_PA1221 = space(80)
w_PA1222 = space(8)
w_PA1223 = space(5)
w_PA1224 = space(80)
w_PA1225 = space(2)
w_PA1226 = space(2)
w_Contatti = .f.
w_PA1251 = space(12)
w_PA1252 = space(12)
w_PA1253 = space(256)
w_PA126 = space(20)
w_FatturaElettronicaBody = .f.
w_DatiGenerali = .f.
w_DatiGeneraliDocumento = .f.
w_PA2111 = space(4)
w_PA2112 = space(3)
w_PA2113 = ctod("  /  /  ")
w_PA2114 = space(20)
w_DatiRitenuta = .f.
w_PA21151 = space(4)
w_PA21152 = 0
w_PA21153 = 0
w_PA21154 = space(2)
w_PA2119 = 0
w_PA21110 = 0
w_PA21111 = space(0)
w_PA21112 = space(2)
w_DatiOrdineAcquisto = .f.
w_PA2126 = space(254)
w_PA2127 = space(254)
w_DatiPagamento = .f.
w_PA241 = space(4)
w_PA2421 = space(200)
w_PA2422 = space(4)
w_PA2423 = ctod("  /  /  ")
w_PA2424 = 0
w_PA2425 = ctod("  /  /  ")
w_PA2426 = 0
w_PA2427 = space(20)
w_PA2428 = space(60)
w_PA2429 = space(60)
w_PA24210 = space(16)
w_PA24211 = space(10)
w_PA24212 = space(80)
w_PA24213 = space(34)
w_PA24214 = 0
w_PA24215 = 0
w_PA24216 = space(11)
w_PA24217 = 0
w_PA24218 = ctod("  /  /  ")
w_PA24219 = 0
w_PA24220 = ctod("  /  /  ")
w_PA24221 = space(60)

* --- Inizializzazione variabili

i_oldarea = select()

* --- Execute first page
if OpenFiles()
  do gopa1brx
  * --- End
  * --- Area Manuale = End
  * --- Fine Area Manuale
  do CloseFiles
endif

i_warea = alltrim(str(i_oldarea))
select (i_oldarea)

return(i_retval)

* === OpenFiles
function OpenFiles
  private i_ok,i_w1,i_w2,i_w3
  i_ok = .t.
  * --- Apertura dei files
  i_w1 = cplu_opf("TMP_STCE",'')
  i_wfrec1 = i_lastrecno
  i_wford1 = i_lastorder
  i_w2 = cplu_opf("FTPA_XML",'')
  i_wfrec2 = i_lastrecno
  i_wford2 = i_lastorder
  i_w3 = cplu_opf("BEN_EFIC",'')
  i_wfrec3 = i_lastrecno
  i_wford3 = i_lastorder
set exclusive off
  if .not.(i_w1 .and. i_w2 .and. i_w3)
    i_ok = .f.
    do cplu_clf with "TMP_STCE",i_w1,''
    do cplu_clf with "FTPA_XML",i_w2,''
    do cplu_clf with "BEN_EFIC",i_w3,''
  endif
  return i_ok

* === CloseFiles
procedure CloseFiles
  if i_wfrec1<>0
    select ("TMP_STCE")
    do cplu_go with i_wfrec1
    set order to (i_wford1)
  endif
  do cplu_clf with "TMP_STCE",.t.,''
  if i_wfrec2<>0
    select ("FTPA_XML")
    do cplu_go with i_wfrec2
    set order to (i_wford2)
  endif
  do cplu_clf with "FTPA_XML",.t.,''
  if i_wfrec3<>0
    select ("BEN_EFIC")
    do cplu_go with i_wfrec3
    set order to (i_wford3)
  endif
  do cplu_clf with "BEN_EFIC",.t.,''
  return


  procedure gopa1brx
  * === Procedure gopa1brx
    * --- LEGGE FATTURA XML E POLOLA  ANAGRAFICA
    * --- CERCA BENEFICIARIO PER CF E PI, SE NON TROVA PROPONE ELENCO BENEFICIARI PER ASSOCIAZIONE UTENTE ALTRIMENTI PROPONE CENSIMENTO AUTOMATICO OBBLIGATORIO
    * --- SE PRESENTE FILE METADATI VERIFICA CHE SIA ASSOCIATO A QUESTA STESSA FATTURA E MEMORIZZA INFORMAZIONI PER GESTIONE MESSAGGI FUTURI
w_PACODBEN = '@@'
    if empty(w_FILEXML)
      do CPLU_ERM with "Seleziona una Fattura !", 48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    if UPPER(RIGHT(w_FILEXML,3)) <> 'XML' AND UPPER(RIGHT(w_FILEXML,3)) <> 'P7M' 
      do CPLU_ERM with "Tipo File Fattura non previsto, selezionare  *.XML o *.P7M !", 48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    if UPPER(RIGHT(w_FILEMET,3)) <> 'XML' AND !EMPTY(w_FILEMET)
      do CPLU_ERM with "Tipo File Metadati non previsto, selezionare  *.XML !", 48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
hr_FILE = FOPEN(w_FILEXML,0)
    if hr_FILE=-1
      do CPLU_ERM with "Errore nell'apertura del file Fatture ! " + w_FILEXML,48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    do gopa2brx
    if i_retcode='stop'
      return
    endif
    do gopa3brx
    if i_retcode='stop'
      return
    endif
    do gopa6brx
    if i_retcode='stop'
      return
    endif
    do gopa7brx
    if i_retcode='stop'
      return
    endif
    do gopa9brx
    if i_retcode='stop'
      return
    endif
w_PA_IDSDI = ''
w_PA_IDCOM = ''
hr_FILE = FOPEN(w_FILEMET,0)
    if hr_FILE=-1
      do CPLU_ERM with "File Metadati non trovato ! " + w_FILEMET,48
      if i_retcode='stop'
        return
      endif
       do CPLU_DBX with "Non sar� possibile gestire il messaggio di Accettazione/Rifiuto, procedere comunque con l' importazione della Fattura ?" , w_R
      if !w_R
        i_retcode = 'stop'
        return
      endif
    else
      do gopa2brx
      if i_retcode='stop'
        return
      endif
      if EMPTY(w_PA_IDSDI) OR EMPTY(w_PA_IDCOM) OR EMPTY(w_TESTMETADATA)
        do CPLU_ERM with "File metadata non valido !" ,48
        if i_retcode='stop'
          return
        endif
         do CPLU_DBX with "Non sar� possibile gestire il messaggio di Accettazione/Rifiuto, procedere comunque con l' importazione della Fattura ?" , w_R
        if !w_R
          i_retcode = 'stop'
          return
        endif
w_PA_IDSDI = ''
w_PA_IDCOM = ''
      else
        if ATC(w_TESTMETADATA,upper(w_FILEXML)) = 0 
          do CPLU_ERM with "File metadata non relativo a questa Fattura !", 48
          if i_retcode='stop'
            return
          endif
           do CPLU_DBX with "Non sar� possibile gestire il messaggio di Accettazione/Rifiuto, procedere comunque con l' importazione della Fattura ?" , w_R
          if !w_R
            i_retcode = 'stop'
            return
          endif
w_PA_IDSDI = ''
w_PA_IDCOM = ''
        endif
      endif
      * --- ARCHIVIAZIONE MESSAGGIO
       m_CMD = 'copy file "'+alltrim(w_FILEMET)+'" to ' + alltrim(w_PATHARCH) + JUSTFNAME(w_FILEMET)
&m_CMD 
w_FILENAME = alltrim(w_PATHARCH) + JUSTFNAME(w_FILEMET)
    endif
    do gopa8brx
    if i_retcode='stop'
      return
    endif
    do CPLU_ERM with "Importazione Effettuata !"
    if i_retcode='stop'
      return
    endif
    return

  procedure gopa2brx
  * === Procedure gopa2brx
    * --- Ciclo il file ed estraggo tutte le righe
    * --- Apertura File
w_ReadTag = .F.
w_FineTag = .F.
w_StringaTAG = ""
w_NomeTAG = ""
w_TmpTAG = ""
    do while not FEOF(hr_FILE)
w_CARATTERE = chkc(FREAD(hr_FILE,1))
      if Asc(w_CARATTERE)=13 or Asc(w_CARATTERE)=10
        * --- Ingnoro eventuali caratteri CR o LF
         loop
      endif
      if w_CARATTERE='<' or w_ReadTAG
w_ReadTag = .T.
w_TmpTAG = w_TmpTAG + w_CARATTERE
        if w_CARATTERE='>'
          * --- controllo presenza attributi di visualizzazione
w_POS = ATC('xmlns', w_TmpTag)
          if w_POS >0 
w_TmpTAG = LEFT(w_TmpTAG,w_POS-2) + '>'
          endif
w_ReadTag = .F.
w_NomeTAG = w_TmpTAG
          if LEFT(w_NomeTAG,2)=='</'
w_StringaTAG = alltrim(w_StringaTAG)
            do gopa4brx
            if i_retcode='stop'
              return
            endif
            do gopa5brx
            if i_retcode='stop'
              return
            endif
          else
            do gopa5brx
            if i_retcode='stop'
              return
            endif
          endif
w_StringaTAG = ""
w_TmpTAG = ""
w_NomeTAG = ""
        endif
      else
w_StringaTAG = w_StringaTAG + w_CARATTERE
      endif
    enddo
    * --- Chiude file
    if hr_FILE>0
x_CLOSE = FCLOSE(hr_FILE)
      if .not. x_CLOSE
        do CPLU_ERM with "Errore nella chisura del file !",48
        if i_retcode='stop'
          return
        endif
        i_retcode = 'stop'
        return
      endif
    endif
    return

  procedure gopa3brx
  * === Procedure gopa3brx
    * --- verifico la chiave
w_KEY = ALLTRIM(w_PA1111)+ALLTRIM(w_PA1112) + ALLTRIM(w_PA112)
    if EMPTY(w_PA1111) OR EMPTY(w_PA1112) OR EMPTY(w_PA112)
      do CPLU_ERM with "File non valido, importazione annullata !",48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
w_PAPROGID = 0
    * --- Read from FTPA_XML
    select FTPA_XML
    w_s = iif(eof(),-1,recno())
    seek w_KEY
    if found()
      w_PAPROGID = PAPROGID
    endif
    do cplu_go with w_s
    select &i_warea
    if !EMPTY(w_PAPROGID) OR w_PAPROGID > 0
      do CPLU_ERM with "Fattura gi� importata ! " + chr(13) + "Numero progressivo: " + alltrim(str(w_PAPROGID)),48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    return

  procedure gopa4brx
  * === Procedure gopa4brx
    do case
      case w_FatturaElettronicaHeader AND w_DatiTrasmissione
        do case
          case w_IdTrasmittente
            do case
              case w_NomeTAG=='</IdPaese>'
w_PA1111 = w_StringaTAG
              case w_NomeTAG=='</IdCodice>'
w_PA1112 = w_StringaTAG
            endcase
          case w_NomeTAG=='</ProgressivoInvio>'
w_PA112 = w_StringaTAG
          case w_NomeTAG=='</FormatoTrasmissione>'
w_PA113 = w_StringaTAG
          case w_NomeTAG=='</CodiceDestinatario>'
w_PA114 = w_StringaTAG
          case w_ContattiTrasmittente
            do case
              case w_NomeTAG=='</Telefono>'
w_PA1151 = w_StringaTAG
              case w_NomeTAG=='</Email>'
w_PA1152 = w_StringaTAG
            endcase
        endcase
      case w_FatturaElettronicaHeader AND w_CedentePrestatore
        do case
          case w_DatiAnagrafici
            do case
              case w_IdFiscaleIVA
                do case
                  case w_NomeTAG=='</IdPaese>'
w_PA12111 = w_StringaTAG
                  case w_NomeTAG=='</IdCodice>'
w_PA12112 = w_StringaTAG
                endcase
              case w_NomeTAG=='</CodiceFiscale>'
w_PA1212 = w_StringaTAG
              case w_Anagrafica
                do case
                  case w_NomeTAG=='</Denominazione>'
w_PA12131 = w_StringaTAG
                  case w_NomeTAG=='</Nome>'
w_PA12132 = w_StringaTAG
                  case w_NomeTAG=='</Cognome>'
w_PA12133 = w_StringaTAG
                  case w_NomeTAG=='</Titolo>'
w_PA12134 = w_StringaTAG
                  case w_NomeTAG=='</CodEORI>'
w_PA12135 = w_StringaTAG
                endcase
            endcase
          case w_Sede
            do case
              case w_NomeTAG=='</Indirizzo>'
w_PA1221 = w_StringaTAG
              case w_NomeTAG=='</NumeroCivico>'
w_PA1222 = w_StringaTAG
              case w_NomeTAG=='</CAP>'
w_PA1223 = w_StringaTAG
              case w_NomeTAG=='</Comune>'
w_PA1224 = w_StringaTAG
              case w_NomeTAG=='</Provincia>'
w_PA1225 = w_StringaTAG
              case w_NomeTAG=='</Nazione>'
w_PA1226 = w_StringaTAG
            endcase
          case w_Contatti
            do case
              case w_NomeTAG=='</Telefono>'
w_PA1251 = w_StringaTAG
              case w_NomeTAG=='</Fax>'
w_PA1252 = w_StringaTAG
              case w_NomeTAG=='</Email>'
w_PA1253 = w_StringaTAG
            endcase
          case w_NomeTAG=='</RiferimentoAmministrazione>'
w_PA126 = w_StringaTAG
        endcase
      case w_FatturaElettronicaBody AND w_DatiGenerali
        do case
          case w_DatiGeneraliDocumento
            do case
              case w_NomeTAG=='</TipoDocumento>'
w_PA2111 = w_StringaTAG
              case w_NomeTAG=='</Divisa>'
w_PA2112 = w_StringaTAG
              case w_NomeTAG=='</Data>'
w_DATACHAR = substr(w_StringaTAG,9,2) + '/' +  substr(w_StringaTAG,6,2) + '/' + left(w_StringaTAG,4)
w_PA2113 = CTOD(w_DATACHAR)
              case w_NomeTAG=='</Numero>'
w_PA2114 = w_StringaTAG
              case w_DatiRitenuta
                do case
                  case w_NomeTAG=='</TipoRitenuta>'
w_PA21151 = w_StringaTAG
                  case w_NomeTAG=='</ImportoRitenuta>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
                    if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
                    endif
w_PA21152 = val(w_StringaTAG) + w_CHKDEC
                  case w_NomeTAG=='</AliquotaRitenuta>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
                    if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
                    endif
w_PA21153 = val(w_StringaTAG) + w_CHKDEC
                  case w_NomeTAG=='</CausalePagamento>'
w_PA21154 = w_StringaTAG
                endcase
              case w_NomeTAG=='</ImportoTotaleDocumento>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
                if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
                endif
w_PA2119 = val(w_StringaTAG) + w_CHKDEC
              case w_NomeTAG=='</Arrotondamento>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
                if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
                endif
w_PA21110 = val(w_StringaTAG) + w_CHKDEC
              case w_NomeTAG=='</Causale>'
w_PA21111 = ALLTRIM(NVL(w_PA21111,'')) + ' ' + w_StringaTAG
              case w_NomeTAG=='</Art73>'
w_PA21112 = w_StringaTAG
            endcase
          case w_DatiOrdineAcquisto
            do case
              case w_NomeTAG=='</CodiceCUP>'
w_PA2126 = ALLTRIM(NVL(w_PA2126,'')) + ' ' + w_StringaTAG
              case w_NomeTAG=='</CodiceCIG>'
w_PA2127 = ALLTRIM(NVL(w_PA2127,'')) + ' ' + w_StringaTAG
            endcase
        endcase
      case w_FatturaElettronicaBody AND w_DatiPagamento
        do case
          case w_NomeTAG=='</CondizioniPagamento>'
w_PA241 = w_StringaTAG
          case w_NomeTAG=='</Beneficiario>'
w_PA2421 = w_StringaTAG
          case w_NomeTAG=='</ModalitaPagamento>'
w_PA2422 = w_StringaTAG
          case w_NomeTAG=='</DatiRiferimentoTerminiPagamento>'
w_DATACHAR = substr(w_StringaTAG,9,2) + '/' +  substr(w_StringaTAG,6,2) + '/' + left(w_StringaTAG,4)
w_PA2423 = CTOD(w_DATACHAR)
          case w_NomeTAG=='</GiorniTerminiPagamento>'
w_PA2424 = val(w_StringaTAG)
          case w_NomeTAG=='</DataScadenzaPagamento>'
w_DATACHAR = substr(w_StringaTAG,9,2) + '/' +  substr(w_StringaTAG,6,2) + '/' + left(w_StringaTAG,4)
w_PA2425 = CTOD(w_DATACHAR)
          case w_NomeTAG=='</ImportoPagamento>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
            if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
            endif
w_PA2426 = val(w_StringaTAG) + w_CHKDEC
          case w_NomeTAG=='</CodiceUfficioPostale>'
w_PA2427 = w_StringaTAG
          case w_NomeTAG=='</CognomeQuietanzante>'
w_PA2428 = w_StringaTAG
          case w_NomeTAG=='</NomeQuietanzante>'
w_PA2429 = w_StringaTAG
          case w_NomeTAG=='</CfQuietanzante>'
w_PA24210 = w_StringaTAG
          case w_NomeTAG=='</TitoloQuietanzante>'
w_PA24211 = w_StringaTAG
          case w_NomeTAG=='</IstitutoFinanziario>'
w_PA24212 = w_StringaTAG
          case w_NomeTAG=='</IBAN>'
w_PA24213 = w_StringaTAG
          case w_NomeTAG=='</ABI>'
w_PA24214 = val(w_StringaTAG)
          case w_NomeTAG=='</CAB>'
w_PA24215 = val(w_StringaTAG)
          case w_NomeTAG=='</BIC>'
w_PA24216 = w_StringaTAG
          case w_NomeTAG=='</ScontoPagamentoAnticipato>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
            if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
            endif
w_PA24217 = val(w_StringaTAG) + w_CHKDEC
          case w_NomeTAG=='</DataLimitePagamentoAnticipato>'
w_DATACHAR = substr(w_StringaTAG,9,2) + '/' +  substr(w_StringaTAG,6,2) + '/' + left(w_StringaTAG,4)
w_PA24218 = CTOD(w_DATACHAR)
          case w_NomeTAG=='</PenalitaPagamentiRitardati>'
w_CHKDEC = val(RIGHT(w_StringaTAG,2))
            if w_CHKDEC >0
w_CHKDEC = w_CHKDEC/100
            endif
w_PA24219 = val(w_StringaTAG) + w_CHKDEC
          case w_NomeTAG=='</DataDecorrenzaPenale>'
w_DATACHAR = substr(w_StringaTAG,9,2) + '/' +  substr(w_StringaTAG,6,2) + '/' + left(w_StringaTAG,4)
w_PA24220 = CTOD(w_DATACHAR)
          case w_NomeTAG=='</CodicePagamento>'
w_PA24221 = w_StringaTAG
        endcase
      case !w_FatturaElettronicaHeader AND !w_FatturaElettronicaBody
        * --- VERIFICA FILE MESSAGGIO METADATA
        do case
          case w_NomeTAG=='</IdentificativoSdI>'
w_PA_IDSDI = w_StringaTAG
          case w_NomeTAG=='</MessageId>'
w_PA_IDCOM = w_StringaTAG
          case w_NomeTAG=='</NomeFile>'
w_TESTMETADATA = w_StringaTAG
        endcase
    endcase
    return

  procedure gopa5brx
  * === Procedure gopa5brx
    do case
      case w_NomeTAG=='<FatturaElettronicaHeader>'
w_FatturaElettronicaHeader = .T.
      case w_NomeTAG=='</FatturaElettronicaHeader>'
w_FatturaElettronicaHeader = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiTrasmissione>'
w_DatiTrasmissione = .T.
      case w_NomeTAG=='</DatiTrasmissione>'
w_DatiTrasmissione = .F.
    endcase
    do case
      case w_NomeTAG=='<IdTrasmittente>'
w_IdTrasmittente = .T.
      case w_NomeTAG=='</IdTrasmittente>'
w_IdTrasmittente = .F.
    endcase
    do case
      case w_NomeTAG=='<ContattiTrasmittente>'
w_ContattiTrasmittente = .T.
      case w_NomeTAG=='</ContattiTrasmittente>'
w_ContattiTrasmittente = .F.
    endcase
    do case
      case w_NomeTAG=='<CedentePrestatore>'
w_CedentePrestatore = .T.
      case w_NomeTAG=='</CedentePrestatore>'
w_CedentePrestatore = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiAnagrafici>'
w_DatiAnagrafici = .T.
      case w_NomeTAG=='</DatiAnagrafici>'
w_DatiAnagrafici = .F.
    endcase
    do case
      case w_NomeTAG=='<IdFiscaleIVA>'
w_IdFiscaleIVA = .T.
      case w_NomeTAG=='</IdFiscaleIVA>'
w_IdFiscaleIVA = .F.
    endcase
    do case
      case w_NomeTAG=='<Anagrafica>'
w_Anagrafica = .T.
      case w_NomeTAG=='</Anagrafica>'
w_Anagrafica = .F.
    endcase
    do case
      case w_NomeTAG=='<Sede>'
w_Sede = .T.
      case w_NomeTAG=='</Sede>'
w_Sede = .F.
    endcase
    do case
      case w_NomeTAG=='<Contatti>'
w_Contatti = .T.
      case w_NomeTAG=='</Contatti>'
w_Contatti = .F.
    endcase
    do case
      case w_NomeTAG=='<RiferimentoAmministrazione>'
w_RiferimentoAmministrazione = .T.
      case w_NomeTAG=='</RiferimentoAmministrazione>'
w_RiferimentoAmministrazione = .F.
    endcase
    do case
      case w_NomeTAG=='<FatturaElettronicaBody>'
w_FatturaElettronicaBody = .T.
      case w_NomeTAG=='</FatturaElettronicaBody>'
w_FatturaElettronicaBody = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiGenerali>'
w_DatiGenerali = .T.
      case w_NomeTAG=='</DatiGenerali>'
w_DatiGenerali = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiGeneraliDocumento>'
w_DatiGeneraliDocumento = .T.
      case w_NomeTAG=='</DatiGeneraliDocumento>'
w_DatiGeneraliDocumento = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiRitenuta>'
w_DatiRitenuta = .T.
      case w_NomeTAG=='</DatiRitenuta>'
w_DatiRitenuta = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiPagamento>'
w_DatiPagamento = .T.
      case w_NomeTAG=='</DatiPagamento>'
w_DatiPagamento = .F.
    endcase
    do case
      case w_NomeTAG=='<DatiOrdineAcquisto>'
w_DatiOrdineAcquisto = .T.
      case w_NomeTAG=='</DatiOrdineAcquisto>'
w_DatiOrdineAcquisto = .F.
    endcase
    return

  procedure gopa6brx
  * === Procedure gopa6brx
    * --- Verifico l'esistenza della cartella 
w_PATHARCH = addbs(sys(5)+sys(2003))+"FTPA\" + UPPER(alltrim(i_codazi)) + '\'
    if !Directory(w_PATHARCH)
       md &w_PATHARCH
    endif
     m_CMD = 'copy file "'+alltrim(w_FILEXML)+'" to ' + alltrim(w_PATHARCH) + JUSTFNAME(w_FILEXML)
&m_CMD 
w_FILENAME = alltrim(w_PATHARCH) + JUSTFNAME(w_FILEXML)
    return

  procedure gopa7brx
  * === Procedure gopa7brx
hr_FILE = 0
hr_FILE = FOPEN(w_FILEXML,0)
    if hr_FILE=-1
      do CPLU_ERM with "Creazione visualizzazione, Errore nell'apertura del file  !" + w_FILEXML,48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
w_FL_COPIA = .F.
w_OK = .F.
    do while not FEOF(hr_FILE)
      * --- GIA - Impostato numero caratteri a 8192 in quanto � il valore massimo accettato da VisualFoxPro 6
w_RECORD = CHKR(FGETS(hr_FILE,8192))
x_r = 1
      if w_FL_COPIA
        if LEFT(w_RECORD,23) = '</p:FatturaElettronica>' OR LEFT(w_RECORD,21) = '</FatturaElettronica>'
          if LEFT(w_RECORD,3) = '</p'
x_r = FWRITE(hrl_FILE,'</p:FatturaElettronica>' + chr(10) )
          else
x_r = FWRITE(hrl_FILE,'</FatturaElettronica>' + chr(10) )
          endif
           EXIT
        else
x_r = FWRITE(hrl_FILE,w_RECORD + chr(10))
        endif
      else
w_POS = ATC('<?xml version', w_RECORD)
        if w_POS >0 
w_LEN = LEN(ALLTRIM(w_RECORD))
w_POSF = w_POS-1
w_FINET = ATC('>', SUBSTR(w_RECORD,w_POS,w_LEN-w_POSF))
w_POS = w_POS+w_FINET
w_POSF = ATC('/FatturaElettronica>',w_RECORD) 
          if w_POSF=0
w_POSF = ATC(':FatturaElettronica>',w_RECORD) 
          endif
          if w_POSF  > 0
w_LENF = w_POSF+20-(w_POS)
w_RECORD = '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="fatturapa_v1.1.xsl"?>' + SUBSTR(w_RECORD,w_POS ,w_LENF)
w_OK = .T.
          else
w_RECORD = '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="fatturapa_v1.1.xsl"?>' + SUBSTR(w_RECORD,w_POS ,w_LEN)
w_FL_COPIA = .T.
          endif
w_PATHFILE = addbs(sys(5)+sys(2003))+"FTPA\" + UPPER(alltrim(i_codazi)) + '\VSFT\' 
          if !Directory(w_PATHFILE)
             md &w_PATHFILE
          endif
          if UPPER(RIGHT(JUSTFNAME(w_FILEXML),4)) = '.P7M'
w_LEN = LEN(JUSTFNAME(w_FILEXML)) - 4
w_FILENAME_VISUAL =  LEFT(JUSTFNAME(w_FILEXML),w_LEN)
          else
w_FILENAME_VISUAL = JUSTFNAME(w_FILEXML)
          endif
w_PATHFILE = addbs(sys(5)+sys(2003))+"FTPA\" + UPPER(alltrim(i_codazi)) + '\VSFT\' + w_FILENAME_VISUAL
hrl_FILE = FCREATE(w_PATHFILE)
          if hrL_FILE=-1
            do CPLU_ERM with "Errore nella creazione del file di visualizzazione !",48
            if i_retcode='stop'
              return
            endif
             return
          endif
w_FILE_STYLE = addbs(sys(5)+sys(2003))+"FTPA\" + UPPER(alltrim(i_codazi)) + '\VSFT\fatturapa_v1.1.xsl'
hr_stf = 0
hr_stf = FOPEN(w_FILE_STYLE,0)
          if hr_stf=-1
w_PATH_ST = addbs(sys(5)+sys(2003))+"fatturapa_v1.1.xsl"
hr_stf = 0
hr_stf = FOPEN(w_PATH_ST,0)
            if hr_stf=-1
              do CPLU_ERM with "File di stile fatturapa_v1.1.xsl per visualizzazione documenti non trovato!",48
              if i_retcode='stop'
                return
              endif
            else
x_CLOSE = FCLOSE(hr_stf)
               m_CMD = 'copy file "'+w_PATH_ST+'" to ' + w_FILE_STYLE
&m_CMD 
            endif
          else
x_CLOSE = FCLOSE(hr_stf)
          endif
x_r = FWRITE(hrl_FILE,w_RECORD + chr(10) )
        endif
      endif
      if x_r = 0
        do CPLU_ERM with "Errore nella scrittura del record !",48
        if i_retcode='stop'
          return
        endif
         return
      endif
    enddo
    * --- Chiude file
    if hr_FILE>0
x_CLOSE = FCLOSE(hr_FILE)
      if .not. x_CLOSE
        do CPLU_ERM with "Errore nella chisura del file !",48
        if i_retcode='stop'
          return
        endif
        i_retcode = 'stop'
        return
      endif
    endif
    if !w_FL_COPIA AND !w_OK
      do CPLU_ERM with "Errore di gestione del file di visualizzazione !",48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    else
      if hrl_FILE>0
x_CLOSE = FCLOSE(hrl_FILE)
        if .not. x_CLOSE
          do CPLU_ERM with "Errore di chiusura del file di visualizzazione !",48
          if i_retcode='stop'
            return
          endif
          i_retcode = 'stop'
          return
        endif
      endif
    endif
    return

  procedure gopa8brx
  * === Procedure gopa8brx
    * --- IMPOSTA PROGRESSIVO FATTURA
w_NUMPRO = 0
    do CPLU_DPR with "PFTPA", "   ", "NUMPRO", "w_NUMPRO" , " ", i_DATLAV
    if i_retcode='stop'
      return
    endif
    * --- Inserisco i dati in tabella
     select FTPA_XML
     append blank
    * --- Write into FTPA_XML
    select FTPA_XML
    w_s = iif(eof(),-1,recno())
      do cplu_wlk with 'File FTPA_XML'
replace PA113 with w_PA113
replace PA1111 with w_PA1111
replace PA1112 with w_PA1112
replace PA112 with w_PA112
replace PA114 with w_PA114
replace PA1151 with w_PA1151
replace PA1152 with w_PA1152
replace PA12111 with w_PA12111
replace PA12112 with w_PA12112
replace PA1212 with w_PA1212
replace PA12131 with w_PA12131
replace PA12132 with w_PA12132
replace PA12133 with w_PA12133
replace PA12134 with w_PA12134
replace PA12135 with w_PA12135
replace PA1221 with w_PA1221
replace PA1222 with w_PA1222
replace PA1223 with w_PA1223
replace PA1224 with w_PA1224
replace PA1225 with w_PA1225
replace PA1226 with w_PA1226
replace PA1251 with w_PA1251
       unlock
    do cplu_go with w_s
    select &i_warea
    * --- Write into FTPA_XML
    select FTPA_XML
    w_s = iif(eof(),-1,recno())
      do cplu_wlk with 'File FTPA_XML'
replace PA1252 with w_PA1252
replace PA1253 with w_PA1253
replace PA126 with w_PA126
replace PA2111 with w_PA2111
replace PA2112 with w_PA2112
replace PA2113 with w_PA2113
replace PA2114 with w_PA2114
replace PA2119 with w_PA2119
replace PA2126 with w_PA2126
replace PA2127 with w_PA2127
replace PA21110 with w_PA21110
replace PA21111 with w_PA21111
replace PA21112 with w_PA21112
replace PA21151 with w_PA21151
replace PA21152 with w_PA21152
replace PA21153 with w_PA21153
replace PA21154 with w_PA21154
replace PA241 with w_PA241
replace PA2421 with w_PA2421
replace PA2422 with w_PA2422
replace PA2423 with w_PA2423
replace PA2424 with w_PA2424
replace PA2425 with w_PA2425
replace PA2426 with w_PA2426
replace PA2427 with w_PA2427
replace PA2428 with w_PA2428
       unlock
    do cplu_go with w_s
    select &i_warea
    * --- Write into FTPA_XML
    select FTPA_XML
    w_s = iif(eof(),-1,recno())
      do cplu_wlk with 'File FTPA_XML'
replace PA2429 with w_PA2429
replace PA24210 with w_PA24210
replace PA24211 with w_PA24211
replace PA24212 with w_PA24212
replace PA24213 with w_PA24213
replace PA24214 with w_PA24214
replace PA24215 with w_PA24215
replace PA24216 with w_PA24216
replace PA24217 with w_PA24217
replace PA24218 with w_PA24218
replace PA24219 with w_PA24219
replace PA24220 with w_PA24220
replace PA24221 with w_PA24221
replace PAPATHFL with w_FILENAME_VISUAL
replace PAPROGID with w_NUMPRO
replace PACODBEN with w_PACODBEN
replace PA_IDCOM with w_PA_IDCOM
replace PA_IDSDI with w_PA_IDSDI
       unlock
    do cplu_go with w_s
    select &i_warea
    do CPLU_FPR with "PFTPA", "   ", "NUMPRO", "w_NUMPRO" , " ", i_DATLAV
    if i_retcode='stop'
      return
    endif
    return

  procedure gopa9brx
  * === Procedure gopa9brx
    * --- VERIFICA CODICE BENEFICIARIO COFIN
w_PACODBEN = '@@'
w_PARIVA = w_PA12112
w_CODFIS = w_PA1212
    if not empty(w_PARIVA)
      * --- Select from BEN_EFIC
      i_sel_9_1 = i_warea
      i_warea = "BEN_EFIC"
      select BEN_EFIC
      set order to 3
      goto top
      seek ALLTRIM(w_PARIVA)
      if .not. empty(key(1))
        set order to 1
      endif
      w_s = .f.
      do while .not. eof()  .and. (ALLTRIM(BEPARIVA)=ALLTRIM(w_PARIVA))
        set order to 3
        if w_s
          skip
        endif
      if .not. empty(key(1))
        set order to 1
      endif
        if .not. eof() .and. (ALLTRIM(BEPARIVA)=ALLTRIM(w_PARIVA))
w_PACODBEN = BECODBEN
        endif
        w_s = .t.
      enddo
      i_warea = i_sel_9_1
      select &i_warea
    endif
    if w_PACODBEN= '@@'
      if not empty(w_CODFIS)
        * --- Select from BEN_EFIC
        i_sel_9_2 = i_warea
        i_warea = "BEN_EFIC"
        select BEN_EFIC
        set order to 4
        goto top
        seek ALLTRIM(w_CODFIS)
        if .not. empty(key(1))
          set order to 1
        endif
        w_s = .f.
        do while .not. eof()  .and. (ALLTRIM(BECODFIS)=ALLTRIM(w_CODFIS))
          set order to 4
          if w_s
            skip
          endif
        if .not. empty(key(1))
          set order to 1
        endif
          if .not. eof() .and. (ALLTRIM(BECODFIS)=ALLTRIM(w_CODFIS))
w_PACODBEN = BECODBEN
          endif
          w_s = .t.
        enddo
        i_warea = i_sel_9_2
        select &i_warea
      endif
    endif
    if w_PACODBEN='@@'
      do CPLU_ERM with "Attenzione fornitore: "+iif(empty(w_PA12131), Alltrim(w_PA12133)+" "+Alltrim(w_PA12132), Alltrim(w_PA12131))+" non trovato nell'archivio beneficiari."+chr(13)+"Verr� visualizzato la visualizzazione dei beneficiari, selezionare il beneficiario con cui associare la fattura oppure uscire (Esc) dalla visualizzazione per crearlo."
      if i_retcode='stop'
        return
      endif
      * --- CARICA ZOOM BENEFICIARI
w_BERAGSOC = ''
       i_rdkey = ""
i_rdkvars[1,1] = 0
i_rdvars[1,1] = 0
i_zoompars[1] = 4
i_zoompars[2] = 2
i_zoompars[3] = "BENEFICIARI"
do cplu_zom with "BEN_EFIC","BECODBEN","BERAGSOC","1","w_PACODBEN","w_BERAGSOC","GOAR_ABE"
      if w_PACODBEN<>'@@'
         do CPLU_DBX with "Confermi associazione del fornitore : " + alltrim(w_PA12131) + " con il Beneficiario : " + ALLTRIM(w_BERAGSOC) + " ?" , w_R
        if !w_R
w_PACODBEN = '@@'
        else
          * --- Write into BEN_EFIC
          select BEN_EFIC
          w_s = iif(eof(),-1,recno())
          seek w_PACODBEN
          if found()
            do cplu_wlk with 'File BEN_EFIC'
replace BEPARIVA with w_PA12112
replace BECODFIS with w_PA1212
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
        endif
      endif
    endif
    if w_PACODBEN='@@'
      * --- SE BENEFICIARIO NON TROVATO PROPONGO IL CARICAMENTO IN ANAGRAFICA
w_R = .F.
       do CPLU_DBX with "Beneficiario non trovato. Eseguo caricamento automatico ?", w_R
      if w_R
        * --- verifica ultimo codice progressivo usato
        * --- Select from BEN_EFIC
        i_sel_9_3 = i_warea
        i_warea = "BEN_EFIC"
        select BEN_EFIC
        set order to 1
        goto top
        if .not. empty(key(1))
          set order to 1
        endif
        w_s = .f.
        do while .not. eof() 
          set order to 1
          if w_s
            skip
          endif
        if .not. empty(key(1))
          set order to 1
        endif
          if .not. eof() 
w_PACODBEN = BECODBEN
          endif
          w_s = .t.
        enddo
        i_warea = i_sel_9_3
        select &i_warea
w_PACODBEN = ALLTRIM(STR(VAL(w_PACODBEN)+1,6,0))
w_PACODBEN = RIGHT('0000000' +w_PACODBEN,7)
w_INDIRIZZO = ALLTRIM(w_PA1221) + '   ' + ALLTRIM(w_PA1222)
        if empty(ALLTRIM(NVL(w_PA12131,'')))
w_RAGSOC = ALLTRIM(w_PA12132) + '  ' + ALLTRIM(w_PA12133)
        else
w_RAGSOC = ALLTRIM(w_PA12131)
        endif
         select BEN_EFIC
         append blank
        * --- Write into BEN_EFIC
        select BEN_EFIC
        w_s = iif(eof(),-1,recno())
          do cplu_wlk with 'File BEN_EFIC'
replace BECODBEN with w_PACODBEN
replace BERAGSOC with w_RAGSOC
replace BEINDIRI with w_INDIRIZZO
replace BE___CAP with w_PA1223
replace BELOCALI with w_PA1224
replace BEPROVIN with w_PA1225
replace BENAZION with w_PA1226
replace BETELEFO with w_PA1251
replace BETELFAX with w_PA1252
replace BECODFIS with w_PA1212
replace BEPARIVA with w_PA12112
replace BE_EMAIL with w_PA1253
replace BE__IBAN with w_PA24213
           unlock
        do cplu_go with w_s
        select &i_warea
      else
        do CPLU_ERM with "Beneficiario non generato. Impossibile acquisire il documento !",48
        if i_retcode='stop'
          return
        endif
        i_retcode = 'stop'
        return
      endif
    endif
    * --- CONTROLLO SE FATTURA CARICATA DA CARTACEO
     SELECT FTPA_XML
     GO TOP
     SET ORDER TO 5
     SEEK ALLTRIM(w_PACODBEN) + DTOC(w_PA2113) + ALLTRIM(w_PA2114)
    if found()
      do CPLU_ERM with "Fattura gi� importata ! " + chr(13) + "Numero progressivo: " + alltrim(str(PAPROGID)),48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    return

  procedure gopa10brx
  * === Procedure gopa10brx
    * --- Apertura File
hr_FILE = FOPEN(w_FILEMET,0)
    if hr_FILE=-1
      do CPLU_ERM with "Errore apertura file metadati !",48
      if i_retcode='stop'
        return
      endif
    endif
w_ReadTag = .F.
w_FineTag = .F.
w_StringaTAG = ""
w_NomeTAG = ""
w_TmpTAG = ""
    do while not FEOF(hr_FILE)
w_CARATTERE = chkc(FREAD(hr_FILE,1))
      if Asc(w_CARATTERE)=13 or Asc(w_CARATTERE)=10
        * --- Ingnoro eventuali caratteri CR o LF
         loop
      endif
      if w_CARATTERE='<' or w_ReadTAG
w_ReadTag = .T.
w_TmpTAG = w_TmpTAG + w_CARATTERE
        if w_CARATTERE='>'
          * --- controllo presenza attributi di visualizzazione
w_POS = ATC('xmlns', w_TmpTag)
          if w_POS >0 
w_TmpTAG = LEFT(w_TmpTAG,w_POS-2) + '>'
          endif
w_ReadTag = .F.
w_NomeTAG = w_TmpTAG
          if LEFT(w_NomeTAG,2)=='</'
w_StringaTAG = alltrim(w_StringaTAG)
            do case
              case w_NomeTAG=='</IdentificativoSdI>'
w_PA_IDSDI = w_StringaTAG
              case w_NomeTAG=='</MessageId>'
w_PA_IDCOM = w_StringaTAG
            endcase
          endif
w_StringaTAG = ""
w_TmpTAG = ""
w_NomeTAG = ""
        endif
      else
w_StringaTAG = w_StringaTAG + w_CARATTERE
      endif
    enddo
    * --- Chiude file
    if hr_FILE>0
x_CLOSE = FCLOSE(hr_FILE)
      if .not. x_CLOSE
        do CPLU_ERM with "Errore nella chisura del file !",48
        if i_retcode='stop'
          return
        endif
        i_retcode = 'stop'
        return
      endif
    endif
    return


* --- Area Manuale = Functions & Procedures
* --- gopa_brx
* Funzione di controllo del singolo carattere
Function CHKC()
Parameter p_Valore
Private p_Ret
p_Ret = ""
if p_Valore$"0123456789 \|!'�$%&/()=?^[]+*@#-_.:,;<>abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" or p_Valore='"'
  p_Ret = p_Valore
else
  p_Ret = ''
endif
Return (p_Ret)

* Funzione di controllo dei caratteri per record
Function CHKR()
Parameter p_Valore
Private p_Ret
p_Ret = ""
p_Valore = alltrim(p_Valore)
for x = 1 to len(p_Valore)
  if substr(p_Valore,x,1)$"0123456789 \|!'�$%&/()=?^[]+*@#-_.:,;<>abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" or substr(p_Valore,x,1)='"'
    p_Ret = p_Ret + substr(p_Valore,x,1)
	else
   *p_Ret = p_Ret + CODIVAL(asc(substr(p_Valore,x,1)))
	endifnext x
Return (p_Ret)


* --- Fine Area Manuale

