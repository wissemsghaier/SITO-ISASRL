parameter pOper,w_PA1111,w_PA1112,w_PA112
* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_bfs                                                        *
*              FUNZIONI DI SERVIZIO FATTURA ELETTRONICA                        *
*                                                                              *
*      Author: DIP                                                             *
*      Client: FatturaPA                                                       *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2012-09-13                                                      *
* Last revis.: 2015-09-30                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
* --- Variabili locali
private i_retcode,i_oldarea,w_s,w_multi, i_modal,i_retval
private i_rdvars,i_rdkvars,i_rdkey

store ' ' to i_retcode,w_s,w_multi,i_retval
store .t. to i_modal

dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
private i_wfrec1,i_wford1
i_wfrec1=0
i_wford1=0
private i_wfrec2,i_wford2
i_wfrec2=0
i_wford2=0
private i_wfrec3,i_wford3
i_wfrec3=0
i_wford3=0
private i_wfrec4,i_wford4
i_wfrec4=0
i_wford4=0
private i_wfrec5,i_wford5
i_wfrec5=0
i_wford5=0
private i_wfrec6,i_wford6
i_wfrec6=0
i_wford6=0
private i_wfrec7,i_wford7
i_wfrec7=0
i_wford7=0
private i_wfrec8,i_wford8
i_wfrec8=0
i_wford8=0
private i_wfrec9,i_wford9
i_wfrec9=0
i_wford9=0
private i_wfrec10,i_wford10
i_wfrec10=0
i_wford10=0
private i_wfrec11,i_wford11
i_wfrec11=0
i_wford11=0
private i_wfrec12,i_wford12
i_wfrec12=0
i_wford12=0
private i_wfrec13,i_wford13
i_wfrec13=0
i_wford13=0

private w_KEY,w_CODFIS,w_PARIVA,w_BECAPITO,w_BECODPAG
private w_BE__IBAN,w_BECODLIQ,w_DATDOC,w_MRNRACIM,w_BECODBEN
private w_CAUSALE,w_TOTALEDOC,w_TOTALEPAG,w_PATHFILE,w_IMNUMRER
private w_DATCOM,w_NDOCPA,w_IMPORTO,w_PRGINV,w_PERXML
private w_PAPROGID

w_KEY = space(0)
w_CODFIS = space(0)
w_PARIVA = space(0)
w_BECAPITO = space(8)
w_BECODPAG = 0
w_BE__IBAN = space(34)
w_BECODLIQ = space(7)
w_DATDOC = ctod("  /  /  ")
w_MRNRACIM = space(0)
w_BECODBEN = space(7)
w_CAUSALE = space(0)
w_TOTALEDOC = 0
w_TOTALEPAG = 0
w_PATHFILE = space(254)
w_IMNUMRER = 0
w_DATCOM = space(4)
w_NDOCPA = space(20)
w_IMPORTO = 0
w_PRGINV = 0
w_PERXML = space(0)
w_PAPROGID = 0

* --- Inizializzazione variabili

i_oldarea = select()

* --- Execute first page
if OpenFiles()
  do gopa1bfs
  * --- End
  * --- Area Manuale = End
  * --- Fine Area Manuale
  do CloseFiles
endif

i_warea = alltrim(str(i_oldarea))
select (i_oldarea)

return(i_retval)

* === OpenFiles
function OpenFiles
  private i_ok,i_w1,i_w2,i_w3,i_w4,i_w5,i_w6,i_w7,i_w8,i_w9
  private i_w10,i_w11,i_w12,i_w13
  i_ok = .t.
  * --- Apertura dei files
  i_w1 = cplu_opf("TMP_STCE",'')
  i_wfrec1 = i_lastrecno
  i_wford1 = i_lastorder
  i_w2 = cplu_opf("FTPA_XML",'')
  i_wfrec2 = i_lastrecno
  i_wford2 = i_lastorder
  i_w3 = cplu_opf("IMP_EGNI",'')
  i_wfrec3 = i_lastrecno
  i_wford3 = i_lastorder
  i_w4 = cplu_opf("SAL_DIBE",'')
  i_wfrec4 = i_lastrecno
  i_wford4 = i_lastorder
  i_w5 = cplu_opf("SAL_DIPC",'')
  i_wfrec5 = i_lastrecno
  i_wford5 = i_lastorder
  i_w6 = cplu_opf("MAN_DATI",'')
  i_wfrec6 = i_lastrecno
  i_wford6 = i_lastorder
  i_w7 = cplu_opf("BEN_EFIC",'')
  i_wfrec7 = i_lastrecno
  i_wford7 = i_lastorder
  i_w8 = cplu_opf("MOV_FINA",'')
  i_wfrec8 = i_lastrecno
  i_wford8 = i_lastorder
  i_w9 = cplu_opf("STO_RESI",'')
  i_wfrec9 = i_lastrecno
  i_wford9 = i_lastorder
  i_w10 = cplu_opf("SAL_DILQ",'')
  i_wfrec10 = i_lastrecno
  i_wford10 = i_lastorder
  i_w11 = cplu_opf("SAL_ACCE",'')
  i_wfrec11 = i_lastrecno
  i_wford11 = i_lastorder
  i_w12 = cplu_opf("SAL_IMPE",'')
  i_wfrec12 = i_lastrecno
  i_wford12 = i_lastorder
  i_w13 = cplu_opf("SAL_DICO",'')
  i_wfrec13 = i_lastrecno
  i_wford13 = i_lastorder
set exclusive off
  if .not.(i_w1 .and. i_w2 .and. i_w3 .and. i_w4 .and. i_w5 .and. i_w6 .and. i_w7 .and. i_w8 .and. i_w9;
       .and. i_w10 .and. i_w11 .and. i_w12 .and. i_w13)
    i_ok = .f.
    do cplu_clf with "TMP_STCE",i_w1,''
    do cplu_clf with "FTPA_XML",i_w2,''
    do cplu_clf with "IMP_EGNI",i_w3,''
    do cplu_clf with "SAL_DIBE",i_w4,''
    do cplu_clf with "SAL_DIPC",i_w5,''
    do cplu_clf with "MAN_DATI",i_w6,''
    do cplu_clf with "BEN_EFIC",i_w7,''
    do cplu_clf with "MOV_FINA",i_w8,''
    do cplu_clf with "STO_RESI",i_w9,''
    do cplu_clf with "SAL_DILQ",i_w10,''
    do cplu_clf with "SAL_ACCE",i_w11,''
    do cplu_clf with "SAL_IMPE",i_w12,''
    do cplu_clf with "SAL_DICO",i_w13,''
  endif
  return i_ok

* === CloseFiles
procedure CloseFiles
  if i_wfrec1<>0
    select ("TMP_STCE")
    do cplu_go with i_wfrec1
    set order to (i_wford1)
  endif
  do cplu_clf with "TMP_STCE",.t.,''
  if i_wfrec2<>0
    select ("FTPA_XML")
    do cplu_go with i_wfrec2
    set order to (i_wford2)
  endif
  do cplu_clf with "FTPA_XML",.t.,''
  if i_wfrec3<>0
    select ("IMP_EGNI")
    do cplu_go with i_wfrec3
    set order to (i_wford3)
  endif
  do cplu_clf with "IMP_EGNI",.t.,''
  if i_wfrec4<>0
    select ("SAL_DIBE")
    do cplu_go with i_wfrec4
    set order to (i_wford4)
  endif
  do cplu_clf with "SAL_DIBE",.t.,''
  if i_wfrec5<>0
    select ("SAL_DIPC")
    do cplu_go with i_wfrec5
    set order to (i_wford5)
  endif
  do cplu_clf with "SAL_DIPC",.t.,''
  if i_wfrec6<>0
    select ("MAN_DATI")
    do cplu_go with i_wfrec6
    set order to (i_wford6)
  endif
  do cplu_clf with "MAN_DATI",.t.,''
  if i_wfrec7<>0
    select ("BEN_EFIC")
    do cplu_go with i_wfrec7
    set order to (i_wford7)
  endif
  do cplu_clf with "BEN_EFIC",.t.,''
  if i_wfrec8<>0
    select ("MOV_FINA")
    do cplu_go with i_wfrec8
    set order to (i_wford8)
  endif
  do cplu_clf with "MOV_FINA",.t.,''
  if i_wfrec9<>0
    select ("STO_RESI")
    do cplu_go with i_wfrec9
    set order to (i_wford9)
  endif
  do cplu_clf with "STO_RESI",.t.,''
  if i_wfrec10<>0
    select ("SAL_DILQ")
    do cplu_go with i_wfrec10
    set order to (i_wford10)
  endif
  do cplu_clf with "SAL_DILQ",.t.,''
  if i_wfrec11<>0
    select ("SAL_ACCE")
    do cplu_go with i_wfrec11
    set order to (i_wford11)
  endif
  do cplu_clf with "SAL_ACCE",.t.,''
  if i_wfrec12<>0
    select ("SAL_IMPE")
    do cplu_go with i_wfrec12
    set order to (i_wford12)
  endif
  do cplu_clf with "SAL_IMPE",.t.,''
  if i_wfrec13<>0
    select ("SAL_DICO")
    do cplu_go with i_wfrec13
    set order to (i_wford13)
  endif
  do cplu_clf with "SAL_DICO",.t.,''
  return


  procedure gopa1bfs
  * === Procedure gopa1bfs
    * --- A = APRE FATTURA CON VISUALIZZAZIONE
    *     I  = CREA IMPEGNO
    *     M = CREA MANDATO (FUNZIONE NON UTILIZZATA)
    *     E = ESITO
    *     Z = ZOOM IMPEGNI PER ASSOCIAZIONE IMPEGNO GI� ESISTENTE
    *     R = RIMUVE RIFERIMENTO IMPEGNO ASSOCIATO
    *     S= RIMUOVE RIFERIMENTO IMPEGNO ASSOCIATO DA CANCELLAZIONE IMPEGNO
    *     C=CARICAMENTO FATTURA CARTACEA DA GOPA_KCA
w_KEY = ALLTRIM(w_PA1111)+ALLTRIM(w_PA1112) + ALLTRIM(w_PA112)
    do case
      case pOper='A'
        * --- Read from FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          w_PATHFILE = PAPATHFL
        endif
        do cplu_go with w_s
        select &i_warea
w_CMD = addbs(sys(5)+sys(2003))+"FTPA\" + UPPER(alltrim(i_codazi)) + '\VSFT\' + alltrim(w_PATHFILE)
         DECLARE INTEGER ShellExecute IN shell32 INTEGER hwnd, STRING lpOperation, STRING lpFile, STRING lpParameters, STRING lpDirectory, INTEGER nShowCmd
         = ShellExecute(0, "open", w_CMD, "", "", 3)
      case pOper='I'
        do gopa2bfs
        if i_retcode='stop'
          return
        endif
        * --- Legge e controlla progressivo impegno
w_IMNUMREG = 0
I_IMNUMREG = 0
        do CPLU_DPR with "PRSPE", "   ", "IMPPRO", "w_IMNUMREG", "I_IMNUMREG", w_DATDOC
        if i_retcode='stop'
          return
        endif
        do while GSLU_CHK("IMP_EGNI",w_DATCOM,str(w_IMNUMREG,6,0))
w_IMNUMREG = w_IMNUMREG + 1
        enddo
         select IMP_EGNI
         append blank
        * --- Write into IMP_EGNI
        select IMP_EGNI
        w_s = iif(eof(),-1,recno())
          do cplu_wlk with 'File IMP_EGNI'
replace IMDATCOM with w_DATCOM
replace IMNUMREG with w_IMNUMREG
replace IMDATREG with w_DATDOC
replace IMTIPCOM with 'C'
replace IMCODBEN with w_BECODBEN
replace IMDESCRI with w_CAUSALE
replace IM_CONTO with w_BECAPITO
replace IMIMPORT with w_IMPORTO
replace IMVARIMP with 0
replace IMTOTIMP with w_IMPORTO
replace IMIMPPAG with 0
           unlock
        do cplu_go with w_s
        select &i_warea
        * --- Aggiorno impegnato del beneficiario e del capitolo
        * --- Insert into SAL_DIBE
        select SAL_DIBE
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECODBEN
        if .not. found()
          append blank
          w_multi = rlock()
          replace SBDATCOM with w_DATCOM
          replace SBCODICE with w_BECODBEN
          unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Write into SAL_DIBE
        select SAL_DIBE
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECODBEN
        if found()
          do cplu_wlk with 'File SAL_DIBE'
replace SBIMPIMP with SBIMPIMP+w_IMPORTO
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Insert into SAL_DIPC
        select SAL_DIPC
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECAPITO
        if .not. found()
          append blank
          w_multi = rlock()
          replace SLDATCOM with w_DATCOM
          replace SLCODICE with w_BECAPITO
          unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Write into SAL_DIPC
        select SAL_DIPC
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECAPITO
        if found()
          do cplu_wlk with 'File SAL_DIPC'
replace SLCCACIM with SLCCACIM+w_IMPORTO
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- AGGIORNO ANAGRAFICA FATTURA CON LA CHIAVE IMPEGNO
w_PAIMPEGN = w_DATCOM+ALLTRIM(STR(w_IMNUMREG,6,0))
        do CPLU_ERM with "Generato Impegno n. " + ALLTRIM(str(w_IMNUMREG))  ,48
        if i_retcode='stop'
          return
        endif
        * --- SALVA CHIAVE IMPEGNO CREATO
        * --- Write into FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          do cplu_wlk with 'File FTPA_XML'
replace PAIMPEGN with w_PAIMPEGN
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
      case pOper='M'
        * --- descrizione fasi funzionali:
        *     1)verifica se gi� presente mandato e impegno
        *     2)se presente impegno riporto nel mandato i riferimento opportuni e valuto gestione flag MPTIPCOM (C= COMPETENZA , A= ARCHIVIO, R=RICEVUTA)
        *     3)se non presente impegno scrive impegno e aggiorna relativi saldi
        *     3)se presente conto di liquidit� scrive movimento finanziario e relativi saldi
w_CREIMP = .T.
        do CPI_QRY with "QUERY\GOPA1BFS.VQR","TMP_DOC"
        if i_retcode='stop'
          return
        endif
        if USED('TMP_DOC')
           SELECT TMP_IMP
           SCAN
          if MPNUMREG > 0
            do CPLU_ERM with "Mandato gi� creato n.:  " + alltrim(str(MPNUMREG)) + '/' + MPDATCOM,48
            if i_retcode='stop'
              return
            endif
            i_retcode = 'stop'
            return
          endif
          if IMNUMREG > 0
w_CREIMP = .F.
w_IMDATCOM = IMDATCOM
w_IMNUMRER = IMNUMRER
w_IMDATREG = IMDATREG
          endif
           ENDSCAN
        endif
        do gopa2bfs
        if i_retcode='stop'
          return
        endif
        if w_CREIMP
          * --- Legge e controlla progressivo impegno
w_IMNUMRER = 0
I_IMNUMRER = 0
          do CPLU_DPR with "PRSPE", "   ", "IMPPRO", "w_IMNUMRER", "I_IMNUMRER", w_DATDOC
          if i_retcode='stop'
            return
          endif
          do while GSLU_CHK("IMP_EGNI",w_DATCOM,str(w_IMNUMRER,6,0))
w_IMNUMRER = w_IMNUMRER + 1
          enddo
        endif
        * --- Legge e controlla progressivo mandato
w_MRNRRVMP = 0
i_MRNRRVMP = 0
        do CPLU_DPR with "PRSPE", "   ", "MANPRO", "w_MRNRRVMP", "i_MRNRRVMP", w_MRDATRIC
        if i_retcode='stop'
          return
        endif
        do while GSLU_CHK("MAN_DATI",w_DATCOM,str(w_MRNRRVMP,6,0))
w_MRNRRVMP = w_MRNRRVMP + 1
        enddo
        if NOT EMPTY(NVL(w_BECODLIQ,''))
          * --- Legge e controlla progressivo movimento finanziario
w_MRNUMMFI = 0
i_MRNUMMFI = 0
          do CPLU_DPR with "PRMFI","   ", "ULTMFI", "w_MRNUMMFI", "i_MRNUMMFI", w_MRDATRIC
          if i_retcode='stop'
            return
          endif
          do while GSLU_CHK("MOV_FINA",w_DATCOM,str(w_MRNUMMFI,6,0))
w_MRNUMMFI = w_MRNUMMFI + 1
          enddo
        endif
        if w_CREIMP
           select IMP_EGNI
           append blank
          * --- Write into IMP_EGNI
          select IMP_EGNI
          w_s = iif(eof(),-1,recno())
            do cplu_wlk with 'File IMP_EGNI'
replace IMDATCOM with w_DATCOM
replace IMNUMREG with w_IMNUMRER
replace IMDATREG with w_DATDOC
replace IMTIPCOM with 'C'
replace IMCODBEN with w_BECODBEN
replace IMDESCRI with w_CAUSALE
replace IM_CONTO with w_BECAPITO
replace IMIMPORT with w_IMPORTO
replace IMVARIMP with 0
replace IMTOTIMP with w_IMPORTO
replace IMIMPPAG with 0
replace IMORFTEL with w_KEY
             unlock
          do cplu_go with w_s
          select &i_warea
          * --- Aggiorno impegnato del beneficiario e del capitolo
          * --- Insert into SAL_DIBE
          select SAL_DIBE
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+w_BECODBEN
          if .not. found()
            append blank
            w_multi = rlock()
            replace SBDATCOM with w_DATCOM
            replace SBCODICE with w_BECODBEN
            unlock
          endif
          do cplu_go with w_s
          select &i_warea
          * --- Write into SAL_DIBE
          select SAL_DIBE
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+w_BECODBEN
          if found()
            do cplu_wlk with 'File SAL_DIBE'
replace SBIMPIMP with SBIMPIMP+w_IMPORTO
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
          * --- Insert into SAL_DIPC
          select SAL_DIPC
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+w_BECAPITO
          if .not. found()
            append blank
            w_multi = rlock()
            replace SLDATCOM with w_DATCOM
            replace SLCODICE with w_BECAPITO
            unlock
          endif
          do cplu_go with w_s
          select &i_warea
          * --- Write into SAL_DIPC
          select SAL_DIPC
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+w_BECAPITO
          if found()
            do cplu_wlk with 'File SAL_DIPC'
replace SLCCACIM with SLCCACIM+w_IMPORTO
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
          * --- Write into FTPA_XML
          select FTPA_XML
          w_s = iif(eof(),-1,recno())
          seek w_KEY
          if found()
            do cplu_wlk with 'File FTPA_XML'
replace PAIMPEGN with w_DATCOM+ALLTRIM(STR(w_IMNUMRER))
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
          do CPLU_ERM with "Generato Impegno n. " + ALLTRIM(str(w_IMNUMRER))  ,48
          if i_retcode='stop'
            return
          endif
        endif
        * --- SE IMPEGNO NON ESISTEVA ED � STATO APPENA CREATO
        if EMPTY(NVL(w_IMDATDOC,''))
w_IMDATCOM = w_DATCOM
w_IMDATREG = w_DATDOC
w_TIPCOM = 'C'
        else
          * --- ** VERIFICARE
w_TIPCOM = iif(w_DATCOM=w_IMDATCOM,'C','A')
        endif
        * --- Scrivo il mandato
         select MAN_DATI
         append blank
        * --- ** VERIFICARE MPFLGIMP
        * --- Write into MAN_DATI
        select MAN_DATI
        w_s = iif(eof(),-1,recno())
          do cplu_wlk with 'File MAN_DATI'
replace MPDATCOM with w_DATCOM
replace MPNUMREG with w_MRNRRVMP
replace MPDATREG with w_DATDOC
replace MPCOMIMP with w_IMDATCOM
replace MPNUMIMP with w_IMNUMREG
replace MPDATIMP with w_IMDATREG
replace MPTIPCOM with w_TIPCOM
replace MPCODBEN with w_BECODBEN
replace MPDESCRI with w_CAUSALE
replace MP_CONTO with w_BECAPITO
replace MPIMPORT with w_IMPORTO
replace MPFLGPAG with 'S'
replace MPNUMMFI with w_MRNUMMFI
replace MPCODLIQ with w_BECODLIQ
replace MPTOTIMP with w_IMPORTO
replace MPFLGIMP with '?'
replace MPFLGMFI with 'S'
        do case
          case ='='
            replace MPORFTEL with w_KEY
          case ='+'
            replace MPORFTEL with MPORFTEL+w_KEY
          case ='-'
            replace MPORFTEL with MPORFTEL-w_KEY
        endcase
           unlock
        do cplu_go with w_s
        select &i_warea
        * --- Write into FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          do cplu_wlk with 'File FTPA_XML'
replace PAMANDAT with w_DATCOM+ALLTRIM(STR(w_MRNRRVMP))
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
        do CPLU_ERM with "Generato Impegno n. " + ALLTRIM(str(w_MRNRRVMP))  ,48
        if i_retcode='stop'
          return
        endif
        * --- Scrivo movimento finanziario
w_MRTIPRIC = 'U'
w_PERDOC = w_BECODBEN
w_FLGCOM = iif(w_TIPCOM='C','+',' ')
w_FLGRES = iif(w_TIPCOM$'RA','+',' ')
w_FLGSTR = iif(w_TIPCOM$'RA','+',' ')
w_FLGENT = iif(w_MRTIPRIC='E','+',' ')
w_FLGUSC = iif(w_MRTIPRIC='U','+',' ')
         select MOV_FINA
         append blank
        * --- Write into MOV_FINA
        select MOV_FINA
        w_s = iif(eof(),-1,recno())
          do cplu_wlk with 'File MOV_FINA'
replace MFDATCOM with w_DATCOM
replace MFNUMREG with w_MRNUMMFI
replace MFDATREG with w_DATDOC
replace MFCODLIQ with w_BECODLIQ
replace MFTIPOPE with iif(w_MRTIPRIC='E','R','M')
replace MFDESCRI with w_CAUSALE
replace MFCOMDOC with w_IMDATCOM
replace MFNUMDOC with w_MRNRRVMP
replace MFDATDOC with w_DATDOC
replace MFDOCFLC with w_TIPCOM
replace MFPERDOC with w_PERDOC
replace MF_CONTO with w_BECODLIQ
replace MFFLGCOM with w_FLGCOM
replace MFFLGRES with w_FLGRES
replace MFFLGSTR with w_FLGSTR
replace MFIMPORT with w_IMPORTO
replace MFFLGENT with w_FLGENT
replace MFFLGUSC with w_FLGUSC
replace MFTOTMOV with w_IMPORTO
           unlock
        do cplu_go with w_s
        select &i_warea
        * --- Aggiorno saldi capitolo
        * --- Insert into SAL_DIPC
        select SAL_DIPC
        w_s = iif(eof(),-1,recno())
        seek CUR_RICE.MRDATCOM+MDE_RICE->MD_CONTO
        if .not. found()
          append blank
          w_multi = rlock()
          replace SLDATCOM with w_DATCOM
          replace SLCODICE with w_BECODLIQ
          unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Write into SAL_DIPC
        select SAL_DIPC
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECODLIQ
        if found()
          do cplu_wlk with 'File SAL_DIPC'
        do case
          case w_FLGCOM='='
            replace SLCCRIPA with MDE_RICE->MDIMPORT
          case w_FLGCOM='+'
            replace SLCCRIPA with SLCCRIPA+MDE_RICE->MDIMPORT
          case w_FLGCOM='-'
            replace SLCCRIPA with SLCCRIPA-MDE_RICE->MDIMPORT
        endcase
        do case
          case w_FLGRES='='
            replace SLRCRIPA with MDE_RICE->MDIMPORT
          case w_FLGRES='+'
            replace SLRCRIPA with SLRCRIPA+MDE_RICE->MDIMPORT
          case w_FLGRES='-'
            replace SLRCRIPA with SLRCRIPA-MDE_RICE->MDIMPORT
        endcase
replace SLSCRIPA with SLSCRIPA+MDE_RICE->MDIMPORT
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Aggiorno lo storico dei residui
        * --- ** VERIFICARE
        if .F.
          * --- Insert into STO_RESI
          select STO_RESI
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+CUR_RICE.MRCMACIM+MDE_RICE->MD_CONTO
          if .not. found()
            append blank
            w_multi = rlock()
            replace SRDATCOM with w_DATCOM
            replace SRANNRES with CUR_RICE.MRCMACIM
            replace SRCODICE with MDE_RICE->MD_CONTO
            unlock
          endif
          do cplu_go with w_s
          select &i_warea
          * --- Write into STO_RESI
          select STO_RESI
          w_s = iif(eof(),-1,recno())
          seek w_DATCOM+CUR_RICE.MRCMACIM+MDE_RICE->MD_CONTO
          if found()
            do cplu_wlk with 'File STO_RESI'
          do case
            case w_FLGSTR='='
              replace SRRISPAG with MDE_RICE->MDIMPORT
            case w_FLGSTR='+'
              replace SRRISPAG with SRRISPAG+MDE_RICE->MDIMPORT
            case w_FLGSTR='-'
              replace SRRISPAG with SRRISPAG-MDE_RICE->MDIMPORT
          endcase
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
        endif
        * --- Aggiorno saldi conto liquidit�
        * --- Insert into SAL_DILQ
        select SAL_DILQ
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECODLIQ
        if .not. found()
          append blank
          w_multi = rlock()
          replace SQDATCOM with w_DATCOM
          replace SQCODICE with w_BECODLIQ
          unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- Write into SAL_DILQ
        select SAL_DILQ
        w_s = iif(eof(),-1,recno())
        seek w_DATCOM+w_BECODLIQ
        if found()
          do cplu_wlk with 'File SAL_DILQ'
        do case
          case w_FLGENT='='
            replace SQENTRAT with w_IMPORTO
          case w_FLGENT='+'
            replace SQENTRAT with SQENTRAT+w_IMPORTO
          case w_FLGENT='-'
            replace SQENTRAT with SQENTRAT-w_IMPORTO
        endcase
        do case
          case w_FLGUSC='='
            replace SQUSCITE with w_IMPORTO
          case w_FLGUSC='+'
            replace SQUSCITE with SQUSCITE+w_IMPORTO
          case w_FLGUSC='-'
            replace SQUSCITE with SQUSCITE-w_IMPORTO
        endcase
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
        * --- ** VERIFICARE
        if .F.
          if w_TIPCOM='R' .and. !empty(w_MRNRACIM)
            if w_MRTIPRIC='E'
              * --- Aggiorno residui attivi in archivio
              * --- Insert into SAL_ACCE
              select SAL_ACCE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCMACIM+str(w_MRNRACIM,6,0)
              if .not. found()
                append blank
                w_multi = rlock()
                replace SADATCOM with CUR_RICE.MRDATCOM
                replace SACOMACC with CUR_RICE.MRCMACIM
                replace SANUMACC with w_MRNRACIM
                unlock
              endif
              do cplu_go with w_s
              select &i_warea
              * --- Write into SAL_ACCE
              select SAL_ACCE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCMACIM+str(w_MRNRACIM,6,0)
              if found()
                do cplu_wlk with 'File SAL_ACCE'
replace SARISPER with SARISPER+MDE_RICE->MDIMPORT
                 unlock
              endif
              do cplu_go with w_s
              select &i_warea
            else
              * --- Aggiorno residui passivi in archivio
              * --- Insert into SAL_IMPE
              select SAL_IMPE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCMACIM+str(w_MRNRACIM,6,0)
              if .not. found()
                append blank
                w_multi = rlock()
                replace SIDATCOM with CUR_RICE.MRDATCOM
                replace SICOMIMP with CUR_RICE.MRCMACIM
                replace SINUMIMP with w_MRNRACIM
                unlock
              endif
              do cplu_go with w_s
              select &i_warea
              * --- Write into SAL_IMPE
              select SAL_IMPE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCMACIM+str(w_MRNRACIM,6,0)
              if found()
                do cplu_wlk with 'File SAL_IMPE'
replace SIPAGPER with SIPAGPER+MDE_RICE->MDIMPORT
                 unlock
              endif
              do cplu_go with w_s
              select &i_warea
            endif
          endif
          if w_TIPCOM#'A'
            if w_MRTIPRIC='E'
              * --- Aggiorno saldi controparte
              * --- Insert into SAL_DICO
              select SAL_DICO
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCODCON
              if .not. found()
                append blank
                w_multi = rlock()
                replace SCDATCOM with CUR_RICE.MRDATCOM
                replace SCCODICE with CUR_RICE.MRCODCON
                unlock
              endif
              do cplu_go with w_s
              select &i_warea
              * --- Write into SAL_DICO
              select SAL_DICO
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCODCON
              if found()
                do cplu_wlk with 'File SAL_DICO'
              do case
                case w_FLGCOM='='
                  replace SCIMPRIS with MDE_RICE->MDIMPORT
                case w_FLGCOM='+'
                  replace SCIMPRIS with SCIMPRIS+MDE_RICE->MDIMPORT
                case w_FLGCOM='-'
                  replace SCIMPRIS with SCIMPRIS-MDE_RICE->MDIMPORT
              endcase
              do case
                case w_FLGRES='='
                  replace SCRESRIS with MDE_RICE->MDIMPORT
                case w_FLGRES='+'
                  replace SCRESRIS with SCRESRIS+MDE_RICE->MDIMPORT
                case w_FLGRES='-'
                  replace SCRESRIS with SCRESRIS-MDE_RICE->MDIMPORT
              endcase
                 unlock
              endif
              do cplu_go with w_s
              select &i_warea
            else
              * --- Aggiorno saldi beneficiario
              * --- Insert into SAL_DIBE
              select SAL_DIBE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCODBEN
              if .not. found()
                append blank
                w_multi = rlock()
                replace SBDATCOM with CUR_RICE.MRDATCOM
                replace SBCODICE with CUR_RICE.MRCODBEN
                unlock
              endif
              do cplu_go with w_s
              select &i_warea
              * --- Write into SAL_DIBE
              select SAL_DIBE
              w_s = iif(eof(),-1,recno())
              seek CUR_RICE.MRDATCOM+CUR_RICE.MRCODBEN
              if found()
                do cplu_wlk with 'File SAL_DIBE'
              do case
                case w_FLGCOM='='
                  replace SBIMPPAG with MDE_RICE->MDIMPORT
                case w_FLGCOM='+'
                  replace SBIMPPAG with SBIMPPAG+MDE_RICE->MDIMPORT
                case w_FLGCOM='-'
                  replace SBIMPPAG with SBIMPPAG-MDE_RICE->MDIMPORT
              endcase
              do case
                case w_FLGRES='='
                  replace SBRESPAG with MDE_RICE->MDIMPORT
                case w_FLGRES='+'
                  replace SBRESPAG with SBRESPAG+MDE_RICE->MDIMPORT
                case w_FLGRES='-'
                  replace SBRESPAG with SBRESPAG-MDE_RICE->MDIMPORT
              endcase
                 unlock
              endif
              do cplu_go with w_s
              select &i_warea
            endif
          endif
        endif
      case pOper='E'
L_PAESICAU = ALLTRIM(w_PAESICAU)
L_FILEESITO = ALLTRIM(w_FILEESITO)
L_PA_ESITO = ALLTRIM(w_PA_ESITO)
L_PA_IDSDI = ALLTRIM(w_PA_IDSDI)
L_PA_IDCOM = ALLTRIM(w_PA_IDCOM)
L_PA2114 = ALLTRIM(w_PA2114)
L_PA2113 = ytos(w_PA2113)
        * --- Creazione File
hr_FILE = FCREATE(w_FILEESITO)
        if hr_FILE=-1
          do CPLU_ERM with "Errore nella creazione del file !",48
          if i_retcode='stop'
            return
          endif
          i_retval=.F.
          i_retcode = 'stop'
          return
        endif
        do CPLU_MES with "Generazione file ..."
        if i_retcode='stop'
          return
        endif
        do gopa3bfs
        if i_retcode='stop'
          return
        endif
        if hr_FILE>0
          * --- Chiude file
x_CLOSE = FCLOSE(hr_FILE)
          if .not. x_CLOSE
            do CPLU_ERM with "Errore nella chisura del file !",48
            if i_retcode='stop'
              return
            endif
            i_retval=.F.
            i_retcode = 'stop'
            return
          endif
        endif
w_PAPRGINV = w_PAPRGINV + 1
        do CPLU_ERM with "File esito Generato ! "
        if i_retcode='stop'
          return
        endif
        * --- SALVA RIFERIMENTI DEL MESSAGGIO DI ESITO
        * --- Write into FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          do cplu_wlk with 'File FTPA_XML'
replace PAPRGINV with w_PAPRGINV
replace PA_ESITO with L_PA_ESITO
replace PAESICAU with L_PAESICAU
replace PA_IDSDI with L_PA_IDSDI
replace PA_IDCOM with L_PA_IDCOM
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
      case pOper='Z'
w_IMNUMREG = 0
w_IMDATCOM = YTOS(I_DATLAV)
         i_rdvars[2,1] = "w_IMNUMREG"
i_rdvars[2,2] = "IMNUMREG"
i_rdvars[3,1] = "w_IMDATCOM"
i_rdvars[3,2] = "IMDATCOM"
i_rdvars[1,1] = 2
do GOGS_ZIM with w_IMDATCOM , w_PACODBEN
        if w_IMNUMREG > 0
w_PAIMPEGN = w_IMDATCOM+ALLTRIM(STR(w_IMNUMREG,6,0))
        endif
        * --- SALVA CHIAVE IMPEGNO ASSOCIATO
        * --- Write into FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          do cplu_wlk with 'File FTPA_XML'
replace PAIMPEGN with w_PAIMPEGN
           unlock
        endif
        do cplu_go with w_s
        select &i_warea
      case pOper='R'
w_R = .F.
         do CPLU_DBX with "Confermi Rimozione riferimento Impegno ? ", w_R
        if w_R
w_PAIMPEGN = ''
          * --- Write into FTPA_XML
          select FTPA_XML
          w_s = iif(eof(),-1,recno())
          seek w_KEY
          if found()
            do cplu_wlk with 'File FTPA_XML'
replace PAIMPEGN with w_PAIMPEGN
             unlock
          endif
          do cplu_go with w_s
          select &i_warea
        endif
      case pOper='S'
         SELECT FTPA_XML
         GO TOP
         SET ORDER TO 4
         SEEK w_PA1111
         REPLACE PAIMPEGN WITH ''
      case pOper='C'
w_PAPROGID = 0
        * --- Read from FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
        seek w_KEY
        if found()
          w_PAPROGID = PAPROGID
        endif
        do cplu_go with w_s
        select &i_warea
        if !EMPTY(w_PAPROGID) OR NVL(w_PAPROGID ,0) > 0
          do CPLU_ERM with "Fattura gi� importata ! " + chr(13) + "Numero progressivo: " + alltrim(str(w_PAPROGID)),48
          if i_retcode='stop'
            return
          endif
          i_retcode = 'stop'
          return
        endif
         SELECT FTPA_XML
         GO TOP
         SET ORDER TO 5
         SEEK ALLTRIM(w_PACODBEN) + DTOC(w_PA2113) + ALLTRIM(w_PA2114)
        if found()
          do CPLU_ERM with "Fattura gi� importata ! " + chr(13) + "Numero progressivo: " + alltrim(str(PAPROGID)),48
          if i_retcode='stop'
            return
          endif
          i_retcode = 'stop'
          return
        endif
         SELECT FTPA_XML
         GO TOP
         SET ORDER TO 3
         SEEK w_PAANPROT + ALLTRIM(STR(w_PANRPROT))
        if found()
          do CPLU_ERM with "Numero protocollo gi� utilizzato ! " + chr(13) + "Numero progressivo: " + alltrim(str(PAPROGID)),48
          if i_retcode='stop'
            return
          endif
          i_retcode = 'stop'
          return
        endif
        * --- DEFINIZIONE CHIAVE DA GOPA_KCA
        *     PA1111 = '@@'
        *     PA1112 = BENEFICIARIO COFIN + NUMERO FATTURE + DATA FATTURA
        *     PA112 = ''
        * --- IMPOSTA PROGRESSIVO FATTURA
w_NUMPRO = 0
        do CPLU_DPR with "PFTPA", "   ", "NUMPRO", "w_NUMPRO" , " ", i_DATLAV
        if i_retcode='stop'
          return
        endif
        * --- Inserisco i dati in tabella
         select FTPA_XML
         append blank
        * --- Write into FTPA_XML
        select FTPA_XML
        w_s = iif(eof(),-1,recno())
          do cplu_wlk with 'File FTPA_XML'
replace PA1111 with w_PA1111
replace PA1112 with w_PA1112
replace PA112 with w_PA112
replace PANRPROT with w_PANRPROT
replace PADTPROT with w_PADTPROT
replace PAANPROT with w_PAANPROT
replace PA2114 with w_PA2114
replace PA2113 with w_PA2113
replace PA12131 with w_PA12131
replace PA1212 with w_PA1212
replace PA12112 with w_PA12112
replace PA21111 with w_PA21111
replace PA2119 with w_PA2119
replace PA2425 with w_PA2425
replace PAPROGID with w_NUMPRO
replace PACODBEN with w_PACODBEN
replace PA2127 with w_PA2127
replace PA2126 with w_PA2126
replace PAIMPEGN with w_PAIMPEGN
           unlock
        do cplu_go with w_s
        select &i_warea
        do CPLU_FPR with "PFTPA", "   ", "NUMPRO", "w_NUMPRO" , " ", i_DATLAV
        if i_retcode='stop'
          return
        endif
        do CPLU_ERM with "Fattura Caricata ! " 
        if i_retcode='stop'
          return
        endif
w_PAANPROT = ''
w_PANRPROT = 0
w_PADTPROT = ctod('  -  -    ')
w_PA2114 = ''
w_PA2113 = ctod('  -  -    ')
w_PACODBEN = ''
w_PA12131 = ''
w_PA1212 = ''
w_PA12112 = ''
w_PA21111 = ''
w_PA2119 = 0
w_PA2425 = ctod('  -  -    ')
w_PAIMPEGN = ''
w_PA2127 = ''
w_PA2126 = ''
w_NUMIMP = 0
w_ANNOIMP = ''
    endcase
    return

  procedure gopa2bfs
  * === Procedure gopa2bfs
    * --- Read from FTPA_XML
    select FTPA_XML
    w_s = iif(eof(),-1,recno())
    seek w_KEY
    if found()
      w_CODFIS = PA1212
      w_PARIVA = PA12112
      w_DATDOC = PA2113
      w_CAUSALE = PA21111
      w_TOTALEDOC = PA2119
      w_TOTALEPAG = PA2426
      w_NDOCPA = PA2114
      w_ESITO = PA_ESITO
      w_RAGSOC = PA12131
      w_BECODBEN = PACODBEN
    endif
    do cplu_go with w_s
    select &i_warea
w_CAUSALE = 'Fat. (E) n. '  + alltrim(w_NDOCPA) + ' del ' + dtoc(w_DATDOC) + ' causale ' + ALLTRIM(w_CAUSALE)
w_DATCOM = ytos(w_DATDOC)
    if w_ESITO='N'
      do CPLU_ERM with "La fattura non � stata accettata ! " + chr(10) + "Impossibile generare il Documento",48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    if w_TOTALEDOC > 0
w_IMPORTO = w_TOTALEDOC
    else
w_IMPORTO = w_TOTALEPAG
    endif
    if w_IMPORTO=0
      do CPLU_ERM with "La fattura non ha alcun importo ! " + chr(10) + "Impossibile generare il Documento",48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
w_BECAPITO = '@@'
    * --- Read from BEN_EFIC
    select BEN_EFIC
    w_s = iif(eof(),-1,recno())
    seek w_BECODBEN
    if found()
      w_BECAPITO = BECAPITO
      w_BECODPAG = BECODPAG
      w_BE__IBAN = BE__IBAN
      w_BECODLIQ = BECODLIQ
    endif
    do cplu_go with w_s
    select &i_warea
    if w_BECAPITO='@@'
      do CPLU_ERM with "Capitolo Beneficiario : " + ALLTRIM(w_RAGSOC)  + chr(10) + "Non Valorizzato ! Impossibile generare il Documento",48
      if i_retcode='stop'
        return
      endif
      i_retcode = 'stop'
      return
    endif
    return

  procedure gopa3bfs
  * === Procedure gopa3bfs
    * --- Inserisco dati base del file XML
w_RECORD = '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="EC_v1.0.xsl"?>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '<types:NotificaEsitoCommittente xmlns:types="http://www.fatturapa.gov.it/sdi/messaggi/v1.0" xmlns:ds="http://www.w3.org/2000/09/xmldsig' + CHR(35) +'"' +' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" versione="1.0" xsi:schemaLocation="http://www.fatturapa.gov.it/sdi/messaggi/v1.0 MessaggiTypes_v1.0.xsd ">'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  <IdentificativoSdI>'+L_PA_IDSDI+'</IdentificativoSdI>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  <RiferimentoFattura>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '    <NumeroFattura>' + L_PA2114 + '</NumeroFattura>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '    <AnnoFattura>' + L_PA2113 + '</AnnoFattura>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  </RiferimentoFattura>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  <Esito>'+ IIF(L_PA_ESITO='S' ,'EC01', 'EC02') + '</Esito>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  <Descrizione>'  + ALLTRIM(L_PAESICAU)+ '</Descrizione>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '  <MessageIdCommittente>'+L_PA_IDCOM+'</MessageIdCommittente>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
w_RECORD = '</types:NotificaEsitoCommittente>'
* --- Area Manuale = ScriviRecord
* --- gopa_bfs
if !empty(w_RECORD)
   x_r = FPUTS(hr_FILE,w_RECORD)
   if x_r = 0
      do CPLU_ERM with "Errore nella scrittura del record su file!",48
      return
   endif
endif
* --- Fine Area Manuale
    return


* --- Area Manuale = Functions & Procedures
* --- gopa_bfs
Procedure makeawriteablecursor
Parameter lccursoralias
Private lnworkarea, lctmpdbfname, lctmpcur, lncurrarea
If Parameter() = 0
    lccursoralias = Alias()
Endif
lncurrarea = Select()
Select (lccursoralias)
lnworkarea = Select(0)
If At(".TMP", Dbf()) > 0
    Select 0
    lctmpdbfname = Dbf(lccursoralias)
    Use (lctmpdbfname) Again
Else
    Select * From (Dbf(lccursoralias));
        INTO Cursor lctmpcur;
        WHERE .T.
    lctmpdbfname = Dbf("lcTmpCur")
Endif
Use (lctmpdbfname) Again In (lnworkarea);
    ALIAS (lccursoralias)
Use
Select (lncurrarea)
Release All Like lnworkarea, lctmpdbfname, lctmpcur, lncurrarea
Return
* --- Fine Area Manuale

