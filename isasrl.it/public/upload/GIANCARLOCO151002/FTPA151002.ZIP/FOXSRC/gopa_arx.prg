* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gopa_arx                                                        *
*              FATTURE  PA                                                     *
*                                                                              *
*      Author: DIP                                                             *
*      Client: FatturaPA                                                       *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2015-04-30                                                      *
* Last revis.: 2015-09-30                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
* ----------------------------------------
* variabile pubblica che conterra' lo stato del programma
* in modo che possa riprendere da dove si era interrotto
public array s_gopa_arx[87]

private i_op
#define OP_QUERY     1
#define OP_LOAD      2
#define OP_EDITMOD   3
#define OP_EDITLOAD  4
#define OP_ZOOM      5
#define OP_QUIT      6
#define OP_INTR      7
i_op = OP_QUERY

* --- Variabili locali
private i_modal
i_modal = .t.
i_3d = iif(type("i_3d")="U",.t.,i_3d)
private i_shx,i_shsz
store 0 to i_shx,i_shsz
private i_loaded,w_s,i_campo,i_campoq,i_docreco, i_campg, i_accpt, i_zoomrec
private i_rdvars,i_rdkvars,i_rdkey, i_zoompars, i_zbrow, i_paint, i_oldarea
private i_pag,i_button,i_function,i_oldop,i_zoomprg, i_openfail, i_help, i_twind
private i_posyx1, i_size1, i_font1, i_style1
private i_posyx2, i_size2, i_font2, i_style2
private i_posyx3, i_size3, i_font3, i_style3
private i_posyx4, i_size4, i_font4, i_style4
private i_posyx5, i_size5, i_font5, i_style5
dimension i_posyx1[49,2], i_size1[49,2], i_font1[49,2], i_style1[49]
dimension i_posyx2[38,2], i_size2[38,2], i_font2[38,2], i_style2[38]
dimension i_posyx3[49,2], i_size3[49,2], i_font3[49,2], i_style3[49]
dimension i_posyx4[13,2], i_size4[13,2], i_font4[13,2], i_style4[13]
dimension i_posyx5[25,2], i_size5[25,2], i_font5[25,2], i_style5[25]
dimension i_campg[5]
dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 1 to i_pag, i_button, i_campoq
i_campo  = i_nbtntbar+1
store .f. to i_loaded, i_zbrow, i_paint, i_accpt, i_openfail
store 0 to i_oldop, i_docreco
store " " to i_function, w_s, i_zoomprg, i_rdkey, i_help
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
i_campg[1] = 3
i_campg[2] = 1
i_campg[3] = 1
i_campg[4] = 1
i_campg[5] = 8
private wnd_gopa_arx
wnd_gopa_arx = ' '

***
* Descrizione analisi FATTURE  PA
***

private i_fngopa_arx
private w_PANRPROT,w_PADTPROT,w_PA21112,w_PA2111,w_PA2112
private w_PA2113,w_PA2114,w_PA21151,w_PA21152,w_PA21153
private w_PA21154,w_PA2119,w_PA21110,w_PA21111,w_PAPATHFL
private w_PA126,w_PA12133,w_PA12134,w_PA12135,w_PA1221
private w_PA1222,w_PA1223,w_PA1224,w_PA1225,w_PA1226
private w_PA1251,w_PA1252,w_PA1253,w_PA12111,w_PA12112
private w_PA1212,w_PA12132,w_PA241,w_PA2421,w_PA2422
private w_PA2423,w_PA2424,w_PA2425,w_PA2426,w_PA2427
private w_PA2428,w_PA2429,w_PA24210,w_PA24212,w_PA24213
private w_PA24214,w_PA24215,w_PA24216,w_PA24217,w_PA24218
private w_PA24219,w_PA24220,w_PA24221,w_PA24211,w_PA1111
private w_PA1112,w_PA112,w_PA113,w_PA114,w_PA1151
private w_PA1152,w_PA12131,w_PA12131,w_PAIMPEGN,w_PA_ESITO
private w_FILEESITO,w_PAPRGINV,w_PA_IDSDI,w_PAESICAU,w_NIMP
private w_DIMP,w_CVG,w_DESPA,w_PA2126,w_PA2127
private w_PA_IDCOM,w_PAPROGID,w_PAANPROT,w_PACODBEN
store " " to w_PANRPROT,w_PADTPROT,w_PA21112,w_PA2111,w_PA2112
store " " to w_PA2113,w_PA2114,w_PA21151,w_PA21152,w_PA21153
store " " to w_PA21154,w_PA2119,w_PA21110,w_PA21111,w_PAPATHFL
store " " to w_PA126,w_PA12133,w_PA12134,w_PA12135,w_PA1221
store " " to w_PA1222,w_PA1223,w_PA1224,w_PA1225,w_PA1226
store " " to w_PA1251,w_PA1252,w_PA1253,w_PA12111,w_PA12112
store " " to w_PA1212,w_PA12132,w_PA241,w_PA2421,w_PA2422
store " " to w_PA2423,w_PA2424,w_PA2425,w_PA2426,w_PA2427
store " " to w_PA2428,w_PA2429,w_PA24210,w_PA24212,w_PA24213
store " " to w_PA24214,w_PA24215,w_PA24216,w_PA24217,w_PA24218
store " " to w_PA24219,w_PA24220,w_PA24221,w_PA24211,w_PA1111
store " " to w_PA1112,w_PA112,w_PA113,w_PA114,w_PA1151
store " " to w_PA1152,w_PA12131,w_PA12131,w_PAIMPEGN,w_PA_ESITO
store " " to w_FILEESITO,w_PAPRGINV,w_PA_IDSDI,w_PAESICAU,w_NIMP
store " " to w_DIMP,w_CVG,w_DESPA,w_PA2126,w_PA2127
store " " to w_PA_IDCOM,w_PAPROGID,w_PAANPROT,w_PACODBEN
private o_PADTPROT
store " " to o_PADTPROT
private r_PA241,r_PA_ESITO
store 0 to r_PA241,r_PA_ESITO
i_oldarea = select()
if .not. wexist("gopa_arx")
  * --- se non esiste la finestra prova
  *     allora il programma non e' gia' attivo
  if .not. OpenProc()
    return
  endif
  * --- Event = Program Start
  * --- End Event
  i_op = OP_QUERY
  * --- Area Manuale = Init
  * --- Fine Area Manuale
  do F_Blank
  do Ass_pos
  do F_Paint with 0
else
  private i_ay
  i_ay = 1.5
  if _windows
    activate window "gopa_arx" noshow same
    modify window "gopa_arx" at wlrow(),wlcol() ;
      size at_y(483,"Arial",9,"")+i_ay,at_x(757,"Arial",9,"")
  else
    if _mac
      activate window "gopa_arx" noshow same
      modify window "gopa_arx" at wlrow(),wlcol() ;
        size at_y(483,"Arial",9*4/3,"")+i_ay,at_x(757,"Arial",9*4/3,"")
    endif
  endif
  do RestoreStatus
endif
do while i_op<>OP_QUIT .and. i_op<>OP_INTR
  do case
    case i_op=OP_QUERY
      * --- Area Manuale = Query Init
      * --- Fine Area Manuale
      do F_Query
      * --- Area Manuale = Query End
      * --- Fine Area Manuale
    case i_op=OP_LOAD
      * --- Area Manuale = Load Key Init
      * --- gopa_arx
      DO CPLU_ERM WITH 'Funzione non abilitata !' , 48
      if .f.
      * --- Fine Area Manuale
      do F_Load
      * --- Area Manuale = Load Key End
      * --- gopa_arx
      endif
      i_op=OP_QUERY
      
      * --- Fine Area Manuale
    case i_op=OP_EDITMOD
      * --- Area Manuale = Edit Init
      * --- Fine Area Manuale
      do F_Edit
      * --- Area Manuale = Edit End
      * --- Fine Area Manuale
    case i_op=OP_EDITLOAD
      do F_Edit
    case i_op=OP_ZOOM
      i_docreco = recno()
      &i_zoomprg
      do RestoreFilters
      i_op = iif(.not. empty(i_todo),OP_INTR,i_oldop)
  endcase
enddo
if i_op=OP_QUIT
  * --- Area Manuale = End
  * --- Fine Area Manuale
  * --- Event = Program End
  * --- End Event
  do CloseProc
else
  do SaveStatus
endif
i_warea = alltrim(str(i_oldarea))
select (i_oldarea)
return

function F_Query
i_fngopa_arx = .f.
#if left(version(),13)="Visual FoxPro"
  i_shx = 1/fontmetric(6)
  i_shsz = -3/fontmetric(6)
#endif
  if i_vidgrf
    modify window "gopa_arx" title "FATTURE  PA / Interroga"
  endif
  do while i_op<>OP_QUIT .and. i_op<>OP_INTR .and. i_op<>OP_ZOOM
    i_function = ""
    i_zoomprg  = ""
    i_help = "gopa_arx interroga"
    activate window "gopa_arx"
    if i_pag=1
      @ i_posyx1[1,1],i_posyx1[1,2]+i_shx get w_PANRPROT picture '@Z 9999999999';
        size i_size1[1,1],i_size1[1,2]+i_shsz;
        when;
          cplu_sod(3);
        valid;
          find_record(3)
      @ i_posyx1[43,1],i_posyx1[43,2]+i_shx get w_PAPROGID picture '@Z 9999999999';
        size i_size1[43,1],i_size1[43,2]+i_shsz;
        when;
          cplu_sod(2);
        valid;
          find_record(2)
        @ i_posyx1[33,1],i_posyx1[33,2] get i_button picture iif(i_vidgrf,'@*B prvideo.bmp','@* Anteprima');
          size i_size1[33,1],i_size1[33,2];
          when .not.empty(w_PAPATHFL) ;
          valid cplu_qz('do GOPA_BFS with  "A", w_PA1111, w_PA1112, w_PA112');

    else
      @ 0,0 get i_button picture "@*I" size 0,0
    endif
    if i_vidgrf
      do gettab with at_x(757),5
    endif
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
      oCpToolBar.SetQuery(i_loaded,.f.,.t.)
    #else
      do cplu_bar with OP_QUERY, .f.
    #endif
    * ---
     _screen.ActiveForm.lockscreen=.t.
     _screen.ActiveForm.lockscreen=.f.
    read object i_campoq cycle deactivate cplu_kwf("gopa_arx")
    * --- Area Manuale = Query Chkread2
    * --- Fine Area Manuale
    do case
      case .not. empty(i_todo)
        i_oldop = OP_QUERY
        i_op = OP_INTR
        i_docreco = recno()
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Next" .or. i_function="Prior"
        do cplu_pn
      case i_function="Edit" .and. i_loaded
        i_campo = i_nbtntbar+1
        * --- Blocca
        w_multi = rlock() .and. .not. deleted()
        if .not. w_multi
          do cplu_erm with w_t_msmrl
          loop
        endif
        i_op = OP_EDITMOD
        do cplu_alk with "FTPA_XML",.t.
        do F_Read
        if i_pag>1
          i_pag = 1
          do F_Paint with 0
        endif
        exit
      case i_function="Load"
        i_campo = i_nbtntbar+1
        i_op = OP_LOAD
        do F_Blank
        do Paint_Pag
        exit
      case i_function="Delete" .and. i_loaded
        * --- Area Manuale = Delete Init
        * --- Fine Area Manuale
        w_s = .f.
        * --- Richiesta conferma Cancellazione Record
        do cplu_dbx with w_t_msmdr,w_s
        if w_s .and. F_ChkAutoLock()
          w_multi = rlock()
          if .not. w_multi
            do cplu_erm with w_t_msmrl
          else
          * --- Event = Record Deleted
          * --- End Event
          do F_Delete with .t.
          unlock
          i_loaded = .f.
          i_docreco = 0
          do F_Blank
          do F_Paint with 1
          endif
        endif
        * --- Area Manuale = Delete End
        * --- Fine Area Manuale
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Zoom"
        i_zoomrec = 0
        #if left(version(),13)="Visual FoxPro"
        do cpvfpzom with 'FTPA_XML','','','Anagrafica','PA1111+ALLTRIM(PA1112)+ALLTRIM(PA112)'
        #else
        i_rdvars[2,1] = "w_PA112"
        i_rdvars[2,2] = "PA112"
        i_rdvars[3,1] = "w_PAPROGID"
        i_rdvars[3,2] = "PAPROGID"
        i_rdvars[1,1] = 2
        i_zoompars[1] = 2
        i_zoompars[2] = 4
        i_zoompars[3] = ''
        do cplu_zom with "FTPA_XML","PA1111","PA1112","1","w_PA1111","w_PA1112",""
        #endif
        if i_zoomrec>0
          goto i_zoomrec
          i_loaded = .t.
          i_docreco = recno()
          do F_Read
          do F_Paint with 1
        endif
      case i_function="Print"
        * --- Area Manuale = Print Init
        * --- Fine Area Manuale
        i_oldop   = i_op
        i_op      = OP_ZOOM
        i_zoomprg = ''
        exit
      case i_function="PgDn" .and. i_pag<5
        i_pag = i_pag+1
        do F_Paint with 0
      case i_function="PgUp" .and. i_pag>1
        i_pag = i_pag-1
        do F_Paint with 0
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
        i_op = OP_QUIT
    endcase
  enddo
  set order to 1
  return

function find_record
  parameter n_key
  * --- Area Manuale = Query Chkread1
  * --- Fine Area Manuale
  if updated()
    do case
      case n_key=1
        seek w_PA1111+ALLTRIM(w_PA1112)+ALLTRIM(w_PA112)
    endcase
    do f_r
  endif
  return .t.

function F_Load
  do F_KeyEdit
  if i_op<>OP_INTR .and. i_op<>OP_ZOOM
    if i_op=OP_QUIT
      i_op = iif(wvisible("gopa_arx"),OP_QUERY,OP_QUIT)
    else
      seek w_PA1111+ALLTRIM(w_PA1112)+ALLTRIM(w_PA112)
      * --- Area Manuale = Load Key Check
      * --- Fine Area Manuale
      if found()
        do cplu_erm with w_t_msldbl
      else
        private i_err,i_olderror
        i_err=.f.
        i_olderror=on('ERROR')
        on error i_err=.t.
        append blank
        on error &i_olderror
        if i_err
          do cplu_erm with "File bloccato"
        else
          w_multi = rlock()
          * --- Area Manuale = Load Key Replace
          * --- Fine Area Manuale
          replace PA1111 with w_PA1111
          replace PA1112 with w_PA1112
          replace PA112 with w_PA112
          flush
          i_op = OP_EDITLOAD
          i_docreco = recno()
          do cplu_alk with "FTPA_XML",.t.
        endif
      endif
    endif
  endif
  return .t.

* === OpenProc
*     definisce la finestra, blank alle variabili di lavoro
procedure OpenProc
  private i_ok,i_ay,i_pv,i_wnd
  i_ok = OpenFiles()
  i_ay = 1.5
  i_wnd = iif(empty(wontop()) or wontop()="BUTTONS","","in window ('"+wontop()+"')")
  if i_ok
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
    i_twind = "system name wnd_gopa_arx"
    i_pv=at_y(10)
    #else
    i_twind = "close grow"
    i_pv=iif(i_vtoolbar,at_y(10),max(at_y(10),2.8))
    #endif
    * ---
    do case
      case _windows
        define window "gopa_arx" at i_pv,at_x(10) size at_y(483,"Arial",9,"")+i_ay,at_x(757,"Arial",9,"");
          font "Arial",9;
          title "FATTURE  PA";
          minimize float &i_twind icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

        modify window "gopa_arx" at i_pv,at_x(10) size at_y(483,"Arial",9,"")+i_ay,at_x(757,"Arial",9,"")
      case _mac
        i_pv=iif(i_vtoolbar,at_y(10),max(at_y(10),2.8))
        define window "gopa_arx" at i_pv,at_x(10) size at_y(483,"Arial",9*4/3,"")+i_ay,at_x(757,"Arial",9*4/3,"");
          font "Arial",9*4/3;
          title "FATTURE  PA";
          minimize float close grow icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

      otherwise
        define window "gopa_arx" from 1,1 to 24,80;
          title "  FATTURE  PA  ";
          minimize float close  "�","�","�","�","�","�","�","�";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

    endcase
  set topic to 'FATTURE PA XML (anagrafica)'
  endif
  return i_ok

* === OpenFiles
function OpenFiles
  private i_ok,i_w1,i_w2,i_w3
  i_ok = .t.
  * --- Apertura dei files
  i_w2 = cplu_opf("BEN_EFIC",'')
  i_w3 = cplu_opf("FTPA_PAG",'')
  i_w1 = cplu_opf("FTPA_XML",'')
  if .not.(i_w1 .and. i_w2 .and. i_w3)
    i_ok = .f.
    do cplu_clf with "FTPA_XML",i_w1,''
    do cplu_clf with "BEN_EFIC",i_w2,''
    do cplu_clf with "FTPA_PAG",i_w3,''
  endif
  return i_ok

* === CloseProc
procedure CloseProc
  release window "gopa_arx"
  do CloseFiles
  * --- Fp3
  #if left(version(),13)="Visual FoxPro"
    oCpToolBar.Enable(.f.)
  #endif
  * ---
  return

* === CloseFiles
procedure CloseFiles
  do cplu_clf with "FTPA_XML",.t.,''
  do cplu_clf with "BEN_EFIC",.t.,''
  do cplu_clf with "FTPA_PAG",.t.,''
  return

procedure RestoreStatus
  private i_zop
  i_docreco = s_gopa_arx[1]
  i_oldop   = s_gopa_arx[2]
  i_zoomprg = s_gopa_arx[3]
  i_campo   = s_gopa_arx[4]
  i_campoq  = s_gopa_arx[5]
  i_pag     = s_gopa_arx[6]
  i_loaded  = s_gopa_arx[7]
  i_zbrow   = s_gopa_arx[8]
  i_zop     = substr(i_zoomprg,4,len(i_zoomprg)-3)
  i_op      = iif(.not. empty(i_zoomprg) .and. (wvisible(i_zop) .or. .not. i_zbrow),OP_ZOOM,i_oldop)
  w_PANRPROT = s_gopa_arx[9]
  w_PADTPROT = s_gopa_arx[10]
  w_PA21112 = s_gopa_arx[11]
  w_PA2111 = s_gopa_arx[12]
  w_PA2112 = s_gopa_arx[13]
  w_PA2113 = s_gopa_arx[14]
  w_PA2114 = s_gopa_arx[15]
  w_PA21151 = s_gopa_arx[16]
  w_PA21152 = s_gopa_arx[17]
  w_PA21153 = s_gopa_arx[18]
  w_PA21154 = s_gopa_arx[19]
  w_PA2119 = s_gopa_arx[20]
  w_PA21110 = s_gopa_arx[21]
  w_PA21111 = s_gopa_arx[22]
  w_PAPATHFL = s_gopa_arx[23]
  w_PA126 = s_gopa_arx[24]
  w_PA12133 = s_gopa_arx[25]
  w_PA12134 = s_gopa_arx[26]
  w_PA12135 = s_gopa_arx[27]
  w_PA1221 = s_gopa_arx[28]
  w_PA1222 = s_gopa_arx[29]
  w_PA1223 = s_gopa_arx[30]
  w_PA1224 = s_gopa_arx[31]
  w_PA1225 = s_gopa_arx[32]
  w_PA1226 = s_gopa_arx[33]
  w_PA1251 = s_gopa_arx[34]
  w_PA1252 = s_gopa_arx[35]
  w_PA1253 = s_gopa_arx[36]
  w_PA12111 = s_gopa_arx[37]
  w_PA12112 = s_gopa_arx[38]
  w_PA1212 = s_gopa_arx[39]
  w_PA12132 = s_gopa_arx[40]
  w_PA241 = s_gopa_arx[41]
  w_PA2421 = s_gopa_arx[42]
  w_PA2422 = s_gopa_arx[43]
  w_PA2423 = s_gopa_arx[44]
  w_PA2424 = s_gopa_arx[45]
  w_PA2425 = s_gopa_arx[46]
  w_PA2426 = s_gopa_arx[47]
  w_PA2427 = s_gopa_arx[48]
  w_PA2428 = s_gopa_arx[49]
  w_PA2429 = s_gopa_arx[50]
  w_PA24210 = s_gopa_arx[51]
  w_PA24212 = s_gopa_arx[52]
  w_PA24213 = s_gopa_arx[53]
  w_PA24214 = s_gopa_arx[54]
  w_PA24215 = s_gopa_arx[55]
  w_PA24216 = s_gopa_arx[56]
  w_PA24217 = s_gopa_arx[57]
  w_PA24218 = s_gopa_arx[58]
  w_PA24219 = s_gopa_arx[59]
  w_PA24220 = s_gopa_arx[60]
  w_PA24221 = s_gopa_arx[61]
  w_PA24211 = s_gopa_arx[62]
  w_PA1111 = s_gopa_arx[63]
  w_PA1112 = s_gopa_arx[64]
  w_PA112 = s_gopa_arx[65]
  w_PA113 = s_gopa_arx[66]
  w_PA114 = s_gopa_arx[67]
  w_PA1151 = s_gopa_arx[68]
  w_PA1152 = s_gopa_arx[69]
  w_PA12131 = s_gopa_arx[70]
  w_PA12131 = s_gopa_arx[71]
  w_PAIMPEGN = s_gopa_arx[72]
  w_PA_ESITO = s_gopa_arx[73]
  w_FILEESITO = s_gopa_arx[74]
  w_PAPRGINV = s_gopa_arx[75]
  w_PA_IDSDI = s_gopa_arx[76]
  w_PAESICAU = s_gopa_arx[77]
  w_NIMP = s_gopa_arx[78]
  w_DIMP = s_gopa_arx[79]
  w_CVG = s_gopa_arx[80]
  w_DESPA = s_gopa_arx[81]
  w_PA2126 = s_gopa_arx[82]
  w_PA2127 = s_gopa_arx[83]
  w_PA_IDCOM = s_gopa_arx[84]
  w_PAPROGID = s_gopa_arx[85]
  w_PAANPROT = s_gopa_arx[86]
  w_PACODBEN = s_gopa_arx[87]
  o_PADTPROT = w_PADTPROT
  do RestoreFilters
  do Ass_pos
  return

procedure RestoreFilters
  select FTPA_XML
  i_warea = "FTPA_XML"
  set filter to 
  do cplu_go with i_docreco
  do Set_Radio
  set topic to 'FATTURE PA XML (anagrafica)'
  return

procedure SaveStatus
  s_gopa_arx[1] = i_docreco
  s_gopa_arx[2] = i_oldop
  s_gopa_arx[3] = i_zoomprg
  s_gopa_arx[4] = i_campo
  s_gopa_arx[5] = i_campoq
  s_gopa_arx[6] = i_pag
  s_gopa_arx[7] = i_loaded
  s_gopa_arx[8] = i_zbrow
  s_gopa_arx[9] = w_PANRPROT
  s_gopa_arx[10] = w_PADTPROT
  s_gopa_arx[11] = w_PA21112
  s_gopa_arx[12] = w_PA2111
  s_gopa_arx[13] = w_PA2112
  s_gopa_arx[14] = w_PA2113
  s_gopa_arx[15] = w_PA2114
  s_gopa_arx[16] = w_PA21151
  s_gopa_arx[17] = w_PA21152
  s_gopa_arx[18] = w_PA21153
  s_gopa_arx[19] = w_PA21154
  s_gopa_arx[20] = w_PA2119
  s_gopa_arx[21] = w_PA21110
  s_gopa_arx[22] = w_PA21111
  s_gopa_arx[23] = w_PAPATHFL
  s_gopa_arx[24] = w_PA126
  s_gopa_arx[25] = w_PA12133
  s_gopa_arx[26] = w_PA12134
  s_gopa_arx[27] = w_PA12135
  s_gopa_arx[28] = w_PA1221
  s_gopa_arx[29] = w_PA1222
  s_gopa_arx[30] = w_PA1223
  s_gopa_arx[31] = w_PA1224
  s_gopa_arx[32] = w_PA1225
  s_gopa_arx[33] = w_PA1226
  s_gopa_arx[34] = w_PA1251
  s_gopa_arx[35] = w_PA1252
  s_gopa_arx[36] = w_PA1253
  s_gopa_arx[37] = w_PA12111
  s_gopa_arx[38] = w_PA12112
  s_gopa_arx[39] = w_PA1212
  s_gopa_arx[40] = w_PA12132
  s_gopa_arx[41] = w_PA241
  s_gopa_arx[42] = w_PA2421
  s_gopa_arx[43] = w_PA2422
  s_gopa_arx[44] = w_PA2423
  s_gopa_arx[45] = w_PA2424
  s_gopa_arx[46] = w_PA2425
  s_gopa_arx[47] = w_PA2426
  s_gopa_arx[48] = w_PA2427
  s_gopa_arx[49] = w_PA2428
  s_gopa_arx[50] = w_PA2429
  s_gopa_arx[51] = w_PA24210
  s_gopa_arx[52] = w_PA24212
  s_gopa_arx[53] = w_PA24213
  s_gopa_arx[54] = w_PA24214
  s_gopa_arx[55] = w_PA24215
  s_gopa_arx[56] = w_PA24216
  s_gopa_arx[57] = w_PA24217
  s_gopa_arx[58] = w_PA24218
  s_gopa_arx[59] = w_PA24219
  s_gopa_arx[60] = w_PA24220
  s_gopa_arx[61] = w_PA24221
  s_gopa_arx[62] = w_PA24211
  s_gopa_arx[63] = w_PA1111
  s_gopa_arx[64] = w_PA1112
  s_gopa_arx[65] = w_PA112
  s_gopa_arx[66] = w_PA113
  s_gopa_arx[67] = w_PA114
  s_gopa_arx[68] = w_PA1151
  s_gopa_arx[69] = w_PA1152
  s_gopa_arx[70] = w_PA12131
  s_gopa_arx[71] = w_PA12131
  s_gopa_arx[72] = w_PAIMPEGN
  s_gopa_arx[73] = w_PA_ESITO
  s_gopa_arx[74] = w_FILEESITO
  s_gopa_arx[75] = w_PAPRGINV
  s_gopa_arx[76] = w_PA_IDSDI
  s_gopa_arx[77] = w_PAESICAU
  s_gopa_arx[78] = w_NIMP
  s_gopa_arx[79] = w_DIMP
  s_gopa_arx[80] = w_CVG
  s_gopa_arx[81] = w_DESPA
  s_gopa_arx[82] = w_PA2126
  s_gopa_arx[83] = w_PA2127
  s_gopa_arx[84] = w_PA_IDCOM
  s_gopa_arx[85] = w_PAPROGID
  s_gopa_arx[86] = w_PAANPROT
  s_gopa_arx[87] = w_PACODBEN
  return

* === Ass_Pos
procedure Ass_Pos
  private i_wx, i_wy, i_ay
  activate window "gopa_arx" noshow same
  i_wx = fontmetric(6)
  i_wy = fontmetric(1)
  i_ay = 1.5
  do case
    case _windows
      do Ass_Pos_Win
    case _mac
      do Ass_Pos_Mac
    otherwise
      do Ass_Pos_Unkn
  endcase
  return

procedure Ass_Pos_Win
      i_posyx1[1,1] = i_ay+(39/i_wy) && at_y(39)
      i_posyx1[1,2] = 157/i_wx && at_x(157)
      i_size1[1,1] = 1
      i_size1[1,2] = cp_intsz(84/i_wx)
      i_posyx1[2,1] = i_ay+(39/i_wy) && at_y(39)
      i_posyx1[2,2] = 352/i_wx && at_x(352)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(77/i_wx)
      i_posyx1[3,1] = i_ay+(361/i_wy) && at_y(361)
      i_posyx1[3,2] = 157/i_wx && at_x(157)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(28/i_wx)
      i_posyx1[4,1] = i_ay+(363/i_wy) && at_y(363)
      i_posyx1[4,2] = 115/i_wx && at_x(115)
      i_posyx1[5,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[5,2] = 157/i_wx && at_x(157)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(42/i_wx)
      i_posyx1[6,1] = i_ay+(73/i_wy) && at_y(73)
      i_posyx1[6,2] = 57/i_wx && at_x(57)
      i_posyx1[7,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[7,2] = 662/i_wx && at_x(662)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(35/i_wx)
      i_posyx1[8,1] = i_ay+(73/i_wy) && at_y(73)
      i_posyx1[8,2] = 620/i_wx && at_x(620)
      i_posyx1[9,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[9,2] = 451/i_wx && at_x(451)
      i_size1[9,1] = 1
      i_size1[9,2] = cp_intsz(70/i_wx)
      i_posyx1[10,1] = i_ay+(73/i_wy) && at_y(73)
      i_posyx1[10,2] = 417/i_wx && at_x(417)
      i_posyx1[11,1] = i_ay+(72/i_wy) && at_y(72)
      i_posyx1[11,2] = 257/i_wx && at_x(257)
      i_size1[11,1] = 1
      i_size1[11,2] = cp_intsz(154/i_wx)
      i_posyx1[12,1] = i_ay+(73/i_wy) && at_y(73)
      i_posyx1[12,2] = 200/i_wx && at_x(200)
      i_posyx1[13,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[13,2] = 157/i_wx && at_x(157)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(42/i_wx)
      i_posyx1[14,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[14,2] = 77/i_wx && at_x(77)
      i_posyx1[15,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[15,2] = 316/i_wx && at_x(316)
      i_size1[15,1] = 1
      i_size1[15,2] = cp_intsz(98/i_wx)
      i_posyx1[16,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[16,2] = 211/i_wx && at_x(211)
      i_posyx1[17,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[17,2] = 536/i_wx && at_x(536)
      i_size1[17,1] = 1
      i_size1[17,2] = cp_intsz(56/i_wx)
      i_posyx1[18,1] = i_ay+(197/i_wy) && at_y(197)
      i_posyx1[18,2] = 434/i_wx && at_x(434)
      i_posyx1[19,1] = i_ay+(221/i_wy) && at_y(221)
      i_posyx1[19,2] = 157/i_wx && at_x(157)
      i_size1[19,1] = 1
      i_size1[19,2] = cp_intsz(28/i_wx)
      i_posyx1[20,1] = i_ay+(222/i_wy) && at_y(222)
      i_posyx1[20,2] = 36/i_wx && at_x(36)
      i_posyx1[21,1] = i_ay+(163/i_wy) && at_y(163)
      i_posyx1[21,2] = 157/i_wx && at_x(157)
      i_size1[21,1] = 1
      i_size1[21,2] = cp_intsz(112/i_wx)
      i_posyx1[22,1] = i_ay+(163/i_wy) && at_y(163)
      i_posyx1[22,2] = 5/i_wx && at_x(5)
      i_posyx1[23,1] = i_ay+(163/i_wy) && at_y(163)
      i_posyx1[23,2] = 377/i_wx && at_x(377)
      i_size1[23,1] = 1
      i_size1[23,2] = cp_intsz(112/i_wx)
      i_posyx1[24,1] = i_ay+(163/i_wy) && at_y(163)
      i_posyx1[24,2] = 280/i_wx && at_x(280)
      i_posyx1[25,1] = i_ay+(257/i_wy) && at_y(257)
      i_posyx1[25,2] = 157/i_wx && at_x(157)
      i_size1[25,1] = cp_intsz(at_y(52))
      i_size1[25,2] = cp_intsz(595/i_wx)
      i_posyx1[26,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx1[26,2] = 75/i_wx && at_x(75)
      i_posyx1[27,1] = i_ay+(396/i_wy) && at_y(396)
      i_posyx1[27,2] = 157/i_wx && at_x(157)
      i_size1[27,1] = cp_intsz(at_y(17))
      i_size1[27,2] = cp_intsz(595/i_wx)
      i_posyx1[28,1] = i_ay+(397/i_wy) && at_y(397)
      i_posyx1[28,2] = 83/i_wx && at_x(83)
      i_posyx1[33,1] = i_ay+(433/i_wy) && at_y(433)
      i_posyx1[33,2] = 13/i_wx && at_x(13)
      i_size1[33,1] = at_y(50)
      i_size1[33,2] = cp_intsz(71/i_wx)
      i_posyx1[36,1] = i_ay+(136/i_wy) && at_y(136)
      i_posyx1[36,2] = 52/i_wx && at_x(52)
      i_posyx1[37,1] = i_ay+(135/i_wy) && at_y(135)
      i_posyx1[37,2] = 157/i_wx && at_x(157)
      i_size1[37,1] = 1
      i_size1[37,2] = cp_intsz(595/i_wx)
      i_posyx1[39,1] = i_ay+(315/i_wy) && at_y(315)
      i_posyx1[39,2] = 157/i_wx && at_x(157)
      i_size1[39,1] = 1
      i_size1[39,2] = cp_intsz(595/i_wx)
      i_posyx1[40,1] = i_ay+(338/i_wy) && at_y(338)
      i_posyx1[40,2] = 157/i_wx && at_x(157)
      i_size1[40,1] = 1
      i_size1[40,2] = cp_intsz(595/i_wx)
      i_posyx1[41,1] = i_ay+(340/i_wy) && at_y(340)
      i_posyx1[41,2] = 90/i_wx && at_x(90)
      i_posyx1[42,1] = i_ay+(316/i_wy) && at_y(316)
      i_posyx1[42,2] = 85/i_wx && at_x(85)
      i_posyx1[43,1] = i_ay+(13/i_wy) && at_y(13)
      i_posyx1[43,2] = 157/i_wx && at_x(157)
      i_size1[43,1] = 1
      i_size1[43,2] = cp_intsz(84/i_wx)
      i_posyx1[45,1] = i_ay+(14/i_wy) && at_y(14)
      i_posyx1[45,2] = 44/i_wx && at_x(44)
      i_posyx1[46,1] = i_ay+(41/i_wy) && at_y(41)
      i_posyx1[46,2] = 48/i_wx && at_x(48)
      i_posyx1[47,1] = i_ay+(41/i_wy) && at_y(41)
      i_posyx1[47,2] = 247/i_wx && at_x(247)
      i_posyx1[48,1] = i_ay+(109/i_wy) && at_y(109)
      i_posyx1[48,2] = 13/i_wx && at_x(13)
      i_posyx1[49,1] = i_ay+(108/i_wy) && at_y(108)
      i_posyx1[49,2] = 157/i_wx && at_x(157)
      i_size1[49,1] = 1
      i_size1[49,2] = cp_intsz(126/i_wx)
      i_posyx2[1,1] = i_ay+(417/i_wy) && at_y(417)
      i_posyx2[1,2] = 167/i_wx && at_x(167)
      i_size2[1,1] = 1
      i_size2[1,2] = cp_intsz(154/i_wx)
      i_posyx2[2,1] = i_ay+(418/i_wy) && at_y(418)
      i_posyx2[2,2] = 0/i_wx && at_x(0)
      i_posyx2[3,1] = i_ay+(133/i_wy) && at_y(133)
      i_posyx2[3,2] = 167/i_wx && at_x(167)
      i_size2[3,1] = 1
      i_size2[3,2] = cp_intsz(434/i_wx)
      i_posyx2[4,1] = i_ay+(134/i_wy) && at_y(134)
      i_posyx2[4,2] = 101/i_wx && at_x(101)
      i_posyx2[6,1] = i_ay+(156/i_wy) && at_y(156)
      i_posyx2[6,2] = 167/i_wx && at_x(167)
      i_size2[6,1] = 1
      i_size2[6,2] = cp_intsz(133/i_wx)
      i_posyx2[7,1] = i_ay+(157/i_wy) && at_y(157)
      i_posyx2[7,2] = 91/i_wx && at_x(91)
      i_posyx2[8,1] = i_ay+(190/i_wy) && at_y(190)
      i_posyx2[8,2] = 167/i_wx && at_x(167)
      i_size2[8,1] = 1
      i_size2[8,2] = cp_intsz(574/i_wx)
      i_posyx2[9,1] = i_ay+(191/i_wy) && at_y(191)
      i_posyx2[9,2] = 115/i_wx && at_x(115)
      i_posyx2[10,1] = i_ay+(213/i_wy) && at_y(213)
      i_posyx2[10,2] = 167/i_wx && at_x(167)
      i_size2[10,1] = 1
      i_size2[10,2] = cp_intsz(70/i_wx)
      i_posyx2[11,1] = i_ay+(214/i_wy) && at_y(214)
      i_posyx2[11,2] = 81/i_wx && at_x(81)
      i_posyx2[12,1] = i_ay+(236/i_wy) && at_y(236)
      i_posyx2[12,2] = 167/i_wx && at_x(167)
      i_size2[12,1] = 1
      i_size2[12,2] = cp_intsz(49/i_wx)
      i_posyx2[13,1] = i_ay+(237/i_wy) && at_y(237)
      i_posyx2[13,2] = 126/i_wx && at_x(126)
      i_posyx2[14,1] = i_ay+(259/i_wy) && at_y(259)
      i_posyx2[14,2] = 167/i_wx && at_x(167)
      i_size2[14,1] = 1
      i_size2[14,2] = cp_intsz(574/i_wx)
      i_posyx2[15,1] = i_ay+(260/i_wy) && at_y(260)
      i_posyx2[15,2] = 104/i_wx && at_x(104)
      i_posyx2[16,1] = i_ay+(282/i_wy) && at_y(282)
      i_posyx2[16,2] = 167/i_wx && at_x(167)
      i_size2[16,1] = 1
      i_size2[16,2] = cp_intsz(28/i_wx)
      i_posyx2[17,1] = i_ay+(283/i_wy) && at_y(283)
      i_posyx2[17,2] = 103/i_wx && at_x(103)
      i_posyx2[18,1] = i_ay+(305/i_wy) && at_y(305)
      i_posyx2[18,2] = 167/i_wx && at_x(167)
      i_size2[18,1] = 1
      i_size2[18,2] = cp_intsz(28/i_wx)
      i_posyx2[19,1] = i_ay+(306/i_wy) && at_y(306)
      i_posyx2[19,2] = 109/i_wx && at_x(109)
      i_posyx2[20,1] = i_ay+(338/i_wy) && at_y(338)
      i_posyx2[20,2] = 167/i_wx && at_x(167)
      i_size2[20,1] = 1
      i_size2[20,2] = cp_intsz(98/i_wx)
      i_posyx2[21,1] = i_ay+(339/i_wy) && at_y(339)
      i_posyx2[21,2] = 107/i_wx && at_x(107)
      i_posyx2[22,1] = i_ay+(361/i_wy) && at_y(361)
      i_posyx2[22,2] = 167/i_wx && at_x(167)
      i_size2[22,1] = 1
      i_size2[22,2] = cp_intsz(98/i_wx)
      i_posyx2[23,1] = i_ay+(362/i_wy) && at_y(362)
      i_posyx2[23,2] = 135/i_wx && at_x(135)
      i_posyx2[24,1] = i_ay+(384/i_wy) && at_y(384)
      i_posyx2[24,2] = 167/i_wx && at_x(167)
      i_size2[24,1] = cp_intsz(at_y(17))
      i_size2[24,2] = cp_intsz(574/i_wx)
      i_posyx2[25,1] = i_ay+(385/i_wy) && at_y(385)
      i_posyx2[25,2] = 119/i_wx && at_x(119)
      i_posyx2[26,1] = i_ay+(29/i_wy) && at_y(29)
      i_posyx2[26,2] = 167/i_wx && at_x(167)
      i_size2[26,1] = 1
      i_size2[26,2] = cp_intsz(23/i_wx)
      i_posyx2[27,1] = i_ay+(30/i_wy) && at_y(30)
      i_posyx2[27,2] = 5/i_wx && at_x(5)
      i_posyx2[28,1] = i_ay+(29/i_wy) && at_y(29)
      i_posyx2[28,2] = 197/i_wx && at_x(197)
      i_size2[28,1] = 1
      i_size2[28,2] = cp_intsz(96/i_wx)
      i_posyx2[29,1] = i_ay+(52/i_wy) && at_y(52)
      i_posyx2[29,2] = 167/i_wx && at_x(167)
      i_size2[29,1] = 1
      i_size2[29,2] = cp_intsz(126/i_wx)
      i_posyx2[30,1] = i_ay+(53/i_wy) && at_y(53)
      i_posyx2[30,2] = 76/i_wx && at_x(76)
      i_posyx2[31,1] = i_ay+(110/i_wy) && at_y(110)
      i_posyx2[31,2] = 167/i_wx && at_x(167)
      i_size2[31,1] = 1
      i_size2[31,2] = cp_intsz(434/i_wx)
      i_posyx2[32,1] = i_ay+(111/i_wy) && at_y(111)
      i_posyx2[32,2] = 52/i_wx && at_x(52)
      i_posyx2[37,1] = i_ay+(76/i_wy) && at_y(76)
      i_posyx2[37,2] = 63/i_wx && at_x(63)
      i_posyx2[38,1] = i_ay+(75/i_wy) && at_y(75)
      i_posyx2[38,2] = 167/i_wx && at_x(167)
      i_size2[38,1] = 1
      i_size2[38,2] = cp_intsz(574/i_wx)
      i_posyx3[1,1] = i_ay+(12/i_wy) && at_y(12)
      i_posyx3[1,2] = 234/i_wx && at_x(234)
      i_posyx3[2,1] = i_ay+(13/i_wy) && at_y(13)
      i_posyx3[2,2] = 85/i_wx && at_x(85)
      i_posyx3[3,1] = i_ay+(35/i_wy) && at_y(35)
      i_posyx3[3,2] = 234/i_wx && at_x(234)
      i_size3[3,1] = cp_intsz(at_y(17))
      i_size3[3,2] = cp_intsz(489/i_wx)
      i_posyx3[4,1] = i_ay+(36/i_wy) && at_y(36)
      i_posyx3[4,2] = 148/i_wx && at_x(148)
      i_posyx3[5,1] = i_ay+(68/i_wy) && at_y(68)
      i_posyx3[5,2] = 234/i_wx && at_x(234)
      i_size3[5,1] = 1
      i_size3[5,2] = cp_intsz(42/i_wx)
      i_posyx3[6,1] = i_ay+(69/i_wy) && at_y(69)
      i_posyx3[6,2] = 114/i_wx && at_x(114)
      i_posyx3[7,1] = i_ay+(91/i_wy) && at_y(91)
      i_posyx3[7,2] = 234/i_wx && at_x(234)
      i_size3[7,1] = 1
      i_size3[7,2] = cp_intsz(70/i_wx)
      i_posyx3[8,1] = i_ay+(93/i_wy) && at_y(93)
      i_posyx3[8,2] = 23/i_wx && at_x(23)
      i_posyx3[9,1] = i_ay+(91/i_wy) && at_y(91)
      i_posyx3[9,2] = 467/i_wx && at_x(467)
      i_size3[9,1] = 1
      i_size3[9,2] = cp_intsz(35/i_wx)
      i_posyx3[10,1] = i_ay+(93/i_wy) && at_y(93)
      i_posyx3[10,2] = 316/i_wx && at_x(316)
      i_posyx3[11,1] = i_ay+(114/i_wy) && at_y(114)
      i_posyx3[11,2] = 234/i_wx && at_x(234)
      i_size3[11,1] = 1
      i_size3[11,2] = cp_intsz(70/i_wx)
      i_posyx3[12,1] = i_ay+(115/i_wy) && at_y(115)
      i_posyx3[12,2] = 74/i_wx && at_x(74)
      i_posyx3[13,1] = i_ay+(137/i_wy) && at_y(137)
      i_posyx3[13,2] = 234/i_wx && at_x(234)
      i_size3[13,1] = 1
      i_size3[13,2] = cp_intsz(98/i_wx)
      i_posyx3[14,1] = i_ay+(138/i_wy) && at_y(138)
      i_posyx3[14,2] = 116/i_wx && at_x(116)
      i_posyx3[15,1] = i_ay+(170/i_wy) && at_y(170)
      i_posyx3[15,2] = 234/i_wx && at_x(234)
      i_size3[15,1] = 1
      i_size3[15,2] = cp_intsz(154/i_wx)
      i_posyx3[16,1] = i_ay+(171/i_wy) && at_y(171)
      i_posyx3[16,2] = 108/i_wx && at_x(108)
      i_posyx3[17,1] = i_ay+(202/i_wy) && at_y(202)
      i_posyx3[17,2] = 234/i_wx && at_x(234)
      i_size3[17,1] = 1
      i_size3[17,2] = cp_intsz(434/i_wx)
      i_posyx3[18,1] = i_ay+(203/i_wy) && at_y(203)
      i_posyx3[18,2] = 96/i_wx && at_x(96)
      i_posyx3[19,1] = i_ay+(225/i_wy) && at_y(225)
      i_posyx3[19,2] = 234/i_wx && at_x(234)
      i_size3[19,1] = 1
      i_size3[19,2] = cp_intsz(434/i_wx)
      i_posyx3[20,1] = i_ay+(226/i_wy) && at_y(226)
      i_posyx3[20,2] = 117/i_wx && at_x(117)
      i_posyx3[21,1] = i_ay+(248/i_wy) && at_y(248)
      i_posyx3[21,2] = 234/i_wx && at_x(234)
      i_size3[21,1] = 1
      i_size3[21,2] = cp_intsz(126/i_wx)
      i_posyx3[22,1] = i_ay+(249/i_wy) && at_y(249)
      i_posyx3[22,2] = 128/i_wx && at_x(128)
      i_posyx3[23,1] = i_ay+(281/i_wy) && at_y(281)
      i_posyx3[23,2] = 234/i_wx && at_x(234)
      i_size3[23,1] = 1
      i_size3[23,2] = cp_intsz(489/i_wx)
      i_posyx3[24,1] = i_ay+(282/i_wy) && at_y(282)
      i_posyx3[24,2] = 122/i_wx && at_x(122)
      i_posyx3[25,1] = i_ay+(304/i_wy) && at_y(304)
      i_posyx3[25,2] = 412/i_wx && at_x(412)
      i_size3[25,1] = 1
      i_size3[25,2] = cp_intsz(252/i_wx)
      i_posyx3[26,1] = i_ay+(305/i_wy) && at_y(305)
      i_posyx3[26,2] = 376/i_wx && at_x(376)
      i_posyx3[27,1] = i_ay+(304/i_wy) && at_y(304)
      i_posyx3[27,2] = 234/i_wx && at_x(234)
      i_size3[27,1] = 1
      i_size3[27,2] = cp_intsz(49/i_wx)
      i_posyx3[28,1] = i_ay+(305/i_wy) && at_y(305)
      i_posyx3[28,2] = 199/i_wx && at_x(199)
      i_posyx3[29,1] = i_ay+(304/i_wy) && at_y(304)
      i_posyx3[29,2] = 320/i_wx && at_x(320)
      i_size3[29,1] = 1
      i_size3[29,2] = cp_intsz(49/i_wx)
      i_posyx3[30,1] = i_ay+(305/i_wy) && at_y(305)
      i_posyx3[30,2] = 288/i_wx && at_x(288)
      i_posyx3[31,1] = i_ay+(327/i_wy) && at_y(327)
      i_posyx3[31,2] = 234/i_wx && at_x(234)
      i_size3[31,1] = 1
      i_size3[31,2] = cp_intsz(91/i_wx)
      i_posyx3[32,1] = i_ay+(328/i_wy) && at_y(328)
      i_posyx3[32,2] = 204/i_wx && at_x(204)
      i_posyx3[33,1] = i_ay+(361/i_wy) && at_y(361)
      i_posyx3[33,2] = 233/i_wx && at_x(233)
      i_size3[33,1] = 1
      i_size3[33,2] = cp_intsz(98/i_wx)
      i_posyx3[34,1] = i_ay+(362/i_wy) && at_y(362)
      i_posyx3[34,2] = 63/i_wx && at_x(63)
      i_posyx3[35,1] = i_ay+(384/i_wy) && at_y(384)
      i_posyx3[35,2] = 233/i_wx && at_x(233)
      i_size3[35,1] = 1
      i_size3[35,2] = cp_intsz(70/i_wx)
      i_posyx3[36,1] = i_ay+(385/i_wy) && at_y(385)
      i_posyx3[36,2] = 43/i_wx && at_x(43)
      i_posyx3[37,1] = i_ay+(407/i_wy) && at_y(407)
      i_posyx3[37,2] = 233/i_wx && at_x(233)
      i_size3[37,1] = 1
      i_size3[37,2] = cp_intsz(98/i_wx)
      i_posyx3[38,1] = i_ay+(408/i_wy) && at_y(408)
      i_posyx3[38,2] = 67/i_wx && at_x(67)
      i_posyx3[39,1] = i_ay+(430/i_wy) && at_y(430)
      i_posyx3[39,2] = 233/i_wx && at_x(233)
      i_size3[39,1] = 1
      i_size3[39,2] = cp_intsz(70/i_wx)
      i_posyx3[40,1] = i_ay+(431/i_wy) && at_y(431)
      i_posyx3[40,2] = 94/i_wx && at_x(94)
      i_posyx3[41,1] = i_ay+(453/i_wy) && at_y(453)
      i_posyx3[41,2] = 233/i_wx && at_x(233)
      i_size3[41,1] = 1
      i_size3[41,2] = cp_intsz(434/i_wx)
      i_posyx3[42,1] = i_ay+(454/i_wy) && at_y(454)
      i_posyx3[42,2] = 118/i_wx && at_x(118)
      i_posyx3[49,1] = i_ay+(68/i_wy) && at_y(68)
      i_posyx3[49,2] = 280/i_wx && at_x(280)
      i_size3[49,1] = 1
      i_size3[49,2] = cp_intsz(443/i_wx)
      i_posyx4[1,1] = i_ay+(51/i_wy) && at_y(51)
      i_posyx4[1,2] = 188/i_wx && at_x(188)
      i_size4[1,1] = 1
      i_size4[1,2] = cp_intsz(28/i_wx)
      i_posyx4[2,1] = i_ay+(52/i_wy) && at_y(52)
      i_posyx4[2,2] = 28/i_wx && at_x(28)
      i_posyx4[3,1] = i_ay+(51/i_wy) && at_y(51)
      i_posyx4[3,2] = 222/i_wx && at_x(222)
      i_size4[3,1] = 1
      i_size4[3,2] = cp_intsz(210/i_wx)
      i_posyx4[4,1] = i_ay+(75/i_wy) && at_y(75)
      i_posyx4[4,2] = 188/i_wx && at_x(188)
      i_size4[4,1] = 1
      i_size4[4,2] = cp_intsz(84/i_wx)
      i_posyx4[5,1] = i_ay+(76/i_wy) && at_y(76)
      i_posyx4[5,2] = 85/i_wx && at_x(85)
      i_posyx4[6,1] = i_ay+(98/i_wy) && at_y(98)
      i_posyx4[6,2] = 188/i_wx && at_x(188)
      i_size4[6,1] = 1
      i_size4[6,2] = cp_intsz(49/i_wx)
      i_posyx4[7,1] = i_ay+(99/i_wy) && at_y(99)
      i_posyx4[7,2] = 53/i_wx && at_x(53)
      i_posyx4[8,1] = i_ay+(121/i_wy) && at_y(121)
      i_posyx4[8,2] = 188/i_wx && at_x(188)
      i_size4[8,1] = 1
      i_size4[8,2] = cp_intsz(70/i_wx)
      i_posyx4[9,1] = i_ay+(122/i_wy) && at_y(122)
      i_posyx4[9,2] = 70/i_wx && at_x(70)
      i_posyx4[10,1] = i_ay+(160/i_wy) && at_y(160)
      i_posyx4[10,2] = 188/i_wx && at_x(188)
      i_size4[10,1] = 1
      i_size4[10,2] = cp_intsz(98/i_wx)
      i_posyx4[11,1] = i_ay+(161/i_wy) && at_y(161)
      i_posyx4[11,2] = 130/i_wx && at_x(130)
      i_posyx4[12,1] = i_ay+(183/i_wy) && at_y(183)
      i_posyx4[12,2] = 188/i_wx && at_x(188)
      i_size4[12,1] = cp_intsz(at_y(17))
      i_size4[12,2] = cp_intsz(567/i_wx)
      i_posyx4[13,1] = i_ay+(184/i_wy) && at_y(184)
      i_posyx4[13,2] = 147/i_wx && at_x(147)
      i_posyx5[1,1] = i_ay+(74/i_wy) && at_y(74)
      i_posyx5[1,2] = 340/i_wx && at_x(340)
      i_size5[1,1] = at_y(50)
      i_size5[1,2] = cp_intsz(122/i_wx)
      i_posyx5[3,1] = i_ay+(292/i_wy) && at_y(292)
      i_posyx5[3,2] = 340/i_wx && at_x(340)
      i_size5[3,1] = at_y(50)
      i_size5[3,2] = cp_intsz(122/i_wx)
      i_posyx5[4,1] = i_ay+(304/i_wy) && at_y(304)
      i_posyx5[4,2] = 195/i_wx && at_x(195)
      i_posyx5[5,1] = i_ay+(248/i_wy) && at_y(248)
      i_posyx5[5,2] = 197/i_wx && at_x(197)
      i_size5[5,1] = 1
      i_size5[5,2] = cp_intsz(434/i_wx)
      i_posyx5[6,1] = i_ay+(246/i_wy) && at_y(246)
      i_posyx5[6,2] = 636/i_wx && at_x(636)
      i_size5[6,1] = at_y(25)
      i_size5[6,2] = cp_intsz(51/i_wx)
      i_posyx5[8,1] = i_ay+(249/i_wy) && at_y(249)
      i_posyx5[8,2] = 92/i_wx && at_x(92)
      i_posyx5[9,1] = i_ay+(225/i_wy) && at_y(225)
      i_posyx5[9,2] = 47/i_wx && at_x(47)
      i_posyx5[10,1] = i_ay+(273/i_wy) && at_y(273)
      i_posyx5[10,2] = 197/i_wx && at_x(197)
      i_size5[10,1] = 1
      i_size5[10,2] = cp_intsz(41/i_wx)
      i_posyx5[11,1] = i_ay+(177/i_wy) && at_y(177)
      i_posyx5[11,2] = 197/i_wx && at_x(197)
      i_size5[11,1] = 1
      i_size5[11,2] = cp_intsz(84/i_wx)
      i_posyx5[12,1] = i_ay+(179/i_wy) && at_y(179)
      i_posyx5[12,2] = 156/i_wx && at_x(156)
      i_posyx5[13,1] = i_ay+(273/i_wy) && at_y(273)
      i_posyx5[13,2] = 92/i_wx && at_x(92)
      i_posyx5[14,1] = i_ay+(224/i_wy) && at_y(224)
      i_posyx5[14,2] = 197/i_wx && at_x(197)
      i_size5[14,1] = 1
      i_size5[14,2] = cp_intsz(434/i_wx)
      i_posyx5[15,1] = i_ay+(143/i_wy) && at_y(143)
      i_posyx5[15,2] = 6/i_wx && at_x(6)
      i_posyx5[17,1] = i_ay+(28/i_wy) && at_y(28)
      i_posyx5[17,2] = 6/i_wx && at_x(6)
      i_posyx5[18,1] = i_ay+(90/i_wy) && at_y(90)
      i_posyx5[18,2] = 197/i_wx && at_x(197)
      i_size5[18,1] = 1
      i_size5[18,2] = cp_intsz(41/i_wx)
      i_posyx5[19,1] = i_ay+(90/i_wy) && at_y(90)
      i_posyx5[19,2] = 274/i_wx && at_x(274)
      i_size5[19,1] = 1
      i_size5[19,2] = cp_intsz(41/i_wx)
      i_posyx5[20,1] = i_ay+(91/i_wy) && at_y(91)
      i_posyx5[20,2] = 127/i_wx && at_x(127)
      i_posyx5[21,1] = i_ay+(91/i_wy) && at_y(91)
      i_posyx5[21,2] = 233/i_wx && at_x(233)
      i_posyx5[22,1] = i_ay+(74/i_wy) && at_y(74)
      i_posyx5[22,2] = 474/i_wx && at_x(474)
      i_size5[22,1] = at_y(50)
      i_size5[22,2] = cp_intsz(122/i_wx)
      i_posyx5[23,1] = i_ay+(73/i_wy) && at_y(73)
      i_posyx5[23,2] = 607/i_wx && at_x(607)
      i_size5[23,1] = at_y(50)
      i_size5[23,2] = cp_intsz(149/i_wx)
      i_posyx5[24,1] = i_ay+(200/i_wy) && at_y(200)
      i_posyx5[24,2] = 197/i_wx && at_x(197)
      i_size5[24,1] = 1
      i_size5[24,2] = cp_intsz(84/i_wx)
      i_posyx5[25,1] = i_ay+(202/i_wy) && at_y(202)
      i_posyx5[25,2] = 91/i_wx && at_x(91)
  return
procedure Ass_Pos_Mac
      i_posyx1[1,1] = i_ay+at_y(39)
      i_posyx1[1,2] = at_x(157)
      i_size1[1,1] = 1
      i_size1[1,2] = cp_intsz(at_x(84))
      i_posyx1[2,1] = i_ay+at_y(39)
      i_posyx1[2,2] = at_x(352)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(at_x(77))
      i_posyx1[3,1] = i_ay+at_y(361)
      i_posyx1[3,2] = at_x(157)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(at_x(28))
      i_posyx1[4,1] = i_ay+at_y(363)
      i_posyx1[4,2] = at_x(115)
      i_posyx1[5,1] = i_ay+at_y(72)
      i_posyx1[5,2] = at_x(157)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(at_x(42))
      i_posyx1[6,1] = i_ay+at_y(73)
      i_posyx1[6,2] = at_x(57)
      i_posyx1[7,1] = i_ay+at_y(72)
      i_posyx1[7,2] = at_x(662)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(at_x(35))
      i_posyx1[8,1] = i_ay+at_y(73)
      i_posyx1[8,2] = at_x(620)
      i_posyx1[9,1] = i_ay+at_y(72)
      i_posyx1[9,2] = at_x(451)
      i_size1[9,1] = 1
      i_size1[9,2] = cp_intsz(at_x(70))
      i_posyx1[10,1] = i_ay+at_y(73)
      i_posyx1[10,2] = at_x(417)
      i_posyx1[11,1] = i_ay+at_y(72)
      i_posyx1[11,2] = at_x(257)
      i_size1[11,1] = 1
      i_size1[11,2] = cp_intsz(at_x(154))
      i_posyx1[12,1] = i_ay+at_y(73)
      i_posyx1[12,2] = at_x(200)
      i_posyx1[13,1] = i_ay+at_y(197)
      i_posyx1[13,2] = at_x(157)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(at_x(42))
      i_posyx1[14,1] = i_ay+at_y(197)
      i_posyx1[14,2] = at_x(77)
      i_posyx1[15,1] = i_ay+at_y(197)
      i_posyx1[15,2] = at_x(316)
      i_size1[15,1] = 1
      i_size1[15,2] = cp_intsz(at_x(98))
      i_posyx1[16,1] = i_ay+at_y(197)
      i_posyx1[16,2] = at_x(211)
      i_posyx1[17,1] = i_ay+at_y(197)
      i_posyx1[17,2] = at_x(536)
      i_size1[17,1] = 1
      i_size1[17,2] = cp_intsz(at_x(56))
      i_posyx1[18,1] = i_ay+at_y(197)
      i_posyx1[18,2] = at_x(434)
      i_posyx1[19,1] = i_ay+at_y(221)
      i_posyx1[19,2] = at_x(157)
      i_size1[19,1] = 1
      i_size1[19,2] = cp_intsz(at_x(28))
      i_posyx1[20,1] = i_ay+at_y(222)
      i_posyx1[20,2] = at_x(36)
      i_posyx1[21,1] = i_ay+at_y(163)
      i_posyx1[21,2] = at_x(157)
      i_size1[21,1] = 1
      i_size1[21,2] = cp_intsz(at_x(112))
      i_posyx1[22,1] = i_ay+at_y(163)
      i_posyx1[22,2] = at_x(5)
      i_posyx1[23,1] = i_ay+at_y(163)
      i_posyx1[23,2] = at_x(377)
      i_size1[23,1] = 1
      i_size1[23,2] = cp_intsz(at_x(112))
      i_posyx1[24,1] = i_ay+at_y(163)
      i_posyx1[24,2] = at_x(280)
      i_posyx1[25,1] = i_ay+at_y(257)
      i_posyx1[25,2] = at_x(157)
      i_size1[25,1] = cp_intsz(at_y(52))
      i_size1[25,2] = cp_intsz(at_x(595))
      i_posyx1[26,1] = i_ay+at_y(259)
      i_posyx1[26,2] = at_x(75)
      i_posyx1[27,1] = i_ay+at_y(396)
      i_posyx1[27,2] = at_x(157)
      i_size1[27,1] = cp_intsz(at_y(17))
      i_size1[27,2] = cp_intsz(at_x(595))
      i_posyx1[28,1] = i_ay+at_y(397)
      i_posyx1[28,2] = at_x(83)
      i_posyx1[33,1] = i_ay+at_y(433)
      i_posyx1[33,2] = at_x(13)
      i_size1[33,1] = at_y(50)
      i_size1[33,2] = cp_intsz(at_x(71))
      i_posyx1[36,1] = i_ay+at_y(136)
      i_posyx1[36,2] = at_x(52)
      i_posyx1[37,1] = i_ay+at_y(135)
      i_posyx1[37,2] = at_x(157)
      i_size1[37,1] = 1
      i_size1[37,2] = cp_intsz(at_x(595))
      i_posyx1[39,1] = i_ay+at_y(315)
      i_posyx1[39,2] = at_x(157)
      i_size1[39,1] = 1
      i_size1[39,2] = cp_intsz(at_x(595))
      i_posyx1[40,1] = i_ay+at_y(338)
      i_posyx1[40,2] = at_x(157)
      i_size1[40,1] = 1
      i_size1[40,2] = cp_intsz(at_x(595))
      i_posyx1[41,1] = i_ay+at_y(340)
      i_posyx1[41,2] = at_x(90)
      i_posyx1[42,1] = i_ay+at_y(316)
      i_posyx1[42,2] = at_x(85)
      i_posyx1[43,1] = i_ay+at_y(13)
      i_posyx1[43,2] = at_x(157)
      i_size1[43,1] = 1
      i_size1[43,2] = cp_intsz(at_x(84))
      i_posyx1[45,1] = i_ay+at_y(14)
      i_posyx1[45,2] = at_x(44)
      i_posyx1[46,1] = i_ay+at_y(41)
      i_posyx1[46,2] = at_x(48)
      i_posyx1[47,1] = i_ay+at_y(41)
      i_posyx1[47,2] = at_x(247)
      i_posyx1[48,1] = i_ay+at_y(109)
      i_posyx1[48,2] = at_x(13)
      i_posyx1[49,1] = i_ay+at_y(108)
      i_posyx1[49,2] = at_x(157)
      i_size1[49,1] = 1
      i_size1[49,2] = cp_intsz(at_x(126))
      i_posyx2[1,1] = i_ay+at_y(417)
      i_posyx2[1,2] = at_x(167)
      i_size2[1,1] = 1
      i_size2[1,2] = cp_intsz(at_x(154))
      i_posyx2[2,1] = i_ay+at_y(418)
      i_posyx2[2,2] = at_x(0)
      i_posyx2[3,1] = i_ay+at_y(133)
      i_posyx2[3,2] = at_x(167)
      i_size2[3,1] = 1
      i_size2[3,2] = cp_intsz(at_x(434))
      i_posyx2[4,1] = i_ay+at_y(134)
      i_posyx2[4,2] = at_x(101)
      i_posyx2[6,1] = i_ay+at_y(156)
      i_posyx2[6,2] = at_x(167)
      i_size2[6,1] = 1
      i_size2[6,2] = cp_intsz(at_x(133))
      i_posyx2[7,1] = i_ay+at_y(157)
      i_posyx2[7,2] = at_x(91)
      i_posyx2[8,1] = i_ay+at_y(190)
      i_posyx2[8,2] = at_x(167)
      i_size2[8,1] = 1
      i_size2[8,2] = cp_intsz(at_x(574))
      i_posyx2[9,1] = i_ay+at_y(191)
      i_posyx2[9,2] = at_x(115)
      i_posyx2[10,1] = i_ay+at_y(213)
      i_posyx2[10,2] = at_x(167)
      i_size2[10,1] = 1
      i_size2[10,2] = cp_intsz(at_x(70))
      i_posyx2[11,1] = i_ay+at_y(214)
      i_posyx2[11,2] = at_x(81)
      i_posyx2[12,1] = i_ay+at_y(236)
      i_posyx2[12,2] = at_x(167)
      i_size2[12,1] = 1
      i_size2[12,2] = cp_intsz(at_x(49))
      i_posyx2[13,1] = i_ay+at_y(237)
      i_posyx2[13,2] = at_x(126)
      i_posyx2[14,1] = i_ay+at_y(259)
      i_posyx2[14,2] = at_x(167)
      i_size2[14,1] = 1
      i_size2[14,2] = cp_intsz(at_x(574))
      i_posyx2[15,1] = i_ay+at_y(260)
      i_posyx2[15,2] = at_x(104)
      i_posyx2[16,1] = i_ay+at_y(282)
      i_posyx2[16,2] = at_x(167)
      i_size2[16,1] = 1
      i_size2[16,2] = cp_intsz(at_x(28))
      i_posyx2[17,1] = i_ay+at_y(283)
      i_posyx2[17,2] = at_x(103)
      i_posyx2[18,1] = i_ay+at_y(305)
      i_posyx2[18,2] = at_x(167)
      i_size2[18,1] = 1
      i_size2[18,2] = cp_intsz(at_x(28))
      i_posyx2[19,1] = i_ay+at_y(306)
      i_posyx2[19,2] = at_x(109)
      i_posyx2[20,1] = i_ay+at_y(338)
      i_posyx2[20,2] = at_x(167)
      i_size2[20,1] = 1
      i_size2[20,2] = cp_intsz(at_x(98))
      i_posyx2[21,1] = i_ay+at_y(339)
      i_posyx2[21,2] = at_x(107)
      i_posyx2[22,1] = i_ay+at_y(361)
      i_posyx2[22,2] = at_x(167)
      i_size2[22,1] = 1
      i_size2[22,2] = cp_intsz(at_x(98))
      i_posyx2[23,1] = i_ay+at_y(362)
      i_posyx2[23,2] = at_x(135)
      i_posyx2[24,1] = i_ay+at_y(384)
      i_posyx2[24,2] = at_x(167)
      i_size2[24,1] = cp_intsz(at_y(17))
      i_size2[24,2] = cp_intsz(at_x(574))
      i_posyx2[25,1] = i_ay+at_y(385)
      i_posyx2[25,2] = at_x(119)
      i_posyx2[26,1] = i_ay+at_y(29)
      i_posyx2[26,2] = at_x(167)
      i_size2[26,1] = 1
      i_size2[26,2] = cp_intsz(at_x(23))
      i_posyx2[27,1] = i_ay+at_y(30)
      i_posyx2[27,2] = at_x(5)
      i_posyx2[28,1] = i_ay+at_y(29)
      i_posyx2[28,2] = at_x(197)
      i_size2[28,1] = 1
      i_size2[28,2] = cp_intsz(at_x(96))
      i_posyx2[29,1] = i_ay+at_y(52)
      i_posyx2[29,2] = at_x(167)
      i_size2[29,1] = 1
      i_size2[29,2] = cp_intsz(at_x(126))
      i_posyx2[30,1] = i_ay+at_y(53)
      i_posyx2[30,2] = at_x(76)
      i_posyx2[31,1] = i_ay+at_y(110)
      i_posyx2[31,2] = at_x(167)
      i_size2[31,1] = 1
      i_size2[31,2] = cp_intsz(at_x(434))
      i_posyx2[32,1] = i_ay+at_y(111)
      i_posyx2[32,2] = at_x(52)
      i_posyx2[37,1] = i_ay+at_y(76)
      i_posyx2[37,2] = at_x(63)
      i_posyx2[38,1] = i_ay+at_y(75)
      i_posyx2[38,2] = at_x(167)
      i_size2[38,1] = 1
      i_size2[38,2] = cp_intsz(at_x(574))
      i_posyx3[1,1] = i_ay+at_y(12)
      i_posyx3[1,2] = at_x(234)
      i_posyx3[2,1] = i_ay+at_y(13)
      i_posyx3[2,2] = at_x(85)
      i_posyx3[3,1] = i_ay+at_y(35)
      i_posyx3[3,2] = at_x(234)
      i_size3[3,1] = cp_intsz(at_y(17))
      i_size3[3,2] = cp_intsz(at_x(489))
      i_posyx3[4,1] = i_ay+at_y(36)
      i_posyx3[4,2] = at_x(148)
      i_posyx3[5,1] = i_ay+at_y(68)
      i_posyx3[5,2] = at_x(234)
      i_size3[5,1] = 1
      i_size3[5,2] = cp_intsz(at_x(42))
      i_posyx3[6,1] = i_ay+at_y(69)
      i_posyx3[6,2] = at_x(114)
      i_posyx3[7,1] = i_ay+at_y(91)
      i_posyx3[7,2] = at_x(234)
      i_size3[7,1] = 1
      i_size3[7,2] = cp_intsz(at_x(70))
      i_posyx3[8,1] = i_ay+at_y(93)
      i_posyx3[8,2] = at_x(23)
      i_posyx3[9,1] = i_ay+at_y(91)
      i_posyx3[9,2] = at_x(467)
      i_size3[9,1] = 1
      i_size3[9,2] = cp_intsz(at_x(35))
      i_posyx3[10,1] = i_ay+at_y(93)
      i_posyx3[10,2] = at_x(316)
      i_posyx3[11,1] = i_ay+at_y(114)
      i_posyx3[11,2] = at_x(234)
      i_size3[11,1] = 1
      i_size3[11,2] = cp_intsz(at_x(70))
      i_posyx3[12,1] = i_ay+at_y(115)
      i_posyx3[12,2] = at_x(74)
      i_posyx3[13,1] = i_ay+at_y(137)
      i_posyx3[13,2] = at_x(234)
      i_size3[13,1] = 1
      i_size3[13,2] = cp_intsz(at_x(98))
      i_posyx3[14,1] = i_ay+at_y(138)
      i_posyx3[14,2] = at_x(116)
      i_posyx3[15,1] = i_ay+at_y(170)
      i_posyx3[15,2] = at_x(234)
      i_size3[15,1] = 1
      i_size3[15,2] = cp_intsz(at_x(154))
      i_posyx3[16,1] = i_ay+at_y(171)
      i_posyx3[16,2] = at_x(108)
      i_posyx3[17,1] = i_ay+at_y(202)
      i_posyx3[17,2] = at_x(234)
      i_size3[17,1] = 1
      i_size3[17,2] = cp_intsz(at_x(434))
      i_posyx3[18,1] = i_ay+at_y(203)
      i_posyx3[18,2] = at_x(96)
      i_posyx3[19,1] = i_ay+at_y(225)
      i_posyx3[19,2] = at_x(234)
      i_size3[19,1] = 1
      i_size3[19,2] = cp_intsz(at_x(434))
      i_posyx3[20,1] = i_ay+at_y(226)
      i_posyx3[20,2] = at_x(117)
      i_posyx3[21,1] = i_ay+at_y(248)
      i_posyx3[21,2] = at_x(234)
      i_size3[21,1] = 1
      i_size3[21,2] = cp_intsz(at_x(126))
      i_posyx3[22,1] = i_ay+at_y(249)
      i_posyx3[22,2] = at_x(128)
      i_posyx3[23,1] = i_ay+at_y(281)
      i_posyx3[23,2] = at_x(234)
      i_size3[23,1] = 1
      i_size3[23,2] = cp_intsz(at_x(489))
      i_posyx3[24,1] = i_ay+at_y(282)
      i_posyx3[24,2] = at_x(122)
      i_posyx3[25,1] = i_ay+at_y(304)
      i_posyx3[25,2] = at_x(412)
      i_size3[25,1] = 1
      i_size3[25,2] = cp_intsz(at_x(252))
      i_posyx3[26,1] = i_ay+at_y(305)
      i_posyx3[26,2] = at_x(376)
      i_posyx3[27,1] = i_ay+at_y(304)
      i_posyx3[27,2] = at_x(234)
      i_size3[27,1] = 1
      i_size3[27,2] = cp_intsz(at_x(49))
      i_posyx3[28,1] = i_ay+at_y(305)
      i_posyx3[28,2] = at_x(199)
      i_posyx3[29,1] = i_ay+at_y(304)
      i_posyx3[29,2] = at_x(320)
      i_size3[29,1] = 1
      i_size3[29,2] = cp_intsz(at_x(49))
      i_posyx3[30,1] = i_ay+at_y(305)
      i_posyx3[30,2] = at_x(288)
      i_posyx3[31,1] = i_ay+at_y(327)
      i_posyx3[31,2] = at_x(234)
      i_size3[31,1] = 1
      i_size3[31,2] = cp_intsz(at_x(91))
      i_posyx3[32,1] = i_ay+at_y(328)
      i_posyx3[32,2] = at_x(204)
      i_posyx3[33,1] = i_ay+at_y(361)
      i_posyx3[33,2] = at_x(233)
      i_size3[33,1] = 1
      i_size3[33,2] = cp_intsz(at_x(98))
      i_posyx3[34,1] = i_ay+at_y(362)
      i_posyx3[34,2] = at_x(63)
      i_posyx3[35,1] = i_ay+at_y(384)
      i_posyx3[35,2] = at_x(233)
      i_size3[35,1] = 1
      i_size3[35,2] = cp_intsz(at_x(70))
      i_posyx3[36,1] = i_ay+at_y(385)
      i_posyx3[36,2] = at_x(43)
      i_posyx3[37,1] = i_ay+at_y(407)
      i_posyx3[37,2] = at_x(233)
      i_size3[37,1] = 1
      i_size3[37,2] = cp_intsz(at_x(98))
      i_posyx3[38,1] = i_ay+at_y(408)
      i_posyx3[38,2] = at_x(67)
      i_posyx3[39,1] = i_ay+at_y(430)
      i_posyx3[39,2] = at_x(233)
      i_size3[39,1] = 1
      i_size3[39,2] = cp_intsz(at_x(70))
      i_posyx3[40,1] = i_ay+at_y(431)
      i_posyx3[40,2] = at_x(94)
      i_posyx3[41,1] = i_ay+at_y(453)
      i_posyx3[41,2] = at_x(233)
      i_size3[41,1] = 1
      i_size3[41,2] = cp_intsz(at_x(434))
      i_posyx3[42,1] = i_ay+at_y(454)
      i_posyx3[42,2] = at_x(118)
      i_posyx3[49,1] = i_ay+at_y(68)
      i_posyx3[49,2] = at_x(280)
      i_size3[49,1] = 1
      i_size3[49,2] = cp_intsz(at_x(443))
      i_posyx4[1,1] = i_ay+at_y(51)
      i_posyx4[1,2] = at_x(188)
      i_size4[1,1] = 1
      i_size4[1,2] = cp_intsz(at_x(28))
      i_posyx4[2,1] = i_ay+at_y(52)
      i_posyx4[2,2] = at_x(28)
      i_posyx4[3,1] = i_ay+at_y(51)
      i_posyx4[3,2] = at_x(222)
      i_size4[3,1] = 1
      i_size4[3,2] = cp_intsz(at_x(210))
      i_posyx4[4,1] = i_ay+at_y(75)
      i_posyx4[4,2] = at_x(188)
      i_size4[4,1] = 1
      i_size4[4,2] = cp_intsz(at_x(84))
      i_posyx4[5,1] = i_ay+at_y(76)
      i_posyx4[5,2] = at_x(85)
      i_posyx4[6,1] = i_ay+at_y(98)
      i_posyx4[6,2] = at_x(188)
      i_size4[6,1] = 1
      i_size4[6,2] = cp_intsz(at_x(49))
      i_posyx4[7,1] = i_ay+at_y(99)
      i_posyx4[7,2] = at_x(53)
      i_posyx4[8,1] = i_ay+at_y(121)
      i_posyx4[8,2] = at_x(188)
      i_size4[8,1] = 1
      i_size4[8,2] = cp_intsz(at_x(70))
      i_posyx4[9,1] = i_ay+at_y(122)
      i_posyx4[9,2] = at_x(70)
      i_posyx4[10,1] = i_ay+at_y(160)
      i_posyx4[10,2] = at_x(188)
      i_size4[10,1] = 1
      i_size4[10,2] = cp_intsz(at_x(98))
      i_posyx4[11,1] = i_ay+at_y(161)
      i_posyx4[11,2] = at_x(130)
      i_posyx4[12,1] = i_ay+at_y(183)
      i_posyx4[12,2] = at_x(188)
      i_size4[12,1] = cp_intsz(at_y(17))
      i_size4[12,2] = cp_intsz(at_x(567))
      i_posyx4[13,1] = i_ay+at_y(184)
      i_posyx4[13,2] = at_x(147)
      i_posyx5[1,1] = i_ay+at_y(74)
      i_posyx5[1,2] = at_x(340)
      i_size5[1,1] = at_y(50)
      i_size5[1,2] = cp_intsz(at_x(122))
      i_posyx5[3,1] = i_ay+at_y(292)
      i_posyx5[3,2] = at_x(340)
      i_size5[3,1] = at_y(50)
      i_size5[3,2] = cp_intsz(at_x(122))
      i_posyx5[4,1] = i_ay+at_y(304)
      i_posyx5[4,2] = at_x(195)
      i_posyx5[5,1] = i_ay+at_y(248)
      i_posyx5[5,2] = at_x(197)
      i_size5[5,1] = 1
      i_size5[5,2] = cp_intsz(at_x(434))
      i_posyx5[6,1] = i_ay+at_y(246)
      i_posyx5[6,2] = at_x(636)
      i_size5[6,1] = at_y(25)
      i_size5[6,2] = cp_intsz(at_x(51))
      i_posyx5[8,1] = i_ay+at_y(249)
      i_posyx5[8,2] = at_x(92)
      i_posyx5[9,1] = i_ay+at_y(225)
      i_posyx5[9,2] = at_x(47)
      i_posyx5[10,1] = i_ay+at_y(273)
      i_posyx5[10,2] = at_x(197)
      i_size5[10,1] = 1
      i_size5[10,2] = cp_intsz(at_x(41))
      i_posyx5[11,1] = i_ay+at_y(177)
      i_posyx5[11,2] = at_x(197)
      i_size5[11,1] = 1
      i_size5[11,2] = cp_intsz(at_x(84))
      i_posyx5[12,1] = i_ay+at_y(179)
      i_posyx5[12,2] = at_x(156)
      i_posyx5[13,1] = i_ay+at_y(273)
      i_posyx5[13,2] = at_x(92)
      i_posyx5[14,1] = i_ay+at_y(224)
      i_posyx5[14,2] = at_x(197)
      i_size5[14,1] = 1
      i_size5[14,2] = cp_intsz(at_x(434))
      i_posyx5[15,1] = i_ay+at_y(143)
      i_posyx5[15,2] = at_x(6)
      i_posyx5[17,1] = i_ay+at_y(28)
      i_posyx5[17,2] = at_x(6)
      i_posyx5[18,1] = i_ay+at_y(90)
      i_posyx5[18,2] = at_x(197)
      i_size5[18,1] = 1
      i_size5[18,2] = cp_intsz(at_x(41))
      i_posyx5[19,1] = i_ay+at_y(90)
      i_posyx5[19,2] = at_x(274)
      i_size5[19,1] = 1
      i_size5[19,2] = cp_intsz(at_x(41))
      i_posyx5[20,1] = i_ay+at_y(91)
      i_posyx5[20,2] = at_x(127)
      i_posyx5[21,1] = i_ay+at_y(91)
      i_posyx5[21,2] = at_x(233)
      i_posyx5[22,1] = i_ay+at_y(74)
      i_posyx5[22,2] = at_x(474)
      i_size5[22,1] = at_y(50)
      i_size5[22,2] = cp_intsz(at_x(122))
      i_posyx5[23,1] = i_ay+at_y(73)
      i_posyx5[23,2] = at_x(607)
      i_size5[23,1] = at_y(50)
      i_size5[23,2] = cp_intsz(at_x(149))
      i_posyx5[24,1] = i_ay+at_y(200)
      i_posyx5[24,2] = at_x(197)
      i_size5[24,1] = 1
      i_size5[24,2] = cp_intsz(at_x(84))
      i_posyx5[25,1] = i_ay+at_y(202)
      i_posyx5[25,2] = at_x(91)
  return
procedure Ass_Pos_Unkn
      i_posyx1[1,1] = -2
      i_posyx1[1,2] = -2
      i_size1[1,1]  = 1
      i_size1[1,2]  = 11
      i_posyx1[2,1] = -2
      i_posyx1[2,2] = -2
      i_size1[2,1]  = 1
      i_size1[2,2]  = 10
      i_posyx1[3,1] = -2
      i_posyx1[3,2] = -2
      i_size1[3,1]  = 1
      i_size1[3,2]  = 3
      i_posyx1[4,1] = -2
      i_posyx1[4,2] = -2
      i_posyx1[5,1] = -2
      i_posyx1[5,2] = -2
      i_size1[5,1]  = 1
      i_size1[5,2]  = 5
      i_posyx1[6,1] = -2
      i_posyx1[6,2] = -2
      i_posyx1[7,1] = -2
      i_posyx1[7,2] = -2
      i_size1[7,1]  = 1
      i_size1[7,2]  = 4
      i_posyx1[8,1] = -2
      i_posyx1[8,2] = -2
      i_posyx1[9,1] = -2
      i_posyx1[9,2] = -2
      i_size1[9,1]  = 1
      i_size1[9,2]  = 9
      i_posyx1[10,1] = -2
      i_posyx1[10,2] = -2
      i_posyx1[11,1] = -2
      i_posyx1[11,2] = -2
      i_size1[11,1]  = 1
      i_size1[11,2]  = 21
      i_posyx1[12,1] = -2
      i_posyx1[12,2] = -2
      i_posyx1[13,1] = -2
      i_posyx1[13,2] = -2
      i_size1[13,1]  = 1
      i_size1[13,2]  = 5
      i_posyx1[14,1] = -2
      i_posyx1[14,2] = -2
      i_posyx1[15,1] = -2
      i_posyx1[15,2] = -2
      i_size1[15,1]  = 1
      i_size1[15,2]  = 13
      i_posyx1[16,1] = -2
      i_posyx1[16,2] = -2
      i_posyx1[17,1] = -2
      i_posyx1[17,2] = -2
      i_size1[17,1]  = 1
      i_size1[17,2]  = 7
      i_posyx1[18,1] = -2
      i_posyx1[18,2] = -2
      i_posyx1[19,1] = -2
      i_posyx1[19,2] = -2
      i_size1[19,1]  = 1
      i_size1[19,2]  = 3
      i_posyx1[20,1] = -2
      i_posyx1[20,2] = -2
      i_posyx1[21,1] = -2
      i_posyx1[21,2] = -2
      i_size1[21,1]  = 1
      i_size1[21,2]  = 15
      i_posyx1[22,1] = -2
      i_posyx1[22,2] = -2
      i_posyx1[23,1] = -2
      i_posyx1[23,2] = -2
      i_size1[23,1]  = 1
      i_size1[23,2]  = 15
      i_posyx1[24,1] = -2
      i_posyx1[24,2] = -2
      i_posyx1[25,1] = -2
      i_posyx1[25,2] = -2
      i_size1[25,1]  = 1
      i_size1[25,2]  = 1
      i_posyx1[26,1] = -2
      i_posyx1[26,2] = -2
      i_posyx1[27,1] = -2
      i_posyx1[27,2] = -2
      i_size1[27,1]  = 1
      i_size1[27,2]  = 1
      i_posyx1[28,1] = -2
      i_posyx1[28,2] = -2
      i_posyx1[33,1] = 17
      i_posyx1[33,2] = 41
      i_size1[33,1]  = 1
      i_size1[33,2]  = 13
      i_posyx1[36,1] = -2
      i_posyx1[36,2] = -2
      i_posyx1[37,1] = -2
      i_posyx1[37,2] = -2
      i_size1[37,1]  = 1
      i_size1[37,2]  = 81
      i_posyx1[39,1] = -2
      i_posyx1[39,2] = -2
      i_size1[39,1]  = 1
      i_size1[39,2]  = 50
      i_posyx1[40,1] = -2
      i_posyx1[40,2] = -2
      i_size1[40,1]  = 1
      i_size1[40,2]  = 50
      i_posyx1[41,1] = -2
      i_posyx1[41,2] = -2
      i_posyx1[42,1] = -2
      i_posyx1[42,2] = -2
      i_posyx1[43,1] = -2
      i_posyx1[43,2] = -2
      i_size1[43,1]  = 1
      i_size1[43,2]  = 11
      i_posyx1[45,1] = -2
      i_posyx1[45,2] = -2
      i_posyx1[46,1] = -2
      i_posyx1[46,2] = -2
      i_posyx1[47,1] = -2
      i_posyx1[47,2] = -2
      i_posyx1[48,1] = -2
      i_posyx1[48,2] = -2
      i_posyx1[49,1] = -2
      i_posyx1[49,2] = -2
      i_size1[49,1]  = 1
      i_size1[49,2]  = 81
      i_posyx2[1,1] = -2
      i_posyx2[1,2] = -2
      i_size2[1,1]  = 1
      i_size2[1,2]  = 21
      i_posyx2[2,1] = -2
      i_posyx2[2,2] = -2
      i_posyx2[3,1] = -2
      i_posyx2[3,2] = -2
      i_size2[3,1]  = 1
      i_size2[3,2]  = 61
      i_posyx2[4,1] = -2
      i_posyx2[4,2] = -2
      i_posyx2[6,1] = -2
      i_posyx2[6,2] = -2
      i_size2[6,1]  = 1
      i_size2[6,2]  = 18
      i_posyx2[7,1] = -2
      i_posyx2[7,2] = -2
      i_posyx2[8,1] = -2
      i_posyx2[8,2] = -2
      i_size2[8,1]  = 1
      i_size2[8,2]  = 81
      i_posyx2[9,1] = -2
      i_posyx2[9,2] = -2
      i_posyx2[10,1] = -2
      i_posyx2[10,2] = -2
      i_size2[10,1]  = 1
      i_size2[10,2]  = 9
      i_posyx2[11,1] = -2
      i_posyx2[11,2] = -2
      i_posyx2[12,1] = -2
      i_posyx2[12,2] = -2
      i_size2[12,1]  = 1
      i_size2[12,2]  = 6
      i_posyx2[13,1] = -2
      i_posyx2[13,2] = -2
      i_posyx2[14,1] = -2
      i_posyx2[14,2] = -2
      i_size2[14,1]  = 1
      i_size2[14,2]  = 81
      i_posyx2[15,1] = -2
      i_posyx2[15,2] = -2
      i_posyx2[16,1] = -2
      i_posyx2[16,2] = -2
      i_size2[16,1]  = 1
      i_size2[16,2]  = 3
      i_posyx2[17,1] = -2
      i_posyx2[17,2] = -2
      i_posyx2[18,1] = -2
      i_posyx2[18,2] = -2
      i_size2[18,1]  = 1
      i_size2[18,2]  = 3
      i_posyx2[19,1] = -2
      i_posyx2[19,2] = -2
      i_posyx2[20,1] = -2
      i_posyx2[20,2] = -2
      i_size2[20,1]  = 1
      i_size2[20,2]  = 13
      i_posyx2[21,1] = -2
      i_posyx2[21,2] = -2
      i_posyx2[22,1] = -2
      i_posyx2[22,2] = -2
      i_size2[22,1]  = 1
      i_size2[22,2]  = 13
      i_posyx2[23,1] = -2
      i_posyx2[23,2] = -2
      i_posyx2[24,1] = -2
      i_posyx2[24,2] = -2
      i_size2[24,1]  = 1
      i_size2[24,2]  = 1
      i_posyx2[25,1] = -2
      i_posyx2[25,2] = -2
      i_posyx2[26,1] = -2
      i_posyx2[26,2] = -2
      i_size2[26,1]  = 1
      i_size2[26,2]  = 3
      i_posyx2[27,1] = -2
      i_posyx2[27,2] = -2
      i_posyx2[28,1] = -2
      i_posyx2[28,2] = -2
      i_size2[28,1]  = 1
      i_size2[28,2]  = 29
      i_posyx2[29,1] = -2
      i_posyx2[29,2] = -2
      i_size2[29,1]  = 1
      i_size2[29,2]  = 17
      i_posyx2[30,1] = -2
      i_posyx2[30,2] = -2
      i_posyx2[31,1] = -2
      i_posyx2[31,2] = -2
      i_size2[31,1]  = 1
      i_size2[31,2]  = 61
      i_posyx2[32,1] = -2
      i_posyx2[32,2] = -2
      i_posyx2[37,1] = -2
      i_posyx2[37,2] = -2
      i_posyx2[38,1] = -2
      i_posyx2[38,2] = -2
      i_size2[38,1]  = 1
      i_size2[38,2]  = 81
      i_posyx3[1,1] = -2
      i_posyx3[1,2] = -2
      i_posyx3[2,1] = -2
      i_posyx3[2,2] = -2
      i_posyx3[3,1] = -2
      i_posyx3[3,2] = -2
      i_size3[3,1]  = 1
      i_size3[3,2]  = 1
      i_posyx3[4,1] = -2
      i_posyx3[4,2] = -2
      i_posyx3[5,1] = -2
      i_posyx3[5,2] = -2
      i_size3[5,1]  = 1
      i_size3[5,2]  = 5
      i_posyx3[6,1] = -2
      i_posyx3[6,2] = -2
      i_posyx3[7,1] = -2
      i_posyx3[7,2] = -2
      i_size3[7,1]  = 1
      i_size3[7,2]  = 9
      i_posyx3[8,1] = -2
      i_posyx3[8,2] = -2
      i_posyx3[9,1] = -2
      i_posyx3[9,2] = -2
      i_size3[9,1]  = 1
      i_size3[9,2]  = 4
      i_posyx3[10,1] = -2
      i_posyx3[10,2] = -2
      i_posyx3[11,1] = -2
      i_posyx3[11,2] = -2
      i_size3[11,1]  = 1
      i_size3[11,2]  = 9
      i_posyx3[12,1] = -2
      i_posyx3[12,2] = -2
      i_posyx3[13,1] = -2
      i_posyx3[13,2] = -2
      i_size3[13,1]  = 1
      i_size3[13,2]  = 13
      i_posyx3[14,1] = -2
      i_posyx3[14,2] = -2
      i_posyx3[15,1] = -2
      i_posyx3[15,2] = -2
      i_size3[15,1]  = 1
      i_size3[15,2]  = 21
      i_posyx3[16,1] = -2
      i_posyx3[16,2] = -2
      i_posyx3[17,1] = -2
      i_posyx3[17,2] = -2
      i_size3[17,1]  = 1
      i_size3[17,2]  = 61
      i_posyx3[18,1] = -2
      i_posyx3[18,2] = -2
      i_posyx3[19,1] = -2
      i_posyx3[19,2] = -2
      i_size3[19,1]  = 1
      i_size3[19,2]  = 61
      i_posyx3[20,1] = -2
      i_posyx3[20,2] = -2
      i_posyx3[21,1] = -2
      i_posyx3[21,2] = -2
      i_size3[21,1]  = 1
      i_size3[21,2]  = 17
      i_posyx3[22,1] = -2
      i_posyx3[22,2] = -2
      i_posyx3[23,1] = -2
      i_posyx3[23,2] = -2
      i_size3[23,1]  = 1
      i_size3[23,2]  = 81
      i_posyx3[24,1] = -2
      i_posyx3[24,2] = -2
      i_posyx3[25,1] = -2
      i_posyx3[25,2] = -2
      i_size3[25,1]  = 1
      i_size3[25,2]  = 35
      i_posyx3[26,1] = -2
      i_posyx3[26,2] = -2
      i_posyx3[27,1] = -2
      i_posyx3[27,2] = -2
      i_size3[27,1]  = 1
      i_size3[27,2]  = 6
      i_posyx3[28,1] = -2
      i_posyx3[28,2] = -2
      i_posyx3[29,1] = -2
      i_posyx3[29,2] = -2
      i_size3[29,1]  = 1
      i_size3[29,2]  = 6
      i_posyx3[30,1] = -2
      i_posyx3[30,2] = -2
      i_posyx3[31,1] = -2
      i_posyx3[31,2] = -2
      i_size3[31,1]  = 1
      i_size3[31,2]  = 12
      i_posyx3[32,1] = -2
      i_posyx3[32,2] = -2
      i_posyx3[33,1] = -2
      i_posyx3[33,2] = -2
      i_size3[33,1]  = 1
      i_size3[33,2]  = 13
      i_posyx3[34,1] = -2
      i_posyx3[34,2] = -2
      i_posyx3[35,1] = -2
      i_posyx3[35,2] = -2
      i_size3[35,1]  = 1
      i_size3[35,2]  = 9
      i_posyx3[36,1] = -2
      i_posyx3[36,2] = -2
      i_posyx3[37,1] = -2
      i_posyx3[37,2] = -2
      i_size3[37,1]  = 1
      i_size3[37,2]  = 13
      i_posyx3[38,1] = -2
      i_posyx3[38,2] = -2
      i_posyx3[39,1] = -2
      i_posyx3[39,2] = -2
      i_size3[39,1]  = 1
      i_size3[39,2]  = 9
      i_posyx3[40,1] = -2
      i_posyx3[40,2] = -2
      i_posyx3[41,1] = -2
      i_posyx3[41,2] = -2
      i_size3[41,1]  = 1
      i_size3[41,2]  = 61
      i_posyx3[42,1] = -2
      i_posyx3[42,2] = -2
      i_posyx3[49,1] = -2
      i_posyx3[49,2] = -2
      i_size3[49,1]  = 1
      i_size3[49,2]  = 61
      i_posyx4[1,1] = -2
      i_posyx4[1,2] = -2
      i_size4[1,1]  = 1
      i_size4[1,2]  = 3
      i_posyx4[2,1] = -2
      i_posyx4[2,2] = -2
      i_posyx4[3,1] = -2
      i_posyx4[3,2] = -2
      i_size4[3,1]  = 1
      i_size4[3,2]  = 29
      i_posyx4[4,1] = -2
      i_posyx4[4,2] = -2
      i_size4[4,1]  = 1
      i_size4[4,2]  = 11
      i_posyx4[5,1] = -2
      i_posyx4[5,2] = -2
      i_posyx4[6,1] = -2
      i_posyx4[6,2] = -2
      i_size4[6,1]  = 1
      i_size4[6,2]  = 6
      i_posyx4[7,1] = -2
      i_posyx4[7,2] = -2
      i_posyx4[8,1] = -2
      i_posyx4[8,2] = -2
      i_size4[8,1]  = 1
      i_size4[8,2]  = 9
      i_posyx4[9,1] = -2
      i_posyx4[9,2] = -2
      i_posyx4[10,1] = -2
      i_posyx4[10,2] = -2
      i_size4[10,1]  = 1
      i_size4[10,2]  = 13
      i_posyx4[11,1] = -2
      i_posyx4[11,2] = -2
      i_posyx4[12,1] = -2
      i_posyx4[12,2] = -2
      i_size4[12,1]  = 1
      i_size4[12,2]  = 1
      i_posyx4[13,1] = -2
      i_posyx4[13,2] = -2
      i_posyx5[1,1] = 17
      i_posyx5[1,2] = 41
      i_size5[1,1]  = 1
      i_size5[1,2]  = 18
      i_posyx5[3,1] = 17
      i_posyx5[3,2] = 41
      i_size5[3,1]  = 1
      i_size5[3,2]  = 22
      i_posyx5[4,1] = -2
      i_posyx5[4,2] = -2
      i_posyx5[5,1] = -2
      i_posyx5[5,2] = -2
      i_size5[5,1]  = 1
      i_size5[5,2]  = 61
      i_posyx5[6,1] = -2
      i_posyx5[6,2] = -2
      i_size5[6,1]  = 1
      i_size5[6,2]  = 7
      i_posyx5[8,1] = -2
      i_posyx5[8,2] = -2
      i_posyx5[9,1] = -2
      i_posyx5[9,2] = -2
      i_posyx5[10,1] = -2
      i_posyx5[10,2] = -2
      i_size5[10,1]  = 1
      i_size5[10,2]  = 4
      i_posyx5[11,1] = -2
      i_posyx5[11,2] = -2
      i_size5[11,1]  = 1
      i_size5[11,2]  = 11
      i_posyx5[12,1] = -2
      i_posyx5[12,2] = -2
      i_posyx5[13,1] = -2
      i_posyx5[13,2] = -2
      i_posyx5[14,1] = -2
      i_posyx5[14,2] = -2
      i_size5[14,1]  = 1
      i_size5[14,2]  = 61
      i_posyx5[15,1] = -2
      i_posyx5[15,2] = -2
      i_posyx5[17,1] = -2
      i_posyx5[17,2] = -2
      i_posyx5[18,1] = -2
      i_posyx5[18,2] = -2
      i_size5[18,1]  = 1
      i_size5[18,2]  = 11
      i_posyx5[19,1] = -2
      i_posyx5[19,2] = -2
      i_size5[19,1]  = 1
      i_size5[19,2]  = 11
      i_posyx5[20,1] = -2
      i_posyx5[20,2] = -2
      i_posyx5[21,1] = -2
      i_posyx5[21,2] = -2
      i_posyx5[22,1] = 17
      i_posyx5[22,2] = 41
      i_size5[22,1]  = 1
      i_size5[22,2]  = 19
      i_posyx5[23,1] = 17
      i_posyx5[23,2] = 41
      i_size5[23,1]  = 1
      i_size5[23,2]  = 24
      i_posyx5[24,1] = -2
      i_posyx5[24,2] = -2
      i_size5[24,1]  = 1
      i_size5[24,2]  = 11
      i_posyx5[25,1] = -2
      i_posyx5[25,2] = -2
return

function cp_intsz
  param i_sz
  return(iif(i_sz>=5,int(i_sz),i_sz))

* === F_Paint
procedure F_Paint
  parameters i_tutto
  private i_ay
  i_ay = 1.5
  activate window "gopa_arx" noshow same
  * --- Area Manuale = Paint Init
  * --- Fine Area Manuale
  if i_tutto=0
    if i_vidgrf
      do painttab with at_x(757),5
      do painttabtitle with at_x(757),5,"Generale","Fornitore","Pagamento","Id Trasmissione","Funz. Accessorie"
      do paintcurrtab with at_x(757),5,(i_pag)
      @ 1.7,0 clear
    else
      clear
    endif
  endif
  do case
    case i_pag=1
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx1(4,1),i_posyx1(4,2) say "Art73:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(39),6);
         picture "@J";

        @ i_posyx1(6,1),i_posyx1(6,2) say "TipoDocumento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(98),14);
         picture "@J";

        @ i_posyx1(8,1),i_posyx1(8,2) say "Divisa:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(40),7);
         picture "@J";

        @ i_posyx1(10,1),i_posyx1(10,2) say "Data:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(32),5);
         picture "@J";

        @ i_posyx1(12,1),i_posyx1(12,2) say "Numero:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(55),7);
         picture "@J";

        @ i_posyx1(14,1),i_posyx1(14,2) say "Tipo Ritenuta:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(78),14);
         picture "@J";

        @ i_posyx1(16,1),i_posyx1(16,2) say "Importo Ritenuta:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(103),17);
         picture "@J";

        @ i_posyx1(18,1),i_posyx1(18,2) say "Aliquota Ritenuta:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(100),18);
         picture "@J";

        @ i_posyx1(20,1),i_posyx1(20,2) say "Causale Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(119),18);
         picture "@J";

        @ i_posyx1(22,1),i_posyx1(22,2) say "Importo Totale Documento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(150),25);
         picture "@J";

        @ i_posyx1(24,1),i_posyx1(24,2) say "Arrotondamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(95),15);
         picture "@J";

        @ i_posyx1(26,1),i_posyx1(26,2) say "Causale:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(80),8);
         picture "@J";

        @ i_posyx1(28,1),i_posyx1(28,2) say "File XML:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(71),9);
         picture "@J";

        @ iif(i_vidgrf,at_y(65)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(67)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ iif(i_vidgrf,at_y(427)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(429)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ iif(i_vidgrf,at_y(190)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(192)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ iif(i_vidgrf,at_y(387)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(389)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ iif(i_vidgrf,at_y(249)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(251)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ iif(i_vidgrf,at_y(101)+i_ay,-2),iif(i_vidgrf,at_x(8),-2) to;
        iif(i_vidgrf,at_y(103)+i_ay,-2),iif(i_vidgrf,at_x(751),-2);


        @ i_posyx1(36,1),i_posyx1(36,2) say "Denominazione:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(102),14);
         picture "@J";

        @ i_posyx1(41,1),i_posyx1(41,2) say "Codice CIG:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(66),11);
         picture "@J";

        @ i_posyx1(42,1),i_posyx1(42,2) say "Codice CUP:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(71),11);
         picture "@J";

        @ i_posyx1(45,1),i_posyx1(45,2) say "Progressivo Fattura:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(110),20);
         picture "@J";

        @ i_posyx1(46,1),i_posyx1(46,2) say "Numero Protocollo:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(106),18);
         picture "@J";

        @ i_posyx1(47,1),i_posyx1(47,2) say "Data Protocollo:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(102),16);
         picture "@J";

        @ i_posyx1(48,1),i_posyx1(48,2) say "Codice Beneficiario Cofin:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(142),26);
         picture "@J";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx1(1,1),i_posyx1(1,2),i_size1[1,1],i_size1[1,2]
           do cplu_3d with i_posyx1(2,1),i_posyx1(2,2),i_size1[2,1],i_size1[2,2]
           do cplu_3d with i_posyx1(3,1),i_posyx1(3,2),i_size1[3,1],i_size1[3,2]
           do cplu_3d with i_posyx1(5,1),i_posyx1(5,2),i_size1[5,1],i_size1[5,2]
           do cplu_3d with i_posyx1(7,1),i_posyx1(7,2),i_size1[7,1],i_size1[7,2]
           do cplu_3d with i_posyx1(9,1),i_posyx1(9,2),i_size1[9,1],i_size1[9,2]
           do cplu_3d with i_posyx1(11,1),i_posyx1(11,2),i_size1[11,1],i_size1[11,2]
           do cplu_3d with i_posyx1(13,1),i_posyx1(13,2),i_size1[13,1],i_size1[13,2]
           do cplu_3d with i_posyx1(15,1),i_posyx1(15,2),i_size1[15,1],i_size1[15,2]
           do cplu_3d with i_posyx1(17,1),i_posyx1(17,2),i_size1[17,1],i_size1[17,2]
           do cplu_3d with i_posyx1(19,1),i_posyx1(19,2),i_size1[19,1],i_size1[19,2]
           do cplu_3d with i_posyx1(21,1),i_posyx1(21,2),i_size1[21,1],i_size1[21,2]
           do cplu_3d with i_posyx1(23,1),i_posyx1(23,2),i_size1[23,1],i_size1[23,2]
           do cplu_3d with i_posyx1(25,1),i_posyx1(25,2),i_size1[25,1],i_size1[25,2]
           do cplu_3d with i_posyx1(27,1),i_posyx1(27,2),i_size1[27,1],i_size1[27,2]
           do cplu_3d with i_posyx1(37,1),i_posyx1(37,2),i_size1[37,1],i_size1[37,2]
           do cplu_3d with i_posyx1(39,1),i_posyx1(39,2),i_size1[39,1],i_size1[39,2]
           do cplu_3d with i_posyx1(40,1),i_posyx1(40,2),i_size1[40,1],i_size1[40,2]
           do cplu_3d with i_posyx1(43,1),i_posyx1(43,2),i_size1[43,1],i_size1[43,2]
           do cplu_3d with i_posyx1(49,1),i_posyx1(49,2),i_size1[49,1],i_size1[49,2]
         endif
       else
       endif
        if i_vidgrf
        @ i_posyx1(33,1),i_posyx1(33,2) get i_button picture '@*B prvideo.bmp';
          size i_size1[33,1],i_size1[33,2] disable;

        else
        @ i_posyx1(33,1),i_posyx1(33,2) get i_button picture '@* Anteprima';
          size i_size1[33,1],i_size1[33,2] disable;

        endif
        clear gets
      endif
      @ i_posyx1(1,1),i_posyx1(1,2) say w_PANRPROT picture '@Z 9999999999';
        size i_size1[1,1],i_size1[1,2];
        color (w_t_col004)
      @ i_posyx1(2,1),i_posyx1(2,2) say w_PADTPROT;
        size i_size1[2,1],i_size1[2,2];
        color (w_t_col004)
      @ i_posyx1(3,1),i_posyx1(3,2) say w_PA21112 picture repl("X",2);
        size i_size1[3,1],i_size1[3,2];
        color (w_t_col004)
      @ i_posyx1(5,1),i_posyx1(5,2) say w_PA2111 picture repl("X",4);
        size i_size1[5,1],i_size1[5,2];
        color (w_t_col004)
      @ i_posyx1(7,1),i_posyx1(7,2) say w_PA2112 picture repl("X",3);
        size i_size1[7,1],i_size1[7,2];
        color (w_t_col004)
      @ i_posyx1(9,1),i_posyx1(9,2) say w_PA2113;
        size i_size1[9,1],i_size1[9,2];
        color (w_t_col004)
      @ i_posyx1(11,1),i_posyx1(11,2) say w_PA2114 picture repl("X",20);
        size i_size1[11,1],i_size1[11,2];
        color (w_t_col004)
      @ i_posyx1(13,1),i_posyx1(13,2) say w_PA21151 picture repl("X",4);
        size i_size1[13,1],i_size1[13,2];
        color (w_t_col004)
      @ i_posyx1(15,1),i_posyx1(15,2) say w_PA21152 picture "999999.99999";
        size i_size1[15,1],i_size1[15,2];
        color (w_t_col004)
      @ i_posyx1(17,1),i_posyx1(17,2) say w_PA21153 picture "99.999";
        size i_size1[17,1],i_size1[17,2];
        color (w_t_col004)
      @ i_posyx1(19,1),i_posyx1(19,2) say w_PA21154 picture repl("X",2);
        size i_size1[19,1],i_size1[19,2];
        color (w_t_col004)
      @ i_posyx1(21,1),i_posyx1(21,2) say w_PA2119 picture v_ZR+PS(15,w_CVG);
        size i_size1[21,1],i_size1[21,2];
        color (w_t_col004)
      @ i_posyx1(23,1),i_posyx1(23,2) say w_PA21110 picture "999999.99999";
        size i_size1[23,1],i_size1[23,2];
        color (w_t_col004)
      @ i_posyx1(25,1),i_posyx1(25,2) edit w_PA21111;
        size i_size1[25,1],i_size1[25,2] disable scroll;
        color (w_t_col004)
      @ i_posyx1(27,1),i_posyx1(27,2) edit w_PAPATHFL;
        size i_size1[27,1],i_size1[27,2] disable ;
        color (w_t_col004)
      @ i_posyx1(37,1),i_posyx1(37,2) say w_PA12131 picture repl("X",80);
        size i_size1[37,1],i_size1[37,2];
        color (w_t_col004)
      @ i_posyx1(39,1),i_posyx1(39,2) say w_PA2126 picture repl("X",254);
        size i_size1[39,1],i_size1[39,2];
        color (w_t_col004)
      @ i_posyx1(40,1),i_posyx1(40,2) say w_PA2127 picture repl("X",254);
        size i_size1[40,1],i_size1[40,2];
        color (w_t_col004)
      @ i_posyx1(43,1),i_posyx1(43,2) say w_PAPROGID picture '@Z 9999999999';
        size i_size1[43,1],i_size1[43,2];
        color (w_t_col004)
      @ i_posyx1(49,1),i_posyx1(49,2) say w_PACODBEN picture repl("X",80);
        size i_size1[49,1],i_size1[49,2];
        color (w_t_col004)
      clear gets
    case i_pag=2
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx2(2,1),i_posyx2(2,2) say "Riferimento Amministrazione:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(165),28);
         picture "@J";

        @ i_posyx2(4,1),i_posyx2(4,2) say "Cognome:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(64),8);
         picture "@J";

        @ i_posyx2(7,1),i_posyx2(7,2) say "Codice EORI:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(74),12);
         picture "@J";

        @ i_posyx2(9,1),i_posyx2(9,2) say "Indirizzo:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(50),10);
         picture "@J";

        @ i_posyx2(11,1),i_posyx2(11,2) say "NumeroCivico:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(84),13);
         picture "@J";

        @ i_posyx2(13,1),i_posyx2(13,2) say "Cap:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(39),4);
         picture "@J";

        @ i_posyx2(15,1),i_posyx2(15,2) say "Comune:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(61),7);
         picture "@J";

        @ i_posyx2(17,1),i_posyx2(17,2) say "Provincia:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(62),10);
         picture "@J";

        @ i_posyx2(19,1),i_posyx2(19,2) say "Nazione:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(56),8);
         picture "@J";

        @ i_posyx2(21,1),i_posyx2(21,2) say "Telefono:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(58),9);
         picture "@J";

        @ i_posyx2(23,1),i_posyx2(23,2) say "Fax:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(30),4);
         picture "@J";

        @ i_posyx2(25,1),i_posyx2(25,2) say "Email:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(46),6);
         picture "@J";

        @ i_posyx2(27,1),i_posyx2(27,2) say "Identificativo fiscale:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(160),23);
         picture "@J";

        @ i_posyx2(30,1),i_posyx2(30,2) say "Codice Fiscale:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(89),15);
         picture "@J";

        @ i_posyx2(32,1),i_posyx2(32,2) say "Nome:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(113),5);
         picture "@J";

        @ iif(i_vidgrf,at_y(102)+i_ay,-2),iif(i_vidgrf,at_x(11),-2) to;
        iif(i_vidgrf,at_y(104)+i_ay,-2),iif(i_vidgrf,at_x(754),-2);


        @ iif(i_vidgrf,at_y(331)+i_ay,-2),iif(i_vidgrf,at_x(11),-2) to;
        iif(i_vidgrf,at_y(333)+i_ay,-2),iif(i_vidgrf,at_x(754),-2);


        @ iif(i_vidgrf,at_y(183)+i_ay,-2),iif(i_vidgrf,at_x(11),-2) to;
        iif(i_vidgrf,at_y(185)+i_ay,-2),iif(i_vidgrf,at_x(754),-2);


        @ iif(i_vidgrf,at_y(410)+i_ay,-2),iif(i_vidgrf,at_x(11),-2) to;
        iif(i_vidgrf,at_y(412)+i_ay,-2),iif(i_vidgrf,at_x(754),-2);


        @ i_posyx2(37,1),i_posyx2(37,2) say "Denominazione:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(102),14);
         picture "@J";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx2(1,1),i_posyx2(1,2),i_size2[1,1],i_size2[1,2]
           do cplu_3d with i_posyx2(3,1),i_posyx2(3,2),i_size2[3,1],i_size2[3,2]
           do cplu_3d with i_posyx2(6,1),i_posyx2(6,2),i_size2[6,1],i_size2[6,2]
           do cplu_3d with i_posyx2(8,1),i_posyx2(8,2),i_size2[8,1],i_size2[8,2]
           do cplu_3d with i_posyx2(10,1),i_posyx2(10,2),i_size2[10,1],i_size2[10,2]
           do cplu_3d with i_posyx2(12,1),i_posyx2(12,2),i_size2[12,1],i_size2[12,2]
           do cplu_3d with i_posyx2(14,1),i_posyx2(14,2),i_size2[14,1],i_size2[14,2]
           do cplu_3d with i_posyx2(16,1),i_posyx2(16,2),i_size2[16,1],i_size2[16,2]
           do cplu_3d with i_posyx2(18,1),i_posyx2(18,2),i_size2[18,1],i_size2[18,2]
           do cplu_3d with i_posyx2(20,1),i_posyx2(20,2),i_size2[20,1],i_size2[20,2]
           do cplu_3d with i_posyx2(22,1),i_posyx2(22,2),i_size2[22,1],i_size2[22,2]
           do cplu_3d with i_posyx2(24,1),i_posyx2(24,2),i_size2[24,1],i_size2[24,2]
           do cplu_3d with i_posyx2(26,1),i_posyx2(26,2),i_size2[26,1],i_size2[26,2]
           do cplu_3d with i_posyx2(28,1),i_posyx2(28,2),i_size2[28,1],i_size2[28,2]
           do cplu_3d with i_posyx2(29,1),i_posyx2(29,2),i_size2[29,1],i_size2[29,2]
           do cplu_3d with i_posyx2(31,1),i_posyx2(31,2),i_size2[31,1],i_size2[31,2]
           do cplu_3d with i_posyx2(38,1),i_posyx2(38,2),i_size2[38,1],i_size2[38,2]
         endif
       else
       endif
      endif
      @ i_posyx2(1,1),i_posyx2(1,2) say w_PA126 picture repl("X",20);
        size i_size2[1,1],i_size2[1,2];
        color (w_t_col004)
      @ i_posyx2(3,1),i_posyx2(3,2) say w_PA12133 picture repl("X",60);
        size i_size2[3,1],i_size2[3,2];
        color (w_t_col004)
      @ i_posyx2(6,1),i_posyx2(6,2) say w_PA12135 picture repl("X",17);
        size i_size2[6,1],i_size2[6,2];
        color (w_t_col004)
      @ i_posyx2(8,1),i_posyx2(8,2) say w_PA1221 picture repl("X",80);
        size i_size2[8,1],i_size2[8,2];
        color (w_t_col004)
      @ i_posyx2(10,1),i_posyx2(10,2) say w_PA1222 picture repl("X",8);
        size i_size2[10,1],i_size2[10,2];
        color (w_t_col004)
      @ i_posyx2(12,1),i_posyx2(12,2) say w_PA1223 picture repl("X",5);
        size i_size2[12,1],i_size2[12,2];
        color (w_t_col004)
      @ i_posyx2(14,1),i_posyx2(14,2) say w_PA1224 picture repl("X",80);
        size i_size2[14,1],i_size2[14,2];
        color (w_t_col004)
      @ i_posyx2(16,1),i_posyx2(16,2) say w_PA1225 picture repl("X",2);
        size i_size2[16,1],i_size2[16,2];
        color (w_t_col004)
      @ i_posyx2(18,1),i_posyx2(18,2) say w_PA1226 picture repl("X",2);
        size i_size2[18,1],i_size2[18,2];
        color (w_t_col004)
      @ i_posyx2(20,1),i_posyx2(20,2) say w_PA1251 picture repl("X",12);
        size i_size2[20,1],i_size2[20,2];
        color (w_t_col004)
      @ i_posyx2(22,1),i_posyx2(22,2) say w_PA1252 picture repl("X",12);
        size i_size2[22,1],i_size2[22,2];
        color (w_t_col004)
      @ i_posyx2(24,1),i_posyx2(24,2) edit w_PA1253;
        size i_size2[24,1],i_size2[24,2] disable ;
        color (w_t_col004)
      @ i_posyx2(26,1),i_posyx2(26,2) say w_PA12111 picture repl("X",2);
        size i_size2[26,1],i_size2[26,2];
        color (w_t_col004)
      @ i_posyx2(28,1),i_posyx2(28,2) say w_PA12112 picture repl("X",28);
        size i_size2[28,1],i_size2[28,2];
        color (w_t_col004)
      @ i_posyx2(29,1),i_posyx2(29,2) say w_PA1212 picture repl("X",16);
        size i_size2[29,1],i_size2[29,2];
        color (w_t_col004)
      @ i_posyx2(31,1),i_posyx2(31,2) say w_PA12132 picture repl("X",60);
        size i_size2[31,1],i_size2[31,2];
        color (w_t_col004)
      @ i_posyx2(38,1),i_posyx2(38,2) say w_PA12131 picture repl("X",80);
        size i_size2[38,1],i_size2[38,2];
        color (w_t_col004)
      clear gets
    case i_pag=3
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx3(2,1),i_posyx3(2,2) say "Condizioni Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(147),21);
         picture "@J";

        @ i_posyx3(4,1),i_posyx3(4,2) say "Beneficiario:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(84),13);
         picture "@J";

        @ i_posyx3(6,1),i_posyx3(6,2) say "Modalita Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(118),19);
         picture "@J";

        @ i_posyx3(8,1),i_posyx3(8,2) say "Data Riferimento Termini Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(209),35);
         picture "@J";

        @ i_posyx3(10,1),i_posyx3(10,2) say "Giorni Termini Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(149),25);
         picture "@J";

        @ i_posyx3(12,1),i_posyx3(12,2) say "Data Scadenza Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(158),24);
         picture "@J";

        @ i_posyx3(14,1),i_posyx3(14,2) say "Importo Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(116),18);
         picture "@J";

        @ i_posyx3(16,1),i_posyx3(16,2) say "Codice Ufficio Postale:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(124),23);
         picture "@J";

        @ i_posyx3(18,1),i_posyx3(18,2) say "Cognome Quietanzante:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(136),21);
         picture "@J";

        @ i_posyx3(20,1),i_posyx3(20,2) say "Nome Quietanzante:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(115),18);
         picture "@J";

        @ i_posyx3(22,1),i_posyx3(22,2) say "CF Quietanzante:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(104),16);
         picture "@J";

        @ i_posyx3(24,1),i_posyx3(24,2) say "Istituto Finanziario:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(110),21);
         picture "@J";

        @ i_posyx3(26,1),i_posyx3(26,2) say "IBAN:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(34),5);
         picture "@J";

        @ i_posyx3(28,1),i_posyx3(28,2) say "ABI:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(33),4);
         picture "@J";

        @ i_posyx3(30,1),i_posyx3(30,2) say "CAB:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(30),4);
         picture "@J";

        @ i_posyx3(32,1),i_posyx3(32,2) say "BIC:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(28),4);
         picture "@J";

        @ i_posyx3(34,1),i_posyx3(34,2) say "Sconto Pagamento Anticipato:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(168),28);
         picture "@J";

        @ i_posyx3(36,1),i_posyx3(36,2) say "Data Limite Pagamento Anticipato:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(188),33);
         picture "@J";

        @ i_posyx3(38,1),i_posyx3(38,2) say "Penalita Pagamenti Ritardati:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(164),29);
         picture "@J";

        @ i_posyx3(40,1),i_posyx3(40,2) say "Data Decorrenza Penale:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(137),23);
         picture "@J";

        @ i_posyx3(42,1),i_posyx3(42,2) say "Codice Pagamento:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(113),17);
         picture "@J";

        @ iif(i_vidgrf,at_y(61)+i_ay,-2),iif(i_vidgrf,at_x(7),-2) to;
        iif(i_vidgrf,at_y(63)+i_ay,-2),iif(i_vidgrf,at_x(749),-2);


        @ iif(i_vidgrf,at_y(163)+i_ay,-2),iif(i_vidgrf,at_x(7),-2) to;
        iif(i_vidgrf,at_y(165)+i_ay,-2),iif(i_vidgrf,at_x(749),-2);


        @ iif(i_vidgrf,at_y(196)+i_ay,-2),iif(i_vidgrf,at_x(7),-2) to;
        iif(i_vidgrf,at_y(198)+i_ay,-2),iif(i_vidgrf,at_x(749),-2);


        @ iif(i_vidgrf,at_y(274)+i_ay,-2),iif(i_vidgrf,at_x(7),-2) to;
        iif(i_vidgrf,at_y(276)+i_ay,-2),iif(i_vidgrf,at_x(749),-2);


        @ iif(i_vidgrf,at_y(354)+i_ay,-2),iif(i_vidgrf,at_x(7),-2) to;
        iif(i_vidgrf,at_y(356)+i_ay,-2),iif(i_vidgrf,at_x(749),-2);


       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx3(3,1),i_posyx3(3,2),i_size3[3,1],i_size3[3,2]
           do cplu_3d with i_posyx3(5,1),i_posyx3(5,2),i_size3[5,1],i_size3[5,2]
           do cplu_3d with i_posyx3(7,1),i_posyx3(7,2),i_size3[7,1],i_size3[7,2]
           do cplu_3d with i_posyx3(9,1),i_posyx3(9,2),i_size3[9,1],i_size3[9,2]
           do cplu_3d with i_posyx3(11,1),i_posyx3(11,2),i_size3[11,1],i_size3[11,2]
           do cplu_3d with i_posyx3(13,1),i_posyx3(13,2),i_size3[13,1],i_size3[13,2]
           do cplu_3d with i_posyx3(15,1),i_posyx3(15,2),i_size3[15,1],i_size3[15,2]
           do cplu_3d with i_posyx3(17,1),i_posyx3(17,2),i_size3[17,1],i_size3[17,2]
           do cplu_3d with i_posyx3(19,1),i_posyx3(19,2),i_size3[19,1],i_size3[19,2]
           do cplu_3d with i_posyx3(21,1),i_posyx3(21,2),i_size3[21,1],i_size3[21,2]
           do cplu_3d with i_posyx3(23,1),i_posyx3(23,2),i_size3[23,1],i_size3[23,2]
           do cplu_3d with i_posyx3(25,1),i_posyx3(25,2),i_size3[25,1],i_size3[25,2]
           do cplu_3d with i_posyx3(27,1),i_posyx3(27,2),i_size3[27,1],i_size3[27,2]
           do cplu_3d with i_posyx3(29,1),i_posyx3(29,2),i_size3[29,1],i_size3[29,2]
           do cplu_3d with i_posyx3(31,1),i_posyx3(31,2),i_size3[31,1],i_size3[31,2]
           do cplu_3d with i_posyx3(33,1),i_posyx3(33,2),i_size3[33,1],i_size3[33,2]
           do cplu_3d with i_posyx3(35,1),i_posyx3(35,2),i_size3[35,1],i_size3[35,2]
           do cplu_3d with i_posyx3(37,1),i_posyx3(37,2),i_size3[37,1],i_size3[37,2]
           do cplu_3d with i_posyx3(39,1),i_posyx3(39,2),i_size3[39,1],i_size3[39,2]
           do cplu_3d with i_posyx3(41,1),i_posyx3(41,2),i_size3[41,1],i_size3[41,2]
           do cplu_3d with i_posyx3(49,1),i_posyx3(49,2),i_size3[49,1],i_size3[49,2]
         endif
       else
       endif
      endif
      @ i_posyx3(1,1),i_posyx3(1,2) get r_PA241 function "*RH Pagamento a rate;Pagamento completo;Anticipo";
        color ,,,,,,,,&w_t_col005;

      @ i_posyx3(3,1),i_posyx3(3,2) edit w_PA2421;
        size i_size3[3,1],i_size3[3,2] disable ;
        color (w_t_col004)
      @ i_posyx3(5,1),i_posyx3(5,2) say w_PA2422 picture repl("X",4);
        size i_size3[5,1],i_size3[5,2];
        color (w_t_col004)
      @ i_posyx3(7,1),i_posyx3(7,2) say w_PA2423;
        size i_size3[7,1],i_size3[7,2];
        color (w_t_col004)
      @ i_posyx3(9,1),i_posyx3(9,2) say w_PA2424 picture "999";
        size i_size3[9,1],i_size3[9,2];
        color (w_t_col004)
      @ i_posyx3(11,1),i_posyx3(11,2) say w_PA2425;
        size i_size3[11,1],i_size3[11,2];
        color (w_t_col004)
      @ i_posyx3(13,1),i_posyx3(13,2) say w_PA2426 picture "999999.99999";
        size i_size3[13,1],i_size3[13,2];
        color (w_t_col004)
      @ i_posyx3(15,1),i_posyx3(15,2) say w_PA2427 picture repl("X",20);
        size i_size3[15,1],i_size3[15,2];
        color (w_t_col004)
      @ i_posyx3(17,1),i_posyx3(17,2) say w_PA2428 picture repl("X",60);
        size i_size3[17,1],i_size3[17,2];
        color (w_t_col004)
      @ i_posyx3(19,1),i_posyx3(19,2) say w_PA2429 picture repl("X",60);
        size i_size3[19,1],i_size3[19,2];
        color (w_t_col004)
      @ i_posyx3(21,1),i_posyx3(21,2) say w_PA24210 picture repl("X",16);
        size i_size3[21,1],i_size3[21,2];
        color (w_t_col004)
      @ i_posyx3(23,1),i_posyx3(23,2) say w_PA24212 picture repl("X",80);
        size i_size3[23,1],i_size3[23,2];
        color (w_t_col004)
      @ i_posyx3(25,1),i_posyx3(25,2) say w_PA24213 picture repl("X",34);
        size i_size3[25,1],i_size3[25,2];
        color (w_t_col004)
      @ i_posyx3(27,1),i_posyx3(27,2) say w_PA24214 picture "99999";
        size i_size3[27,1],i_size3[27,2];
        color (w_t_col004)
      @ i_posyx3(29,1),i_posyx3(29,2) say w_PA24215 picture "99999";
        size i_size3[29,1],i_size3[29,2];
        color (w_t_col004)
      @ i_posyx3(31,1),i_posyx3(31,2) say w_PA24216 picture repl("X",11);
        size i_size3[31,1],i_size3[31,2];
        color (w_t_col004)
      @ i_posyx3(33,1),i_posyx3(33,2) say w_PA24217 picture "999999.99999";
        size i_size3[33,1],i_size3[33,2];
        color (w_t_col004)
      @ i_posyx3(35,1),i_posyx3(35,2) say w_PA24218;
        size i_size3[35,1],i_size3[35,2];
        color (w_t_col004)
      @ i_posyx3(37,1),i_posyx3(37,2) say w_PA24219 picture "999999.99999";
        size i_size3[37,1],i_size3[37,2];
        color (w_t_col004)
      @ i_posyx3(39,1),i_posyx3(39,2) say w_PA24220;
        size i_size3[39,1],i_size3[39,2];
        color (w_t_col004)
      @ i_posyx3(41,1),i_posyx3(41,2) say w_PA24221 picture repl("X",60);
        size i_size3[41,1],i_size3[41,2];
        color (w_t_col004)
      @ i_posyx3(49,1),i_posyx3(49,2) say w_DESPA picture repl("X",60);
        size i_size3[49,1],i_size3[49,2];
        color (w_t_col004)
      clear gets
    case i_pag=4
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ i_posyx4(2,1),i_posyx4(2,2) say "Identificativo del trasmittente:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(158),32);
         picture "@J";

        @ i_posyx4(5,1),i_posyx4(5,2) say "Progressivo Invio:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(101),18);
         picture "@J";

        @ i_posyx4(7,1),i_posyx4(7,2) say "FormatoTrasmissione:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(133),20);
         picture "@J";

        @ i_posyx4(9,1),i_posyx4(9,2) say "CodiceDestinatario:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(116),19);
         picture "@J";

        @ i_posyx4(11,1),i_posyx4(11,2) say "Telefono:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(56),9);
         picture "@J";

        @ i_posyx4(13,1),i_posyx4(13,2) say "Email:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(39),6);
         picture "@J";

        @ iif(i_vidgrf,at_y(150)+i_ay,-2),iif(i_vidgrf,at_x(4),-2) to;
        iif(i_vidgrf,at_y(152)+i_ay,-2),iif(i_vidgrf,at_x(747),-2);


       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx4(1,1),i_posyx4(1,2),i_size4[1,1],i_size4[1,2]
           do cplu_3d with i_posyx4(3,1),i_posyx4(3,2),i_size4[3,1],i_size4[3,2]
           do cplu_3d with i_posyx4(4,1),i_posyx4(4,2),i_size4[4,1],i_size4[4,2]
           do cplu_3d with i_posyx4(6,1),i_posyx4(6,2),i_size4[6,1],i_size4[6,2]
           do cplu_3d with i_posyx4(8,1),i_posyx4(8,2),i_size4[8,1],i_size4[8,2]
           do cplu_3d with i_posyx4(10,1),i_posyx4(10,2),i_size4[10,1],i_size4[10,2]
           do cplu_3d with i_posyx4(12,1),i_posyx4(12,2),i_size4[12,1],i_size4[12,2]
         endif
       else
       endif
      endif
      @ i_posyx4(1,1),i_posyx4(1,2) say w_PA1111 picture repl("X",2);
        size i_size4[1,1],i_size4[1,2];
        color (w_t_col004)
      @ i_posyx4(3,1),i_posyx4(3,2) say w_PA1112 picture repl("X",28);
        size i_size4[3,1],i_size4[3,2];
        color (w_t_col004)
      @ i_posyx4(4,1),i_posyx4(4,2) say w_PA112 picture repl("X",10);
        size i_size4[4,1],i_size4[4,2];
        color (w_t_col004)
      @ i_posyx4(6,1),i_posyx4(6,2) say w_PA113 picture repl("X",5);
        size i_size4[6,1],i_size4[6,2];
        color (w_t_col004)
      @ i_posyx4(8,1),i_posyx4(8,2) say w_PA114 picture repl("X",8);
        size i_size4[8,1],i_size4[8,2];
        color (w_t_col004)
      @ i_posyx4(10,1),i_posyx4(10,2) say w_PA1151 picture repl("X",12);
        size i_size4[10,1],i_size4[10,2];
        color (w_t_col004)
      @ i_posyx4(12,1),i_posyx4(12,2) edit w_PA1152;
        size i_size4[12,1],i_size4[12,2] disable ;
        color (w_t_col004)
      clear gets
    case i_pag=5
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ iif(i_vidgrf,at_y(161)+i_ay,-2),iif(i_vidgrf,at_x(2),-2) to;
        iif(i_vidgrf,at_y(163)+i_ay,-2),iif(i_vidgrf,at_x(750),-2);


        @ i_posyx5(8,1),i_posyx5(8,2) say "Percorso file esito:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(102),20);
         picture "@J";

        @ i_posyx5(9,1),i_posyx5(9,2) say "Causale (in caso di rifiuto):";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(147),29);
         picture "@J";

        @ i_posyx5(12,1),i_posyx5(12,2) say "ID SDI:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(38),7);
         picture "@J";

        @ i_posyx5(13,1),i_posyx5(13,2) say "Progressivo Invio:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(102),18);
         picture "@J";

        @ i_posyx5(15,1),i_posyx5(15,2) say "Messaggio di esito per il Committente";

        @ iif(i_vidgrf,at_y(47)+i_ay,-2),iif(i_vidgrf,at_x(2),-2) to;
        iif(i_vidgrf,at_y(49)+i_ay,-2),iif(i_vidgrf,at_x(750),-2);


        @ i_posyx5(17,1),i_posyx5(17,2) say "Impegno Associato";

        @ i_posyx5(20,1),i_posyx5(20,2) say "Impegno N.:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(67),11);
         picture "@J";

        @ i_posyx5(21,1),i_posyx5(21,2) say "Anno:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(39),5);
         picture "@J";

        @ i_posyx5(25,1),i_posyx5(25,2) say "ID COMMITTENTE:";
         size iif(i_vidgrf,max(1.1,at_y(18)),1);
             ,iif(i_vidgrf,at_x(103),15);
         picture "@J";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx5(5,1),i_posyx5(5,2),i_size5[5,1],i_size5[5,2]
           do cplu_3d with i_posyx5(10,1),i_posyx5(10,2),i_size5[10,1],i_size5[10,2]
           do cplu_3d with i_posyx5(11,1),i_posyx5(11,2),i_size5[11,1],i_size5[11,2]
           do cplu_3d with i_posyx5(14,1),i_posyx5(14,2),i_size5[14,1],i_size5[14,2]
           do cplu_3d with i_posyx5(18,1),i_posyx5(18,2),i_size5[18,1],i_size5[18,2]
           do cplu_3d with i_posyx5(19,1),i_posyx5(19,2),i_size5[19,1],i_size5[19,2]
           do cplu_3d with i_posyx5(24,1),i_posyx5(24,2),i_size5[24,1],i_size5[24,2]
         endif
       else
       endif
        @ i_posyx5(1,1),i_posyx5(1,2) get i_button picture '@* Genera Impegno';
          size i_size5[1,1],i_size5[1,2] disable;

        @ i_posyx5(3,1),i_posyx5(3,2) get i_button picture '@* Genera/Varia Esito';
          size i_size5[3,1],i_size5[3,2] disable;

        @ i_posyx5(6,1),i_posyx5(6,2) get i_button picture '@* ...';
          size i_size5[6,1],i_size5[6,2] disable;

        @ i_posyx5(22,1),i_posyx5(22,2) get i_button picture '@* Associa Impegno';
          size i_size5[22,1],i_size5[22,2] disable;

        @ i_posyx5(23,1),i_posyx5(23,2) get i_button picture '@* Rimuovi Rif. Impegno';
          size i_size5[23,1],i_size5[23,2] disable;

        clear gets
      endif
      @ i_posyx5(4,1),i_posyx5(4,2) get r_PA_ESITO function "*R Accettata;Rifiutata";
        color ,,,,,,,,&w_t_col005;

      @ i_posyx5(5,1),i_posyx5(5,2) say w_FILEESITO picture repl("X",120);
        size i_size5[5,1],i_size5[5,2];
        color (w_t_col004)
      @ i_posyx5(10,1),i_posyx5(10,2) say w_PAPRGINV;
        size i_size5[10,1],i_size5[10,2];
        color (w_t_col004)
      @ i_posyx5(11,1),i_posyx5(11,2) say w_PA_IDSDI picture repl("X",10);
        size i_size5[11,1],i_size5[11,2];
        color (w_t_col004)
      @ i_posyx5(14,1),i_posyx5(14,2) say w_PAESICAU picture repl("X",60);
        size i_size5[14,1],i_size5[14,2];
        color (w_t_col004)
      @ i_posyx5(18,1),i_posyx5(18,2) say w_NIMP picture repl("X",10);
        size i_size5[18,1],i_size5[18,2];
        color (w_t_col004)
      @ i_posyx5(19,1),i_posyx5(19,2) say w_DIMP picture repl("X",10);
        size i_size5[19,1],i_size5[19,2];
        color (w_t_col004)
      @ i_posyx5(24,1),i_posyx5(24,2) say w_PA_IDCOM picture repl("X",10);
        size i_size5[24,1],i_size5[24,2];
        color (w_t_col004)
      clear gets
  endcase
  activate window "gopa_arx" same
  * --- Area Manuale = Paint End
  * --- Fine Area Manuale
  return

* === F_Read
function F_Read
  i_warea = "FTPA_XML"
  select FTPA_XML
  if i_docreco>0
    goto i_docreco
  endif
  * --- Area Manuale = Func Read Init
  * --- Fine Area Manuale
  w_FILEESITO = space(120)
  w_DESPA = space(60)
  w_PANRPROT = PANRPROT
  w_PADTPROT = PADTPROT
  w_PA21112 = PA21112
  w_PA2111 = PA2111
  w_PA2112 = PA2112
  w_PA2113 = PA2113
  w_PA2114 = PA2114
  w_PA21151 = PA21151
  w_PA21152 = PA21152
  w_PA21153 = PA21153
  w_PA21154 = PA21154
  w_PA2119 = PA2119
  w_PA21110 = PA21110
  w_PA21111 = PA21111
  w_PAPATHFL = PAPATHFL
  w_PA126 = PA126
  w_PA12133 = PA12133
  w_PA12134 = PA12134
  w_PA12135 = PA12135
  w_PA1221 = PA1221
  w_PA1222 = PA1222
  w_PA1223 = PA1223
  w_PA1224 = PA1224
  w_PA1225 = PA1225
  w_PA1226 = PA1226
  w_PA1251 = PA1251
  w_PA1252 = PA1252
  w_PA1253 = PA1253
  w_PA12111 = PA12111
  w_PA12112 = PA12112
  if w_PA12112<>space(28)
    select BEN_EFIC
    seek w_PA12112
    if found()
      w_DESBEN = BERAGSOC
    endif
    select &i_warea
  endif
  w_PA1212 = PA1212
  if w_PA1212<>space(16)
    select BEN_EFIC
    seek w_PA1212
    if found()
      w_DESBEN = BERAGSOC
    endif
    select &i_warea
  endif
  w_PA12132 = PA12132
  w_PA241 = PA241
  w_PA2421 = PA2421
  w_PA2422 = PA2422
  if w_PA2422<>space(4)
    select FTPA_PAG
    seek w_PA2422
    if found()
      w_DESPA = PGDESCRI
    endif
    select &i_warea
  endif
  w_PA2423 = PA2423
  w_PA2424 = PA2424
  w_PA2425 = PA2425
  w_PA2426 = PA2426
  w_PA2427 = PA2427
  w_PA2428 = PA2428
  w_PA2429 = PA2429
  w_PA24210 = PA24210
  w_PA24212 = PA24212
  w_PA24213 = PA24213
  w_PA24214 = PA24214
  w_PA24215 = PA24215
  w_PA24216 = PA24216
  w_PA24217 = PA24217
  w_PA24218 = PA24218
  w_PA24219 = PA24219
  w_PA24220 = PA24220
  w_PA24221 = PA24221
  w_PA24211 = PA24211
  w_PA1111 = PA1111
  w_PA1112 = PA1112
  w_PA112 = PA112
  w_PA113 = PA113
  w_PA114 = PA114
  w_PA1151 = PA1151
  w_PA1152 = PA1152
  w_PA12131 = PA12131
  w_PA12131 = PA12131
  w_PAIMPEGN = PAIMPEGN
  w_PA_ESITO = PA_ESITO
  w_PAPRGINV = PAPRGINV
  w_PA_IDSDI = PA_IDSDI
  w_PAESICAU = PAESICAU
  w_NIMP = substr(w_PAIMPEGN,5,LEN(w_PAIMPEGN)-4)
  w_DIMP = LEFT(w_PAIMPEGN,4)
  w_CVG = NDecVal(ValCon(ytos(w_PA2113)),'G')
  w_PA2126 = PA2126
  w_PA2127 = PA2127
  w_PA_IDCOM = PA_IDCOM
  w_PAPROGID = PAPROGID
  w_PAANPROT = PAANPROT
  w_PACODBEN = PACODBEN
  * --- Area Manuale = Func Read End
  * --- Fine Area Manuale
  do Set_Radio
  return

* === F_Replace
function F_Replace
  i_warea = "FTPA_XML"
  select FTPA_XML
  goto i_docreco
  * --- Area Manuale = Func Replace Init
  * --- Fine Area Manuale
  replace PANRPROT with w_PANRPROT
  replace PADTPROT with w_PADTPROT
  replace PA21112 with w_PA21112
  replace PA2111 with w_PA2111
  replace PA2112 with w_PA2112
  replace PA2113 with w_PA2113
  replace PA2114 with w_PA2114
  replace PA21151 with w_PA21151
  replace PA21152 with w_PA21152
  replace PA21153 with w_PA21153
  replace PA21154 with w_PA21154
  replace PA2119 with w_PA2119
  replace PA21110 with w_PA21110
  replace PA21111 with w_PA21111
  replace PAPATHFL with w_PAPATHFL
  replace PA126 with w_PA126
  replace PA12133 with w_PA12133
  replace PA12134 with w_PA12134
  replace PA12135 with w_PA12135
  replace PA1221 with w_PA1221
  replace PA1222 with w_PA1222
  replace PA1223 with w_PA1223
  replace PA1224 with w_PA1224
  replace PA1225 with w_PA1225
  replace PA1226 with w_PA1226
  replace PA1251 with w_PA1251
  replace PA1252 with w_PA1252
  replace PA1253 with w_PA1253
  replace PA12111 with w_PA12111
  replace PA12112 with w_PA12112
  replace PA1212 with w_PA1212
  replace PA12132 with w_PA12132
  replace PA241 with w_PA241
  replace PA2421 with w_PA2421
  replace PA2422 with w_PA2422
  replace PA2423 with w_PA2423
  replace PA2424 with w_PA2424
  replace PA2425 with w_PA2425
  replace PA2426 with w_PA2426
  replace PA2427 with w_PA2427
  replace PA2428 with w_PA2428
  replace PA2429 with w_PA2429
  replace PA24210 with w_PA24210
  replace PA24212 with w_PA24212
  replace PA24213 with w_PA24213
  replace PA24214 with w_PA24214
  replace PA24215 with w_PA24215
  replace PA24216 with w_PA24216
  replace PA24217 with w_PA24217
  replace PA24218 with w_PA24218
  replace PA24219 with w_PA24219
  replace PA24220 with w_PA24220
  replace PA24221 with w_PA24221
  replace PA24211 with w_PA24211
  replace PA1111 with w_PA1111
  replace PA1112 with w_PA1112
  replace PA112 with w_PA112
  replace PA113 with w_PA113
  replace PA114 with w_PA114
  replace PA1151 with w_PA1151
  replace PA1152 with w_PA1152
  replace PA12131 with w_PA12131
  replace PA12131 with w_PA12131
  replace PAIMPEGN with w_PAIMPEGN
  replace PA_ESITO with w_PA_ESITO
  replace PAPRGINV with w_PAPRGINV
  replace PA_IDSDI with w_PA_IDSDI
  replace PAESICAU with w_PAESICAU
  replace PA2126 with w_PA2126
  replace PA2127 with w_PA2127
  replace PA_IDCOM with w_PA_IDCOM
  replace PAPROGID with w_PAPROGID
  replace PAANPROT with w_PAANPROT
  replace PACODBEN with w_PACODBEN
  * --- Area Manuale = Func Replace End
  * --- Fine Area Manuale
  return

* === F_Blank
function F_Blank
  * --- Area Manuale = Func Blank Init
  * --- Fine Area Manuale
  w_PANRPROT = 0
  w_PADTPROT = ctod("  /  /  ")
  w_PA21112 = space(2)
  w_PA2111 = space(4)
  w_PA2112 = space(3)
  w_PA2113 = ctod("  /  /  ")
  w_PA2114 = space(20)
  w_PA21151 = space(4)
  w_PA21152 = 0
  w_PA21153 = 0
  w_PA21154 = space(2)
  w_PA2119 = 0
  w_PA21110 = 0
  w_PA21111 = space(0)
  w_PAPATHFL = space(0)
  w_PA126 = space(20)
  w_PA12133 = space(60)
  w_PA12134 = space(10)
  w_PA12135 = space(17)
  w_PA1221 = space(80)
  w_PA1222 = space(8)
  w_PA1223 = space(5)
  w_PA1224 = space(80)
  w_PA1225 = space(2)
  w_PA1226 = space(2)
  w_PA1251 = space(12)
  w_PA1252 = space(12)
  w_PA1253 = space(0)
  w_PA12111 = space(2)
  w_PA12112 = space(28)
  w_PA1212 = space(16)
  w_PA12132 = space(60)
  w_PA241 = space(4)
  w_PA2421 = space(0)
  w_PA2422 = space(4)
  w_PA2423 = ctod("  /  /  ")
  w_PA2424 = 0
  w_PA2425 = ctod("  /  /  ")
  w_PA2426 = 0
  w_PA2427 = space(20)
  w_PA2428 = space(60)
  w_PA2429 = space(60)
  w_PA24210 = space(16)
  w_PA24212 = space(80)
  w_PA24213 = space(34)
  w_PA24214 = 0
  w_PA24215 = 0
  w_PA24216 = space(11)
  w_PA24217 = 0
  w_PA24218 = ctod("  /  /  ")
  w_PA24219 = 0
  w_PA24220 = ctod("  /  /  ")
  w_PA24221 = space(60)
  w_PA24211 = space(10)
  w_PA1111 = space(2)
  w_PA1112 = space(28)
  w_PA112 = space(10)
  w_PA113 = space(5)
  w_PA114 = space(8)
  w_PA1151 = space(12)
  w_PA1152 = space(0)
  w_PA12131 = space(80)
  w_PA12131 = space(80)
  w_PAIMPEGN = space(10)
  w_PA_ESITO = space(1)
  w_FILEESITO = space(120)
  w_PAPRGINV = 0
  w_PA_IDSDI = space(10)
  w_PAESICAU = space(60)
  w_NIMP = space(10)
  w_DIMP = space(10)
  w_CVG = 0
  w_DESPA = space(60)
  w_PA2126 = space(254)
  w_PA2127 = space(254)
  w_PA_IDCOM = space(10)
  w_PAPROGID = 0
  w_PAANPROT = space(4)
  w_PACODBEN = space(80)
  w_NIMP = substr(w_PAIMPEGN,5,LEN(w_PAIMPEGN)-4)
  w_DIMP = LEFT(w_PAIMPEGN,4)
  w_CVG = NDecVal(ValCon(ytos(w_PA2113)),'G')
  w_PAANPROT = ytos(w_PADTPROT)
  * --- Area Manuale = Func Blank End
  * --- Fine Area Manuale
  do Set_Radio
  return

* === F_Delete
function F_Delete
  parameters i_delete
  i_warea = "FTPA_XML"
  select FTPA_XML
  goto i_docreco
  * --- Area Manuale = Func Delete Init
  * --- Fine Area Manuale
  if i_delete

    delete
    skip
  endif
  * --- Area Manuale = Func Delete End
  * --- Fine Area Manuale
  return

function F_Edit
  private i_esci, i_upda
  i_upda = .f.
  i_help = "gopa_arx edit"
  if i_vidgrf
    if i_op=OP_EDITMOD
      modify window "gopa_arx" title "FATTURE  PA / Varia"
    endif
  endif
  * --- Area Manuale = Func Edit Init
  * --- Fine Area Manuale
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
  do while i_op=OP_EDITMOD .or. i_op=OP_EDITLOAD
    i_function = ""
    i_zoomprg  = ""
    if i_zbrow
      i_function = "Zoom"
    else
      activate window "gopa_arx"
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with i_op, .f.
      #endif
      * ---
      do case
        case i_pag=1
      @ i_posyx1[1,1],i_posyx1[1,2]+i_shx get w_PANRPROT picture '@Z 9999999999';
        size i_size1[1,1],i_size1[1,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PANRPROT",;
                0) .and.;
              F_Calc(.f.)
      @ i_posyx1[2,1],i_posyx1[2,2]+i_shx get w_PADTPROT;
        size i_size1[2,1],i_size1[2,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
                .and. F_def_1_2();
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PADTPROT",;
                ctod("  /  /  ")) .and.;
              F_Calc(.f.)
      @ i_posyx1[3,1],i_posyx1[3,2]+i_shx get w_PA21112 picture repl("X",2);
        size i_size1[3,1],i_size1[3,2]+i_shsz;
     disable
      @ i_posyx1[5,1],i_posyx1[5,2]+i_shx get w_PA2111 picture repl("X",4);
        size i_size1[5,1],i_size1[5,2]+i_shsz;
     disable
      @ i_posyx1[7,1],i_posyx1[7,2]+i_shx get w_PA2112 picture repl("X",3);
        size i_size1[7,1],i_size1[7,2]+i_shsz;
     disable
      @ i_posyx1[9,1],i_posyx1[9,2]+i_shx get w_PA2113;
        size i_size1[9,1],i_size1[9,2]+i_shsz;
     disable
      @ i_posyx1[11,1],i_posyx1[11,2]+i_shx get w_PA2114 picture repl("X",20);
        size i_size1[11,1],i_size1[11,2]+i_shsz;
     disable
      @ i_posyx1[13,1],i_posyx1[13,2]+i_shx get w_PA21151 picture repl("X",4);
        size i_size1[13,1],i_size1[13,2]+i_shsz;
     disable
      @ i_posyx1[15,1],i_posyx1[15,2]+i_shx get w_PA21152 picture "999999.99999";
        size i_size1[15,1],i_size1[15,2]+i_shsz;
     disable
      @ i_posyx1[17,1],i_posyx1[17,2]+i_shx get w_PA21153 picture "99.999";
        size i_size1[17,1],i_size1[17,2]+i_shsz;
     disable
      @ i_posyx1[19,1],i_posyx1[19,2]+i_shx get w_PA21154 picture repl("X",2);
        size i_size1[19,1],i_size1[19,2]+i_shsz;
     disable
      @ i_posyx1[21,1],i_posyx1[21,2]+i_shx get w_PA2119 picture v_ZR+PG(15,w_CVG);
        size i_size1[21,1],i_size1[21,2]+i_shsz;
     disable
      @ i_posyx1[23,1],i_posyx1[23,2]+i_shx get w_PA21110 picture "999999.99999";
        size i_size1[23,1],i_size1[23,2]+i_shsz;
     disable
      @ i_posyx1[25,1],i_posyx1[25,2] edit w_PA21111;
        size i_size1[25,1],i_size1[25,2] scroll;
       color (w_t_col004);
     disable
      @ i_posyx1[27,1],i_posyx1[27,2] edit w_PAPATHFL;
        size i_size1[27,1],i_size1[27,2] ;
       color (w_t_col004);
     disable
            @ i_posyx1[33,1],i_posyx1[33,2] get i_button picture iif(i_vidgrf,'@*B prvideo.bmp','@* Anteprima');
              size i_size1[33,1],i_size1[33,2];
              when .not.empty(w_PAPATHFL)  .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      @ i_posyx1[37,1],i_posyx1[37,2]+i_shx get w_PA12131 picture repl("X",80);
        size i_size1[37,1],i_size1[37,2]+i_shsz;
     disable
      @ i_posyx1[39,1],i_posyx1[39,2]+i_shx get w_PA2126 picture repl("X",254);
        size i_size1[39,1],i_size1[39,2]+i_shsz;
     disable
      @ i_posyx1[40,1],i_posyx1[40,2]+i_shx get w_PA2127 picture repl("X",254);
        size i_size1[40,1],i_size1[40,2]+i_shsz;
     disable
      @ i_posyx1[43,1],i_posyx1[43,2]+i_shx get w_PAPROGID picture '@Z 9999999999';
        size i_size1[43,1],i_size1[43,2]+i_shsz;
     disable
      @ i_posyx1[49,1],i_posyx1[49,2]+i_shx get w_PACODBEN picture repl("X",80);
        size i_size1[49,1],i_size1[49,2]+i_shsz;
     disable
        case i_pag=2
      @ i_posyx2[1,1],i_posyx2[1,2]+i_shx get w_PA126 picture repl("X",20);
        size i_size2[1,1],i_size2[1,2]+i_shsz;
     disable
      @ i_posyx2[3,1],i_posyx2[3,2]+i_shx get w_PA12133 picture repl("X",60);
        size i_size2[3,1],i_size2[3,2]+i_shsz;
     disable
      @ i_posyx2[6,1],i_posyx2[6,2]+i_shx get w_PA12135 picture repl("X",17);
        size i_size2[6,1],i_size2[6,2]+i_shsz;
     disable
      @ i_posyx2[8,1],i_posyx2[8,2]+i_shx get w_PA1221 picture repl("X",80);
        size i_size2[8,1],i_size2[8,2]+i_shsz;
     disable
      @ i_posyx2[10,1],i_posyx2[10,2]+i_shx get w_PA1222 picture repl("X",8);
        size i_size2[10,1],i_size2[10,2]+i_shsz;
     disable
      @ i_posyx2[12,1],i_posyx2[12,2]+i_shx get w_PA1223 picture repl("X",5);
        size i_size2[12,1],i_size2[12,2]+i_shsz;
     disable
      @ i_posyx2[14,1],i_posyx2[14,2]+i_shx get w_PA1224 picture repl("X",80);
        size i_size2[14,1],i_size2[14,2]+i_shsz;
     disable
      @ i_posyx2[16,1],i_posyx2[16,2]+i_shx get w_PA1225 picture repl("X",2);
        size i_size2[16,1],i_size2[16,2]+i_shsz;
     disable
      @ i_posyx2[18,1],i_posyx2[18,2]+i_shx get w_PA1226 picture repl("X",2);
        size i_size2[18,1],i_size2[18,2]+i_shsz;
     disable
      @ i_posyx2[20,1],i_posyx2[20,2]+i_shx get w_PA1251 picture repl("X",12);
        size i_size2[20,1],i_size2[20,2]+i_shsz;
     disable
      @ i_posyx2[22,1],i_posyx2[22,2]+i_shx get w_PA1252 picture repl("X",12);
        size i_size2[22,1],i_size2[22,2]+i_shsz;
     disable
      @ i_posyx2[24,1],i_posyx2[24,2] edit w_PA1253;
        size i_size2[24,1],i_size2[24,2] ;
       color (w_t_col004);
     disable
      @ i_posyx2[26,1],i_posyx2[26,2]+i_shx get w_PA12111 picture repl("X",2);
        size i_size2[26,1],i_size2[26,2]+i_shsz;
     disable
      @ i_posyx2[28,1],i_posyx2[28,2]+i_shx get w_PA12112 picture repl("X",28);
        size i_size2[28,1],i_size2[28,2]+i_shsz;
     disable
      @ i_posyx2[29,1],i_posyx2[29,2]+i_shx get w_PA1212 picture repl("X",16);
        size i_size2[29,1],i_size2[29,2]+i_shsz;
     disable
      @ i_posyx2[31,1],i_posyx2[31,2]+i_shx get w_PA12132 picture repl("X",60);
        size i_size2[31,1],i_size2[31,2]+i_shsz;
     disable
      @ i_posyx2[38,1],i_posyx2[38,2]+i_shx get w_PA12131 picture repl("X",80);
        size i_size2[38,1],i_size2[38,2]+i_shsz;
     disable
        case i_pag=3
      @ i_posyx3(1,1),i_posyx3(1,2) get r_PA241 function "*RH Pagamento a rate;Pagamento completo;Anticipo";
        color ,,,,,,,,&w_t_col005;
     disable
      @ i_posyx3[3,1],i_posyx3[3,2] edit w_PA2421;
        size i_size3[3,1],i_size3[3,2] ;
       color (w_t_col004);
     disable
      @ i_posyx3[5,1],i_posyx3[5,2]+i_shx get w_PA2422 picture repl("X",4);
        size i_size3[5,1],i_size3[5,2]+i_shsz;
     disable
      @ i_posyx3[7,1],i_posyx3[7,2]+i_shx get w_PA2423;
        size i_size3[7,1],i_size3[7,2]+i_shsz;
     disable
      @ i_posyx3[9,1],i_posyx3[9,2]+i_shx get w_PA2424 picture "999";
        size i_size3[9,1],i_size3[9,2]+i_shsz;
     disable
      @ i_posyx3[11,1],i_posyx3[11,2]+i_shx get w_PA2425;
        size i_size3[11,1],i_size3[11,2]+i_shsz;
     disable
      @ i_posyx3[13,1],i_posyx3[13,2]+i_shx get w_PA2426 picture "999999.99999";
        size i_size3[13,1],i_size3[13,2]+i_shsz;
     disable
      @ i_posyx3[15,1],i_posyx3[15,2]+i_shx get w_PA2427 picture repl("X",20);
        size i_size3[15,1],i_size3[15,2]+i_shsz;
     disable
      @ i_posyx3[17,1],i_posyx3[17,2]+i_shx get w_PA2428 picture repl("X",60);
        size i_size3[17,1],i_size3[17,2]+i_shsz;
     disable
      @ i_posyx3[19,1],i_posyx3[19,2]+i_shx get w_PA2429 picture repl("X",60);
        size i_size3[19,1],i_size3[19,2]+i_shsz;
     disable
      @ i_posyx3[21,1],i_posyx3[21,2]+i_shx get w_PA24210 picture repl("X",16);
        size i_size3[21,1],i_size3[21,2]+i_shsz;
     disable
      @ i_posyx3[23,1],i_posyx3[23,2]+i_shx get w_PA24212 picture repl("X",80);
        size i_size3[23,1],i_size3[23,2]+i_shsz;
     disable
      @ i_posyx3[25,1],i_posyx3[25,2]+i_shx get w_PA24213 picture repl("X",34);
        size i_size3[25,1],i_size3[25,2]+i_shsz;
     disable
      @ i_posyx3[27,1],i_posyx3[27,2]+i_shx get w_PA24214 picture "99999";
        size i_size3[27,1],i_size3[27,2]+i_shsz;
     disable
      @ i_posyx3[29,1],i_posyx3[29,2]+i_shx get w_PA24215 picture "99999";
        size i_size3[29,1],i_size3[29,2]+i_shsz;
     disable
      @ i_posyx3[31,1],i_posyx3[31,2]+i_shx get w_PA24216 picture repl("X",11);
        size i_size3[31,1],i_size3[31,2]+i_shsz;
     disable
      @ i_posyx3[33,1],i_posyx3[33,2]+i_shx get w_PA24217 picture "999999.99999";
        size i_size3[33,1],i_size3[33,2]+i_shsz;
     disable
      @ i_posyx3[35,1],i_posyx3[35,2]+i_shx get w_PA24218;
        size i_size3[35,1],i_size3[35,2]+i_shsz;
     disable
      @ i_posyx3[37,1],i_posyx3[37,2]+i_shx get w_PA24219 picture "999999.99999";
        size i_size3[37,1],i_size3[37,2]+i_shsz;
     disable
      @ i_posyx3[39,1],i_posyx3[39,2]+i_shx get w_PA24220;
        size i_size3[39,1],i_size3[39,2]+i_shsz;
     disable
      @ i_posyx3[41,1],i_posyx3[41,2]+i_shx get w_PA24221 picture repl("X",60);
        size i_size3[41,1],i_size3[41,2]+i_shsz;
     disable
      @ i_posyx3[49,1],i_posyx3[49,2]+i_shx get w_DESPA picture repl("X",60);
        size i_size3[49,1],i_size3[49,2]+i_shsz;
     disable
        case i_pag=4
      @ i_posyx4[1,1],i_posyx4[1,2]+i_shx get w_PA1111 picture repl("X",2);
        size i_size4[1,1],i_size4[1,2]+i_shsz;
     disable
      @ i_posyx4[3,1],i_posyx4[3,2]+i_shx get w_PA1112 picture repl("X",28);
        size i_size4[3,1],i_size4[3,2]+i_shsz;
     disable
      @ i_posyx4[4,1],i_posyx4[4,2]+i_shx get w_PA112 picture repl("X",10);
        size i_size4[4,1],i_size4[4,2]+i_shsz;
     disable
      @ i_posyx4[6,1],i_posyx4[6,2]+i_shx get w_PA113 picture repl("X",5);
        size i_size4[6,1],i_size4[6,2]+i_shsz;
     disable
      @ i_posyx4[8,1],i_posyx4[8,2]+i_shx get w_PA114 picture repl("X",8);
        size i_size4[8,1],i_size4[8,2]+i_shsz;
     disable
      @ i_posyx4[10,1],i_posyx4[10,2]+i_shx get w_PA1151 picture repl("X",12);
        size i_size4[10,1],i_size4[10,2]+i_shsz;
     disable
      @ i_posyx4[12,1],i_posyx4[12,2] edit w_PA1152;
        size i_size4[12,1],i_size4[12,2] ;
       color (w_t_col004);
     disable
        case i_pag=5
            @ i_posyx5[1,1],i_posyx5[1,2] get i_button picture '@* Genera Impegno';
              size i_size5[1,1],i_size5[1,2];
              when .not.empty(w_PAPATHFL) and empty(w_PAIMPEGN) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

            @ i_posyx5[3,1],i_posyx5[3,2] get i_button picture '@* Genera/Varia Esito';
              size i_size5[3,1],i_size5[3,2];
              when .not.empty(w_FILEESITO) AND .not.empty(w_PA_ESITO) AND .not.empty(w_PA_IDSDI) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      @ i_posyx5(4,1),i_posyx5(4,2) get r_PA_ESITO function "*R Accettata;Rifiutata";
        color ,,,,,,,,&w_t_col005;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_PA_ESITO",;
                space(1)) .and.;
              F_Calc(.f.)
      @ i_posyx5[5,1],i_posyx5[5,2]+i_shx get w_FILEESITO picture repl("X",120);
        size i_size5[5,1],i_size5[5,2]+i_shsz;
     disable
            @ i_posyx5[6,1],i_posyx5[6,2] get i_button picture '@* ...';
              size i_size5[6,1],i_size5[6,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      @ i_posyx5[10,1],i_posyx5[10,2]+i_shx get w_PAPRGINV;
        size i_size5[10,1],i_size5[10,2]+i_shsz;
     disable
      @ i_posyx5[11,1],i_posyx5[11,2]+i_shx get w_PA_IDSDI picture repl("X",10);
        size i_size5[11,1],i_size5[11,2]+i_shsz;
     disable
      @ i_posyx5[14,1],i_posyx5[14,2]+i_shx get w_PAESICAU picture repl("X",60);
        size i_size5[14,1],i_size5[14,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_PAESICAU",;
                space(60)) .and.;
              F_Calc(.f.)
      @ i_posyx5[18,1],i_posyx5[18,2]+i_shx get w_NIMP picture repl("X",10);
        size i_size5[18,1],i_size5[18,2]+i_shsz;
     disable
      @ i_posyx5[19,1],i_posyx5[19,2]+i_shx get w_DIMP picture repl("X",10);
        size i_size5[19,1],i_size5[19,2]+i_shsz;
     disable
            @ i_posyx5[22,1],i_posyx5[22,2] get i_button picture '@* Associa Impegno';
              size i_size5[22,1],i_size5[22,2];
              when .not.empty(w_PAPATHFL) and empty(w_PAIMPEGN) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

            @ i_posyx5[23,1],i_posyx5[23,2] get i_button picture '@* Rimuovi Rif. Impegno';
              size i_size5[23,1],i_size5[23,2];
              when .not. empty(w_PAIMPEGN) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      @ i_posyx5[24,1],i_posyx5[24,2]+i_shx get w_PA_IDCOM picture repl("X",10);
        size i_size5[24,1],i_size5[24,2]+i_shsz;
     disable
      endcase
      if i_vidgrf
        do gettab with at_x(757),5
      endif
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gopa_arx")
      * --- Area Manuale = Func Edit Chkread2
      * --- Fine Area Manuale
    endif
    do case
      * --- Area Manuale = Func Edit Funckeys
      * --- Fine Area Manuale
      case .not. empty(i_todo)
        i_oldop = i_op
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Save"
        i_esci = .f.
        do case
          * --- Area Manuale = Func Edit Confirm
          * --- Fine Area Manuale
          * --- Controllo dei campi obbligatori nelle righe del corpo
          case F_ChkAutoLock()
            i_esci = .t.
            * --- Area Manuale = Func Edit Save
            * --- Fine Area Manuale
        endcase
        if i_esci
          if i_op=OP_EDITMOD
            do F_Delete with .f.
          endif
          do F_Replace
          unlock
          if i_op=OP_EDITMOD
            i_op = OP_QUERY
            * --- Event = Record Modified
            * --- End Event
          else
            i_op = OP_LOAD
            * --- Event = Record Added
            * --- End Event
            do F_Blank
            i_campo = i_nbtntbar+1
          endif
          do Paint_Pag
          do cplu_alk with "FTPA_XML",.f.
        else
          do F_Paint with 0
        endif
      case i_function="Prior" .or. i_function="Next"
      case i_function="Delete"
      case i_function="Zoom"
        i_oldop = i_op
        i_op = OP_ZOOM
        do case
          case i_pag=1
            do case
              case i_campo=16+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do GOPA_BFS with  "A", w_PA1111, w_PA1112, w_PA112'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
            endcase
          case i_pag=2
            do case
            endcase
          case i_pag=3
            do case
            endcase
          case i_pag=4
            do case
            endcase
          case i_pag=5
            do case
              case i_campo=1+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do GOPA_BFS with  "I", w_PA1111, w_PA1112, w_PA112'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=2+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do GOPA_BFS with  "E", w_PA1111, w_PA1112, w_PA112'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=6+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'DO READPATH'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=12+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do GOPA_BFS with  "Z", w_PA1111, w_PA1112, w_PA112'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=13+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do GOPA_BFS with  "R", w_PA1111, w_PA1112, w_PA112'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
            endcase
        endcase
        if .not. i_zbrow
          do F_Calc with .t.
          i_op = i_oldop
        endif
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
        w_s = .t.
        if w_s
          if i_op=OP_EDITLOAD
            select FTPA_XML
            i_docreco = recno()
            delete
            do F_Blank
          endif
          unlock
          i_op = iif(wvisible("gopa_arx"),OP_QUERY,OP_QUIT)
          if i_op<>OP_QUIT
            do Paint_Pag
          endif
          do cplu_alk with "FTPA_XML",.f.
        endif
      case (((readkey()=15 .or. readkey()=5) .and. readkey(1)=1) .or. i_function="PgDn") .and. i_pag<5
        i_pag = i_pag+1
        do F_Paint with 0
        i_campo = i_nbtntbar+1
      case ((readkey()=4 .and. readkey(1)=1) .or. i_function="PgUp") .and. i_pag>1
        i_pag = i_pag-1
        do F_Paint with 0
        i_campo = iif(readkey()=4,i_campg[i_pag]+i_nbtntbar,i_nbtntbar+1)
    endcase
  enddo
  * --- Area Manuale = Func Edit End
  * --- Fine Area Manuale
  return

function F_KeyEdit
  private i_upda
  i_upda = .f.
  i_help     = "gopa_arx carica chiave"
  if i_vidgrf
    modify window "gopa_arx" title "FATTURE  PA / Carica"
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
    return
  * --- Area Manuale = Func Keyedit Init
  * --- Fine Area Manuale
  do while .t.
    i_function = ""
    i_zoomprg  = ""
    activate window "gopa_arx"
    if i_zbrow
      i_function = "Zoom"
    else
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with OP_LOAD, .f.
      #endif
      * ---
      @ i_posyx1[3,1],i_posyx1[3,2]+i_shx get w_PA21112 picture repl("X",2);
        size i_size1[3,1],i_size1[3,2]+i_shsz;
     disable
      @ i_posyx1[5,1],i_posyx1[5,2]+i_shx get w_PA2111 picture repl("X",4);
        size i_size1[5,1],i_size1[5,2]+i_shsz;
     disable
      @ i_posyx1[7,1],i_posyx1[7,2]+i_shx get w_PA2112 picture repl("X",3);
        size i_size1[7,1],i_size1[7,2]+i_shsz;
     disable
      @ i_posyx1[9,1],i_posyx1[9,2]+i_shx get w_PA2113;
        size i_size1[9,1],i_size1[9,2]+i_shsz;
     disable
      @ i_posyx1[11,1],i_posyx1[11,2]+i_shx get w_PA2114 picture repl("X",20);
        size i_size1[11,1],i_size1[11,2]+i_shsz;
     disable
      @ i_posyx1[13,1],i_posyx1[13,2]+i_shx get w_PA21151 picture repl("X",4);
        size i_size1[13,1],i_size1[13,2]+i_shsz;
     disable
      @ i_posyx1[15,1],i_posyx1[15,2]+i_shx get w_PA21152 picture "999999.99999";
        size i_size1[15,1],i_size1[15,2]+i_shsz;
     disable
      @ i_posyx1[17,1],i_posyx1[17,2]+i_shx get w_PA21153 picture "99.999";
        size i_size1[17,1],i_size1[17,2]+i_shsz;
     disable
      @ i_posyx1[19,1],i_posyx1[19,2]+i_shx get w_PA21154 picture repl("X",2);
        size i_size1[19,1],i_size1[19,2]+i_shsz;
     disable
      @ i_posyx1[21,1],i_posyx1[21,2]+i_shx get w_PA2119 picture v_ZR+PG(15,w_CVG);
        size i_size1[21,1],i_size1[21,2]+i_shsz;
     disable
      @ i_posyx1[23,1],i_posyx1[23,2]+i_shx get w_PA21110 picture "999999.99999";
        size i_size1[23,1],i_size1[23,2]+i_shsz;
     disable
      @ i_posyx1[25,1],i_posyx1[25,2] edit w_PA21111;
        size i_size1[25,1],i_size1[25,2] scroll;
       color (w_t_col004);
     disable
      @ i_posyx1[27,1],i_posyx1[27,2] edit w_PAPATHFL;
        size i_size1[27,1],i_size1[27,2] ;
       color (w_t_col004);
     disable
      @ i_posyx1[37,1],i_posyx1[37,2]+i_shx get w_PA12131 picture repl("X",80);
        size i_size1[37,1],i_size1[37,2]+i_shsz;
     disable
      @ i_posyx1[39,1],i_posyx1[39,2]+i_shx get w_PA2126 picture repl("X",254);
        size i_size1[39,1],i_size1[39,2]+i_shsz;
     disable
      @ i_posyx1[40,1],i_posyx1[40,2]+i_shx get w_PA2127 picture repl("X",254);
        size i_size1[40,1],i_size1[40,2]+i_shsz;
     disable
      @ i_posyx1[43,1],i_posyx1[43,2]+i_shx get w_PAPROGID picture '@Z 9999999999';
        size i_size1[43,1],i_size1[43,2]+i_shsz;
     disable
      @ i_posyx1[49,1],i_posyx1[49,2]+i_shx get w_PACODBEN picture repl("X",80);
        size i_size1[49,1],i_size1[49,2]+i_shsz;
     disable
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gopa_arx")
    endif
    do case
      case .not. empty(i_todo)
        i_oldop = OP_LOAD
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Prior" .or. i_function="Next"
      case i_function="Zoom"
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
        i_op = OP_QUIT
        if wvisible("gopa_arx")
          do F_Blank
          do F_Paint with 1
        endif
    endcase
    if i_op=OP_ZOOM.or.i_op=OP_INTR.or.i_op=OP_QUIT.or.(;
        (readkey()=15.or.readkey()=271.or.readkey()=5);
        .and. readkey(1)=1)
      * --- Area Manuale = Func Keyedit Save
      * --- Fine Area Manuale
      exit
    endif
  enddo
  * --- Area Manuale = Func Keyedit End
  * --- Fine Area Manuale
  return

function F_def_1_2
  if empty(w_PADTPROT)
  w_PADTPROT = i_datlav
    i_upda = .t.
  endif
  return .t.

function F_dep
  parameter i_skip,i_zoom
  if _curobj>i_nbtntbar
    i_campo = _curobj
  endif
  i_accpt = .t.
  o_PADTPROT = w_PADTPROT
  if .not. chrsaw()
    * --- FP3
    #if .not. (left(version(),13)="Visual FoxPro")
      show object 4 disable
      if i_skip
        show object 6 enable
        show object 7 enable
      else
        show object 6 disable
        show object 7 disable
      endif
      if i_zoom
        show object 8 enable
      else
        show object 8 disable
      endif
      if i_pag<>1
        show object 9 enable
      else
        show object 9 disable
      endif
      if i_pag<>5
        show object 10 enable
      else
        show object 10 disable
      endif
    #else
      * --- Parte per FoxPro3
      if i_skip
        oCPToolBar.b7.enabled = .t.
        oCPToolBar.b8.enabled = .t.
      else
        oCPToolBar.b7.enabled = .f.
        oCPToolBar.b8.enabled = .f.
      endif
      if i_zoom
        oCPToolBar.b9.enabled = .t.
      else
        oCPToolBar.b9.enabled = .f.
      endif
    #endif
    * ---
  endif
  * --- Area Manuale = Function Dep
  * --- Fine Area Manuale
  return .t.

function F_calc
  parameter i_upd
  * --- Area Manuale = Func Edit Calc Alws
  * --- Fine Area Manuale
  w_NIMP = substr(w_PAIMPEGN,5,LEN(w_PAIMPEGN)-4)
  w_DIMP = LEFT(w_PAIMPEGN,4)
  if updated() .or. i_upd .or. i_upda
    * --- Area Manuale = Func Edit Calc
    * --- Fine Area Manuale
    do F_Lnk2_28
    do F_Lnk2_29
    do F_Lnk3_5
      w_CVG = NDecVal(ValCon(ytos(w_PA2113)),'G')
    if o_PADTPROT<>w_PADTPROT
      w_PAANPROT = ytos(w_PADTPROT)
    endif
    do Set_Radio
    show gets
  endif
  i_upda = .f.
  return .t.

function F_Lnk2_28
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[1,1] = 0
  do cplu_fld with "w_PA12112","BEN_EFIC",1,"BEPARIVA","w_DESBEN","BERAGSOC",w_s
  return w_s

function F_Lnk2_29
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[1,1] = 0
  do cplu_fld with "w_PA1212","BEN_EFIC",1,"BECODFIS","w_DESBEN","BERAGSOC",w_s
  return w_s

function F_Lnk3_5
  w_s = .t.
  i_rdkey = ""
  i_rdkvars[1,1] = 0
  i_rdvars[1,1] = 0
  do cplu_fld with "w_PA2422","FTPA_PAG",1,"PGCODICE","w_DESPA","PGDESCRI",w_s
  return w_s

function Set_Radio
  w_PA241=trim(w_PA241)
  r_PA241 = ;
    iif(w_PA241=='TP01',1,;
    iif(w_PA241=='TP02',2,;
    iif(w_PA241=='TP03',3,;
    0)))
  w_PA_ESITO=trim(w_PA_ESITO)
  r_PA_ESITO = ;
    iif(w_PA_ESITO=='S',1,;
    iif(w_PA_ESITO=='N',2,;
    0))
  return .t.

function Get_Radio
  w_PA241 = iif(r_PA241=1,'TP01',;
    iif(r_PA241=2,'TP02',;
    iif(r_PA241=3,'TP03',;
    space(4))))
  w_PA_ESITO = iif(r_PA_ESITO=1,'S',;
    iif(r_PA_ESITO=2,'N',;
    space(1)))
  return .t.

function at_x
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(6)
  else
    i_pos = i_pos / fontmetric(6,i_fnt,i_h,i_s)
  endif
  return i_pos

function at_y
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(1)
  else
    i_pos = i_pos / fontmetric(1,i_fnt,i_h,i_s)
  endif
  return i_pos

function F_Check
  parameter i_chk, i_obbl, i_var, i_value, i_msg
  i_accpt = i_chk .and. (.not. i_obbl .or. &i_var<>i_value)
  if .not. i_accpt
    if wontop()<>'BUTTONS'
      _curobj = _curobj
    endif
    if .not.("|"+i_function+"|"$"|Zoom|Prior|Next|")
      do cplu_erm with iif(empty(i_msg),iif(.not.i_chk,w_t_mseerr,w_t_mseobl),i_msg)
    endif
    &i_var = i_value
    if i_function = "Save"
      i_function = ""
    endif
  endif
  return .t.

procedure F_ChkAutoLock
  private i_rsp
  i_rsp = .t.
  return i_rsp

procedure Paint_Pag
  if i_pag>1
    i_pag = 1
    do F_Paint with 0
  else
    do F_Paint with 1
  endif
  return

procedure cplu_pn
  if i_function="Next"
    if .not. eof()
      skip
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    else
      do cplu_erm with w_t_msqefl
      i_loaded = .f.
      i_docreco = 0
    endif
  else
    if .not. bof()
      skip -1
    endif
    if .not. bof()
      i_loaded = .t.
      i_docreco = recno()
    else
      do cplu_erm with w_t_msqsfl
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    endif
  endif
  do F_Read
  do F_Paint with 1
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  return

procedure f_r
  #if left(version(),13)="Visual FoxPro"
  _curobj = _curobj
  #endif
  if .not. found()
    do cplu_erm with w_t_msmnr
    i_loaded = .f.
    i_docreco = 0
  else
    i_docreco = recno()
    i_loaded = .t.
    do F_Read
    do F_Paint with 1
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  clear read
  return

procedure cplu_3d
  parameter i_y,i_x,i_h,i_w,rilievo,fontn,fontp,fonts
  private i_color1,i_color2,i_ww,i_hh,i_olderror
  if parameters()>4 .and. rilievo
    i_color2 =  "rgb(92,92,92,92,92,92)"
    i_color1 =  "rgb(255,255,255,255,255,255)"
  else
    i_color1 =  "rgb(92,92,92,92,92,92)"
    i_color2 =  "rgb(255,255,255,255,255,255)"
  endif
  if parameters()>5
    i_h = i_h*fontmetric(1,fontn,fontp,fonts)/fontmetric(1)
    i_w = i_w*fontmetric(6,fontn,fontp,fonts)/fontmetric(6)
  endif
  i_olderror=on('ERROR')
  on error =.f.
  i_hh = 1/fontmetric(1)
  i_ww = 1/fontmetric(6)
  @ i_y-i_hh,i_x-i_ww     to i_y-i_hh,i_x+i_w+i_ww pen 1 color (i_color1)
  @ i_y-i_hh,i_x-i_ww     to i_y+i_h+i_hh,i_x-i_ww pen 1 color (i_color1)
  @ i_y+i_h+i_hh,i_x-i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  @ i_y-i_hh,i_x+i_w+i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  on error &i_olderror
  return

function cplu_tag
  param p
  i_pag=p
  i_campo = i_nbtntbar+1
  i_function="Repaint"
  return(.t.)

procedure gettab
  param wh,ntab
  private TABSZ,i,cwh,cntab,ci
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ci=alltrim(str(i))
    @ 0.4,TABSZ*(i-1)+1 get i_button size 1,TABSZ-2 pict "@*IT" valid cplu_tag(&ci)
  next
  return

procedure paintcurrtab
  param wh,ntab,ct
  private TABSZ
  TABSZ=min(int(wh/ntab),20)
  ct=ct-1
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  @ 1.5,ct*TABSZ to 1.5,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  @ 1.6,ct*TABSZ to 1.6,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  return

procedure painttab
  param wh,ntab
  private i,TABSZ
  TABSZ=min(int(wh/ntab),20)
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  for i=1 to ntab
    * --- linea orizzontale
    @ 0,(i-1)*TABSZ to 0,i*TABSZ-0.5 color rgb(255,255,255)
    * --- linee vericali
    @ 0,(i-1)*TABSZ to 1.5,(i-1)*TABSZ color rgb(255,255,255)
    @ 0.1,i*TABSZ-0.4 to 1.5,i*TABSZ-0.4
  next
  return

procedure painttabtitle
  param wh,ntab,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10
  private TABSZ,i,ii
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ii=alltrim(str(i))
    @ 0.3,TABSZ*(i-1)+1 say t&ii size 1,TABSZ-2 pict "@I"
  next
  return

* --- Area Manuale = Functions & Procedures
* --- gopa_arx
PROCEDURE READPATH
w_DIRESITO=''
w_ERR = .f.
on error w_ERR=.t.
w_LEN=LEN(JUSTFNAME(w_PAPATHFL)) - 4
w_FILEESITO = GETDIR(alltrim(w_FILEESITO) ,"Percorso file")
if len(w_FILEESITO) > 0
  w_FILEESITO = ALLTRIM(w_FILEESITO) + LEFT(JUSTFNAME(w_PAPATHFL),w_LEN) + '_EC_' + RIGHT('000' + ALLTRIM(STR(w_PAPRGINV+1)),3) + '.xml'
endif
on error
RETURN

* --- Fine Area Manuale
