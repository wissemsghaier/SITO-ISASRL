* ---------------------------------------------------------------------------- *
* #%&%#Build:  57
*                                                                              *
*   Procedure: gast_sel                                                        *
*              STAMPA CON SELEZIONE LIBERA                                     *
*                                                                              *
*      Author: ISA COMPUTER & SOFTWARE                                         *
*      Client: ALBO                                                            *
*                                                                              *
*    Language:                                                                 *
*          OS:                                                                 *
*                                                                              *
*     Version:                                                                 *
* Date creat.: 2003-01-31                                                      *
* Last revis.: 2015-09-24                                                      *
*                                                                              *
*                                                                              *
* ---------------------------------------------------------------------------- *
* --- Area Manuale = Header
* --- Fine Area Manuale
* ----------------------------------------
* variabile pubblica che conterra' lo stato del programma
* in modo che possa riprendere da dove si era interrotto
public array s_gast_sel[34]

private i_op
#define OP_QUERY     1
#define OP_LOAD      2
#define OP_EDITMOD   3
#define OP_EDITLOAD  4
#define OP_ZOOM      5
#define OP_QUIT      6
#define OP_INTR      7
i_op = OP_QUERY

* --- Variabili locali
private i_modal
i_modal = .t.
i_3d = iif(type("i_3d")="U",.t.,i_3d)
private i_shx,i_shsz
store 0 to i_shx,i_shsz
private i_loaded,w_s,i_campo,i_campoq,i_docreco, i_campg, i_accpt, i_zoomrec
private i_rdvars,i_rdkvars,i_rdkey, i_zoompars, i_zbrow, i_paint, i_oldarea
private i_pag,i_button,i_function,i_oldop,i_zoomprg, i_openfail, i_help, i_twind
private i_posyx1, i_size1, i_font1, i_style1
dimension i_posyx1[38,2], i_size1[38,2], i_font1[38,2], i_style1[38]
dimension i_campg[1]
dimension i_rdvars[41,2],i_rdkvars[6,2],i_zoompars[3]
store 1 to i_pag, i_button, i_campoq
i_campo  = i_nbtntbar+1
store .f. to i_loaded, i_zbrow, i_paint, i_accpt, i_openfail
store 0 to i_oldop, i_docreco
store " " to i_function, w_s, i_zoomprg, i_rdkey, i_help
store 0 to i_rdvars[1,1],i_rdkvars[1,1]
i_campg[1] = 31
private wnd_gast_sel
wnd_gast_sel = ' '

***
* Descrizione analisi STAMPA CON SELEZIONE LIBERA
***

private i_fngast_sel


private w_FILTRO1,w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1
private w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2,w_FIELD3
private w_OPERA3,w_CONFR3,w_CONG3,w_FIELD4,w_OPERA4
private w_CONFR4,w_CONG4,w_FIELD5,w_OPERA5,w_CONFR5
private w_INDSTA,w_ORDINE,w_INTSTA,w_FILTRO2,w_FILTRO3
private w_FILTRO4
store " " to w_FILTRO1,w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1
store " " to w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2,w_FIELD3
store " " to w_OPERA3,w_CONFR3,w_CONG3,w_FIELD4,w_OPERA4
store " " to w_CONFR4,w_CONG4,w_FIELD5,w_OPERA5,w_CONFR5
store " " to w_INDSTA,w_ORDINE,w_INTSTA,w_FILTRO2,w_FILTRO3
store " " to w_FILTRO4


private r_OPERA1,r_CONG1,r_OPERA2,r_CONG2,r_OPERA3
private r_CONG3,r_OPERA4,r_CONG4,r_OPERA5,r_INDSTA
private r_ORDINE
store 0 to r_OPERA1,r_CONG1,r_OPERA2,r_CONG2,r_OPERA3
store 0 to r_CONG3,r_OPERA4,r_CONG4,r_OPERA5,r_INDSTA
store 0 to r_ORDINE
i_oldarea = select()
if .not. wexist("gast_sel")
  * --- se non esiste la finestra prova
  *     allora il programma non e' gia' attivo
  if .not. OpenProc()
    return
  endif
  * --- Event = Program Start
  * --- End Event
  i_op = OP_QUERY
  * --- Area Manuale = Init
  * --- Fine Area Manuale
  do F_Blank
  do Ass_pos
  do F_Paint with 0
else
  private i_ay
  i_ay = 0
  if _windows
    activate window "gast_sel" noshow same
    modify window "gast_sel" at wlrow(),wlcol() ;
      size at_y(324,"Arial",9,"")+i_ay,at_x(441,"Arial",9,"")
  else
    if _mac
      activate window "gast_sel" noshow same
      modify window "gast_sel" at wlrow(),wlcol() ;
        size at_y(324,"Arial",9*4/3,"")+i_ay,at_x(441,"Arial",9*4/3,"")
    endif
  endif
  do RestoreStatus
endif
do while i_op<>OP_QUIT .and. i_op<>OP_INTR
  do case
    case i_op=OP_QUERY .or. i_op=OP_EDITMOD
      i_op = OP_EDITMOD
      do F_Edit
    case i_op=OP_ZOOM
      &i_zoomprg
      do RestoreFilters
      i_op = iif(.not. empty(i_todo),OP_INTR,i_oldop)
  endcase
enddo
if i_op=OP_QUIT
  * --- Area Manuale = End
  * --- Fine Area Manuale
  * --- Event = Program End
  * --- End Event
  do CloseProc
else
  do SaveStatus
endif
i_warea = alltrim(str(i_oldarea))
select (i_oldarea)
return

* === OpenProc
*     definisce la finestra, blank alle variabili di lavoro
procedure OpenProc
  private i_ok,i_ay,i_pv,i_wnd
  i_ok = OpenFiles()
  i_ay = 0
  i_wnd = iif(empty(wontop()) or wontop()="BUTTONS","","in window ('"+wontop()+"')")
  if i_ok
    * --- FP3
    #if left(version(),13)="Visual FoxPro"
    i_twind = "system name wnd_gast_sel"
    i_pv=at_y(6)
    #else
    i_twind = "close grow"
    i_pv=iif(i_vtoolbar,at_y(6),max(at_y(6),2.8))
    #endif
    * ---
    do case
      case _windows
        define window "gast_sel" at i_pv,at_x(9) size at_y(324,"Arial",9,"")+i_ay,at_x(441,"Arial",9,"");
          font "Arial",9;
          title "STAMPA CON SELEZIONE LIBERA";
          minimize float &i_twind icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

        modify window "gast_sel" at i_pv,at_x(9) size at_y(324,"Arial",9,"")+i_ay,at_x(441,"Arial",9,"")
      case _mac
        i_pv=iif(i_vtoolbar,at_y(6),max(at_y(6),2.8))
        define window "gast_sel" at i_pv,at_x(9) size at_y(324,"Arial",9*4/3,"")+i_ay,at_x(441,"Arial",9*4/3,"");
          font "Arial",9*4/3;
          title "STAMPA CON SELEZIONE LIBERA";
          minimize float close grow icon file "anag.ico";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

      otherwise
        define window "gast_sel" from 0,1 to 18,56;
          title "  STAMPA CON SELEZIONE LIBERA  ";
          minimize float close  "�","�","�","�","�","�","�","�";
        color &w_t_col005,,&w_t_col005,&w_t_col002,&w_t_col002,,,,&w_t_col004,&w_t_col004

    endcase
set topic to 'STAMPA CON SELEZIONE LIBERA (programma)'
  endif
  return i_ok

* === OpenFiles
function OpenFiles
  private i_ok,i_w1,i_w2
  i_ok = .t.
  * --- Apertura dei files
  i_w1 = cplu_opf("ANA_ALBO",'')
  i_w2 = cplu_opf("TAB_MTIT",'')
set exclusive off
  if .not.(i_w1 .and. i_w2)
    i_ok = .f.
    do cplu_clf with "ANA_ALBO",i_w1,''
    do cplu_clf with "TAB_MTIT",i_w2,''
  endif
  return i_ok

* === CloseProc
procedure CloseProc
  release window "gast_sel"
  do CloseFiles
  * --- Fp3
  #if left(version(),13)="Visual FoxPro"
    oCpToolBar.Enable(.f.)
  #endif
  * ---
  return

* === CloseFiles
procedure CloseFiles
  do cplu_clf with "ANA_ALBO",.t.,''
  do cplu_clf with "TAB_MTIT",.t.,''
  return

procedure RestoreStatus
  private i_zop
  i_docreco = s_gast_sel[1]
  i_oldop   = s_gast_sel[2]
  i_zoomprg = s_gast_sel[3]
  i_campo   = s_gast_sel[4]
  i_campoq  = s_gast_sel[5]
  i_pag     = s_gast_sel[6]
  i_loaded  = s_gast_sel[7]
  i_zbrow   = s_gast_sel[8]
  i_zop     = substr(i_zoomprg,4,len(i_zoomprg)-3)
  i_op      = iif(.not. empty(i_zoomprg) .and. (wvisible(i_zop) .or. .not. i_zbrow),OP_ZOOM,i_oldop)
  w_FILTRO1 = s_gast_sel[9]
  w_FIELD1 = s_gast_sel[10]
  w_OPERA1 = s_gast_sel[11]
  w_CONFR1 = s_gast_sel[12]
  w_CONG1 = s_gast_sel[13]
  w_FIELD2 = s_gast_sel[14]
  w_OPERA2 = s_gast_sel[15]
  w_CONFR2 = s_gast_sel[16]
  w_CONG2 = s_gast_sel[17]
  w_FIELD3 = s_gast_sel[18]
  w_OPERA3 = s_gast_sel[19]
  w_CONFR3 = s_gast_sel[20]
  w_CONG3 = s_gast_sel[21]
  w_FIELD4 = s_gast_sel[22]
  w_OPERA4 = s_gast_sel[23]
  w_CONFR4 = s_gast_sel[24]
  w_CONG4 = s_gast_sel[25]
  w_FIELD5 = s_gast_sel[26]
  w_OPERA5 = s_gast_sel[27]
  w_CONFR5 = s_gast_sel[28]
  w_INDSTA = s_gast_sel[29]
  w_ORDINE = s_gast_sel[30]
  w_INTSTA = s_gast_sel[31]
  w_FILTRO2 = s_gast_sel[32]
  w_FILTRO3 = s_gast_sel[33]
  w_FILTRO4 = s_gast_sel[34]
  do RestoreFilters
  do Ass_pos
  return

procedure RestoreFilters
  do Set_Radio
set topic to 'STAMPA CON SELEZIONE LIBERA (programma)'
  return

procedure SaveStatus
  s_gast_sel[1] = i_docreco
  s_gast_sel[2] = i_oldop
  s_gast_sel[3] = i_zoomprg
  s_gast_sel[4] = i_campo
  s_gast_sel[5] = i_campoq
  s_gast_sel[6] = i_pag
  s_gast_sel[7] = i_loaded
  s_gast_sel[8] = i_zbrow
  s_gast_sel[9] = w_FILTRO1
  s_gast_sel[10] = w_FIELD1
  s_gast_sel[11] = w_OPERA1
  s_gast_sel[12] = w_CONFR1
  s_gast_sel[13] = w_CONG1
  s_gast_sel[14] = w_FIELD2
  s_gast_sel[15] = w_OPERA2
  s_gast_sel[16] = w_CONFR2
  s_gast_sel[17] = w_CONG2
  s_gast_sel[18] = w_FIELD3
  s_gast_sel[19] = w_OPERA3
  s_gast_sel[20] = w_CONFR3
  s_gast_sel[21] = w_CONG3
  s_gast_sel[22] = w_FIELD4
  s_gast_sel[23] = w_OPERA4
  s_gast_sel[24] = w_CONFR4
  s_gast_sel[25] = w_CONG4
  s_gast_sel[26] = w_FIELD5
  s_gast_sel[27] = w_OPERA5
  s_gast_sel[28] = w_CONFR5
  s_gast_sel[29] = w_INDSTA
  s_gast_sel[30] = w_ORDINE
  s_gast_sel[31] = w_INTSTA
  s_gast_sel[32] = w_FILTRO2
  s_gast_sel[33] = w_FILTRO3
  s_gast_sel[34] = w_FILTRO4
  return

* === Ass_Pos
procedure Ass_Pos
  private i_wx, i_wy, i_ay
  activate window "gast_sel" noshow same
  i_wx = fontmetric(6)
  i_wy = fontmetric(1)
  i_ay = 0
  do case
    case _windows
      do Ass_Pos_Win
    case _mac
      do Ass_Pos_Mac
    otherwise
      do Ass_Pos_Unkn
  endcase
  return

procedure Ass_Pos_Win
      i_posyx1[2,1] = i_ay+(29/i_wy) && at_y(29)
      i_posyx1[2,2] = 14/i_wx && at_x(14)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(87/i_wx)
      i_posyx1[3,1] = i_ay+(26/i_wy) && at_y(26)
      i_posyx1[3,2] = 108/i_wx && at_x(108)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(87/i_wx)
      i_posyx1[4,1] = i_ay+(29/i_wy) && at_y(29)
      i_posyx1[4,2] = 202/i_wx && at_x(202)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(171/i_wx)
      i_posyx1[5,1] = i_ay+(26/i_wy) && at_y(26)
      i_posyx1[5,2] = 384/i_wx && at_x(384)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(52/i_wx)
      i_posyx1[6,1] = i_ay+(56/i_wy) && at_y(56)
      i_posyx1[6,2] = 14/i_wx && at_x(14)
      i_size1[6,1] = 1
      i_size1[6,2] = cp_intsz(87/i_wx)
      i_posyx1[7,1] = i_ay+(53/i_wy) && at_y(53)
      i_posyx1[7,2] = 108/i_wx && at_x(108)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(87/i_wx)
      i_posyx1[8,1] = i_ay+(56/i_wy) && at_y(56)
      i_posyx1[8,2] = 202/i_wx && at_x(202)
      i_size1[8,1] = 1
      i_size1[8,2] = cp_intsz(171/i_wx)
      i_posyx1[9,1] = i_ay+(53/i_wy) && at_y(53)
      i_posyx1[9,2] = 384/i_wx && at_x(384)
      i_size1[9,1] = 1
      i_size1[9,2] = cp_intsz(52/i_wx)
      i_posyx1[10,1] = i_ay+(83/i_wy) && at_y(83)
      i_posyx1[10,2] = 14/i_wx && at_x(14)
      i_size1[10,1] = 1
      i_size1[10,2] = cp_intsz(87/i_wx)
      i_posyx1[11,1] = i_ay+(80/i_wy) && at_y(80)
      i_posyx1[11,2] = 108/i_wx && at_x(108)
      i_size1[11,1] = 1
      i_size1[11,2] = cp_intsz(87/i_wx)
      i_posyx1[12,1] = i_ay+(83/i_wy) && at_y(83)
      i_posyx1[12,2] = 202/i_wx && at_x(202)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(171/i_wx)
      i_posyx1[13,1] = i_ay+(80/i_wy) && at_y(80)
      i_posyx1[13,2] = 384/i_wx && at_x(384)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(52/i_wx)
      i_posyx1[14,1] = i_ay+(110/i_wy) && at_y(110)
      i_posyx1[14,2] = 14/i_wx && at_x(14)
      i_size1[14,1] = 1
      i_size1[14,2] = cp_intsz(87/i_wx)
      i_posyx1[15,1] = i_ay+(107/i_wy) && at_y(107)
      i_posyx1[15,2] = 108/i_wx && at_x(108)
      i_size1[15,1] = 1
      i_size1[15,2] = cp_intsz(87/i_wx)
      i_posyx1[16,1] = i_ay+(110/i_wy) && at_y(110)
      i_posyx1[16,2] = 202/i_wx && at_x(202)
      i_size1[16,1] = 1
      i_size1[16,2] = cp_intsz(171/i_wx)
      i_posyx1[17,1] = i_ay+(107/i_wy) && at_y(107)
      i_posyx1[17,2] = 384/i_wx && at_x(384)
      i_size1[17,1] = 1
      i_size1[17,2] = cp_intsz(52/i_wx)
      i_posyx1[18,1] = i_ay+(137/i_wy) && at_y(137)
      i_posyx1[18,2] = 14/i_wx && at_x(14)
      i_size1[18,1] = 1
      i_size1[18,2] = cp_intsz(87/i_wx)
      i_posyx1[19,1] = i_ay+(134/i_wy) && at_y(134)
      i_posyx1[19,2] = 108/i_wx && at_x(108)
      i_size1[19,1] = 1
      i_size1[19,2] = cp_intsz(87/i_wx)
      i_posyx1[20,1] = i_ay+(137/i_wy) && at_y(137)
      i_posyx1[20,2] = 202/i_wx && at_x(202)
      i_size1[20,1] = 1
      i_size1[20,2] = cp_intsz(171/i_wx)
      i_posyx1[21,1] = i_ay+(134/i_wy) && at_y(134)
      i_posyx1[21,2] = 384/i_wx && at_x(384)
      i_size1[21,1] = at_y(23)
      i_size1[21,2] = cp_intsz(52/i_wx)
      i_posyx1[22,1] = i_ay+(184/i_wy) && at_y(184)
      i_posyx1[22,2] = 119/i_wx && at_x(119)
      i_posyx1[23,1] = i_ay+(205/i_wy) && at_y(205)
      i_posyx1[23,2] = 119/i_wx && at_x(119)
      i_posyx1[24,1] = i_ay+(246/i_wy) && at_y(246)
      i_posyx1[24,2] = 8/i_wx && at_x(8)
      i_size1[24,1] = cp_intsz(at_y(38))
      i_size1[24,2] = cp_intsz(428/i_wx)
      i_posyx1[25,1] = i_ay+(291/i_wy) && at_y(291)
      i_posyx1[25,2] = 310/i_wx && at_x(310)
      i_size1[25,1] = at_y(28)
      i_size1[25,2] = cp_intsz(61/i_wx)
      i_posyx1[26,1] = i_ay+(291/i_wy) && at_y(291)
      i_posyx1[26,2] = 376/i_wx && at_x(376)
      i_size1[26,1] = at_y(28)
      i_size1[26,2] = cp_intsz(61/i_wx)
      i_posyx1[28,1] = i_ay+(5/i_wy) && at_y(5)
      i_posyx1[28,2] = 8/i_wx && at_x(8)
      i_font1[28,1] = "Arial"
      i_font1[28,2] = 9
      i_style1[28]  = "B"
      i_posyx1[30,1] = i_ay+(164/i_wy) && at_y(164)
      i_posyx1[30,2] = 8/i_wx && at_x(8)
      i_font1[30,1] = "Arial"
      i_font1[30,2] = 9
      i_style1[30]  = "B"
      i_posyx1[31,1] = i_ay+(184/i_wy) && at_y(184)
      i_posyx1[31,2] = 8/i_wx && at_x(8)
      i_posyx1[32,1] = i_ay+(226/i_wy) && at_y(226)
      i_posyx1[32,2] = 8/i_wx && at_x(8)
      i_posyx1[33,1] = i_ay+(205/i_wy) && at_y(205)
      i_posyx1[33,2] = 15/i_wx && at_x(15)
      i_posyx1[37,1] = i_ay+(291/i_wy) && at_y(291)
      i_posyx1[37,2] = 8/i_wx && at_x(8)
      i_size1[37,1] = at_y(25)
      i_size1[37,2] = cp_intsz(33/i_wx)
      i_posyx1[38,1] = i_ay+(291/i_wy) && at_y(291)
      i_posyx1[38,2] = 45/i_wx && at_x(45)
      i_size1[38,1] = at_y(25)
      i_size1[38,2] = cp_intsz(51/i_wx)
  return
procedure Ass_Pos_Mac
      i_posyx1[2,1] = i_ay+at_y(29)
      i_posyx1[2,2] = at_x(14)
      i_size1[2,1] = 1
      i_size1[2,2] = cp_intsz(at_x(87))
      i_posyx1[3,1] = i_ay+at_y(26)
      i_posyx1[3,2] = at_x(108)
      i_size1[3,1] = 1
      i_size1[3,2] = cp_intsz(at_x(87))
      i_posyx1[4,1] = i_ay+at_y(29)
      i_posyx1[4,2] = at_x(202)
      i_size1[4,1] = 1
      i_size1[4,2] = cp_intsz(at_x(171))
      i_posyx1[5,1] = i_ay+at_y(26)
      i_posyx1[5,2] = at_x(384)
      i_size1[5,1] = 1
      i_size1[5,2] = cp_intsz(at_x(52))
      i_posyx1[6,1] = i_ay+at_y(56)
      i_posyx1[6,2] = at_x(14)
      i_size1[6,1] = 1
      i_size1[6,2] = cp_intsz(at_x(87))
      i_posyx1[7,1] = i_ay+at_y(53)
      i_posyx1[7,2] = at_x(108)
      i_size1[7,1] = 1
      i_size1[7,2] = cp_intsz(at_x(87))
      i_posyx1[8,1] = i_ay+at_y(56)
      i_posyx1[8,2] = at_x(202)
      i_size1[8,1] = 1
      i_size1[8,2] = cp_intsz(at_x(171))
      i_posyx1[9,1] = i_ay+at_y(53)
      i_posyx1[9,2] = at_x(384)
      i_size1[9,1] = 1
      i_size1[9,2] = cp_intsz(at_x(52))
      i_posyx1[10,1] = i_ay+at_y(83)
      i_posyx1[10,2] = at_x(14)
      i_size1[10,1] = 1
      i_size1[10,2] = cp_intsz(at_x(87))
      i_posyx1[11,1] = i_ay+at_y(80)
      i_posyx1[11,2] = at_x(108)
      i_size1[11,1] = 1
      i_size1[11,2] = cp_intsz(at_x(87))
      i_posyx1[12,1] = i_ay+at_y(83)
      i_posyx1[12,2] = at_x(202)
      i_size1[12,1] = 1
      i_size1[12,2] = cp_intsz(at_x(171))
      i_posyx1[13,1] = i_ay+at_y(80)
      i_posyx1[13,2] = at_x(384)
      i_size1[13,1] = 1
      i_size1[13,2] = cp_intsz(at_x(52))
      i_posyx1[14,1] = i_ay+at_y(110)
      i_posyx1[14,2] = at_x(14)
      i_size1[14,1] = 1
      i_size1[14,2] = cp_intsz(at_x(87))
      i_posyx1[15,1] = i_ay+at_y(107)
      i_posyx1[15,2] = at_x(108)
      i_size1[15,1] = 1
      i_size1[15,2] = cp_intsz(at_x(87))
      i_posyx1[16,1] = i_ay+at_y(110)
      i_posyx1[16,2] = at_x(202)
      i_size1[16,1] = 1
      i_size1[16,2] = cp_intsz(at_x(171))
      i_posyx1[17,1] = i_ay+at_y(107)
      i_posyx1[17,2] = at_x(384)
      i_size1[17,1] = 1
      i_size1[17,2] = cp_intsz(at_x(52))
      i_posyx1[18,1] = i_ay+at_y(137)
      i_posyx1[18,2] = at_x(14)
      i_size1[18,1] = 1
      i_size1[18,2] = cp_intsz(at_x(87))
      i_posyx1[19,1] = i_ay+at_y(134)
      i_posyx1[19,2] = at_x(108)
      i_size1[19,1] = 1
      i_size1[19,2] = cp_intsz(at_x(87))
      i_posyx1[20,1] = i_ay+at_y(137)
      i_posyx1[20,2] = at_x(202)
      i_size1[20,1] = 1
      i_size1[20,2] = cp_intsz(at_x(171))
      i_posyx1[21,1] = i_ay+at_y(134)
      i_posyx1[21,2] = at_x(384)
      i_size1[21,1] = at_y(23)
      i_size1[21,2] = cp_intsz(at_x(52))
      i_posyx1[22,1] = i_ay+at_y(184)
      i_posyx1[22,2] = at_x(119)
      i_posyx1[23,1] = i_ay+at_y(205)
      i_posyx1[23,2] = at_x(119)
      i_posyx1[24,1] = i_ay+at_y(246)
      i_posyx1[24,2] = at_x(8)
      i_size1[24,1] = cp_intsz(at_y(38))
      i_size1[24,2] = cp_intsz(at_x(428))
      i_posyx1[25,1] = i_ay+at_y(291)
      i_posyx1[25,2] = at_x(310)
      i_size1[25,1] = at_y(28)
      i_size1[25,2] = cp_intsz(at_x(61))
      i_posyx1[26,1] = i_ay+at_y(291)
      i_posyx1[26,2] = at_x(376)
      i_size1[26,1] = at_y(28)
      i_size1[26,2] = cp_intsz(at_x(61))
      i_posyx1[28,1] = i_ay+at_y(5)
      i_posyx1[28,2] = at_x(8)
      i_font1[28,1] = "Arial"
      i_font1[28,2] = 9*4/3
      i_style1[28]  = "B"
      i_posyx1[30,1] = i_ay+at_y(164)
      i_posyx1[30,2] = at_x(8)
      i_font1[30,1] = "Arial"
      i_font1[30,2] = 9*4/3
      i_style1[30]  = "B"
      i_posyx1[31,1] = i_ay+at_y(184)
      i_posyx1[31,2] = at_x(8)
      i_posyx1[32,1] = i_ay+at_y(226)
      i_posyx1[32,2] = at_x(8)
      i_posyx1[33,1] = i_ay+at_y(205)
      i_posyx1[33,2] = at_x(15)
      i_posyx1[37,1] = i_ay+at_y(291)
      i_posyx1[37,2] = at_x(8)
      i_size1[37,1] = at_y(25)
      i_size1[37,2] = cp_intsz(at_x(33))
      i_posyx1[38,1] = i_ay+at_y(291)
      i_posyx1[38,2] = at_x(45)
      i_size1[38,1] = at_y(25)
      i_size1[38,2] = cp_intsz(at_x(51))
  return
procedure Ass_Pos_Unkn
      i_posyx1[2,1] = 2
      i_posyx1[2,2] = 0
      i_size1[2,1]  = 1
      i_size1[2,2]  = 12
      i_posyx1[3,1] = 1
      i_posyx1[3,2] = 12
      i_size1[3,1]  = 1
      i_size1[3,2]  = 12
      i_posyx1[4,1] = 2
      i_posyx1[4,2] = 24
      i_size1[4,1]  = 1
      i_size1[4,2]  = 24
      i_posyx1[5,1] = 1
      i_posyx1[5,2] = 47
      i_size1[5,1]  = 1
      i_size1[5,2]  = 7
      i_posyx1[6,1] = 3
      i_posyx1[6,2] = 0
      i_size1[6,1]  = 1
      i_size1[6,2]  = 12
      i_posyx1[7,1] = 3
      i_posyx1[7,2] = 12
      i_size1[7,1]  = 1
      i_size1[7,2]  = 12
      i_posyx1[8,1] = 3
      i_posyx1[8,2] = 24
      i_size1[8,1]  = 1
      i_size1[8,2]  = 24
      i_posyx1[9,1] = 3
      i_posyx1[9,2] = 47
      i_size1[9,1]  = 1
      i_size1[9,2]  = 7
      i_posyx1[10,1] = 4
      i_posyx1[10,2] = 0
      i_size1[10,1]  = 1
      i_size1[10,2]  = 12
      i_posyx1[11,1] = 4
      i_posyx1[11,2] = 12
      i_size1[11,1]  = 1
      i_size1[11,2]  = 12
      i_posyx1[12,1] = 4
      i_posyx1[12,2] = 24
      i_size1[12,1]  = 1
      i_size1[12,2]  = 24
      i_posyx1[13,1] = 4
      i_posyx1[13,2] = 47
      i_size1[13,1]  = 1
      i_size1[13,2]  = 7
      i_posyx1[14,1] = 6
      i_posyx1[14,2] = 0
      i_size1[14,1]  = 1
      i_size1[14,2]  = 12
      i_posyx1[15,1] = 6
      i_posyx1[15,2] = 12
      i_size1[15,1]  = 1
      i_size1[15,2]  = 12
      i_posyx1[16,1] = 6
      i_posyx1[16,2] = 24
      i_size1[16,1]  = 1
      i_size1[16,2]  = 24
      i_posyx1[17,1] = 6
      i_posyx1[17,2] = 47
      i_size1[17,1]  = 1
      i_size1[17,2]  = 7
      i_posyx1[18,1] = 7
      i_posyx1[18,2] = 0
      i_size1[18,1]  = 1
      i_size1[18,2]  = 12
      i_posyx1[19,1] = 7
      i_posyx1[19,2] = 12
      i_size1[19,1]  = 1
      i_size1[19,2]  = 12
      i_posyx1[20,1] = 7
      i_posyx1[20,2] = 24
      i_size1[20,1]  = 1
      i_size1[20,2]  = 24
      i_posyx1[21,1] = 7
      i_posyx1[21,2] = 47
      i_size1[21,1]  = 1
      i_size1[21,2]  = 12
      i_posyx1[22,1] = 10
      i_posyx1[22,2] = 14
      i_posyx1[23,1] = 11
      i_posyx1[23,2] = 14
      i_posyx1[24,1] = 13
      i_posyx1[24,2] = 0
      i_size1[24,1]  = 3
      i_size1[24,2]  = 54
      i_posyx1[25,1] = 15
      i_posyx1[25,2] = 37
      i_size1[25,1]  = 1
      i_size1[25,2]  = 6
      i_posyx1[26,1] = 15
      i_posyx1[26,2] = 46
      i_size1[26,1]  = 1
      i_size1[26,2]  = 10
      i_posyx1[28,1] = 0
      i_posyx1[28,2] = 0
      i_font1[28,1] = ""
      i_font1[28,2] = 0
      i_style1[28]  = ""
      i_posyx1[30,1] = 9
      i_posyx1[30,2] = 0
      i_font1[30,1] = ""
      i_font1[30,2] = 0
      i_style1[30]  = ""
      i_posyx1[31,1] = 10
      i_posyx1[31,2] = 0
      i_posyx1[32,1] = 12
      i_posyx1[32,2] = 0
      i_posyx1[33,1] = 11
      i_posyx1[33,2] = 1
      i_posyx1[37,1] = -1
      i_posyx1[37,2] = -2
      i_size1[37,1]  = 1
      i_size1[37,2]  = 7
      i_posyx1[38,1] = -1
      i_posyx1[38,2] = -2
      i_size1[38,1]  = 1
      i_size1[38,2]  = 11
return

function cp_intsz
  param i_sz
  return(iif(i_sz>=5,int(i_sz),i_sz))

* === F_Paint
procedure F_Paint
  parameters i_tutto
  private i_ay
  i_ay = 0
  activate window "gast_sel" noshow same
  * --- Area Manuale = Paint Init
  * --- Fine Area Manuale
  if i_tutto=0
    clear
  endif
  do case
    case i_pag=1
      * --- Visualizzazione delle descrizioni
      if i_tutto=0
        @ iif(i_vidgrf,at_y(13)+i_ay,1),iif(i_vidgrf,at_x(4),-1) to;
        iif(i_vidgrf,at_y(13)+i_ay,1),iif(i_vidgrf,at_x(439),54);


        @ i_posyx1(28,1),i_posyx1(28,2) say "Condizione di selezione:";
          font i_font1(28,1), i_font1(28,2) style i_style1(28);

        @ iif(i_vidgrf,at_y(172)+i_ay,9),iif(i_vidgrf,at_x(4),-1) to;
        iif(i_vidgrf,at_y(172)+i_ay,9),iif(i_vidgrf,at_x(439),54);


        @ i_posyx1(30,1),i_posyx1(30,2) say "Opzioni di stampa:";
          font i_font1(30,1), i_font1(30,2) style i_style1(30);

        @ i_posyx1(31,1),i_posyx1(31,2) say "Indirizzo da stamp.:";

        @ i_posyx1(32,1),i_posyx1(32,2) say "Intestazione Stampa:";

        @ i_posyx1(33,1),i_posyx1(33,2) say "Ordine di Stampa:";

       if i_vidgrf
         if i_3d
           do cplu_3d with i_posyx1(2,1),i_posyx1(2,2),i_size1[2,1],i_size1[2,2]
           do cplu_3d with i_posyx1(4,1),i_posyx1(4,2),i_size1[4,1],i_size1[4,2]
           do cplu_3d with i_posyx1(6,1),i_posyx1(6,2),i_size1[6,1],i_size1[6,2]
           do cplu_3d with i_posyx1(8,1),i_posyx1(8,2),i_size1[8,1],i_size1[8,2]
           do cplu_3d with i_posyx1(10,1),i_posyx1(10,2),i_size1[10,1],i_size1[10,2]
           do cplu_3d with i_posyx1(12,1),i_posyx1(12,2),i_size1[12,1],i_size1[12,2]
           do cplu_3d with i_posyx1(14,1),i_posyx1(14,2),i_size1[14,1],i_size1[14,2]
           do cplu_3d with i_posyx1(16,1),i_posyx1(16,2),i_size1[16,1],i_size1[16,2]
           do cplu_3d with i_posyx1(18,1),i_posyx1(18,2),i_size1[18,1],i_size1[18,2]
           do cplu_3d with i_posyx1(20,1),i_posyx1(20,2),i_size1[20,1],i_size1[20,2]
           do cplu_3d with i_posyx1(24,1),i_posyx1(24,2),i_size1[24,1],i_size1[24,2]
         endif
       else
       endif
        @ i_posyx1(21,1),i_posyx1(21,2) get i_button picture '@* Verifica';
          size i_size1[21,1],i_size1[21,2] disable;

        if i_vidgrf
        @ i_posyx1(25,1),i_posyx1(25,2) get i_button picture '@*B T_OK.BMP';
          size i_size1[25,1],i_size1[25,2] disable;

        else
        @ i_posyx1(25,1),i_posyx1(25,2) get i_button picture '@* OK';
          size i_size1[25,1],i_size1[25,2] disable;

        endif
        if i_vidgrf
        @ i_posyx1(26,1),i_posyx1(26,2) get i_button picture '@*B T_CANCEL.BMP';
          size i_size1[26,1],i_size1[26,2] disable;

        else
        @ i_posyx1(26,1),i_posyx1(26,2) get i_button picture '@* CANCEL';
          size i_size1[26,1],i_size1[26,2] disable;

        endif
        @ i_posyx1(37,1),i_posyx1(37,2) get i_button picture '@* SQL';
          size i_size1[37,1],i_size1[37,2] disable;

        @ i_posyx1(38,1),i_posyx1(38,2) get i_button picture '@* Pulisci';
          size i_size1[38,1],i_size1[38,2] disable;

        clear gets
      endif
      @ i_posyx1(2,1),i_posyx1(2,2) say w_FIELD1 picture "!!!!!!!!!!";
        size i_size1[2,1],i_size1[2,2];
        color (w_t_col004)
      @ i_posyx1(3,1),i_posyx1(3,2) get r_OPERA1 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[3,1],i_size1[3,2];

      @ i_posyx1(4,1),i_posyx1(4,2) say w_CONFR1 picture repl("X",20);
        size i_size1[4,1],i_size1[4,2];
        color (w_t_col004)
      @ i_posyx1(5,1),i_posyx1(5,2) get r_CONG1 function "^  ;E;O";
        size i_size1[5,1],i_size1[5,2];

      @ i_posyx1(6,1),i_posyx1(6,2) say w_FIELD2 picture "!!!!!!!!!!";
        size i_size1[6,1],i_size1[6,2];
        color (w_t_col004)
      @ i_posyx1(7,1),i_posyx1(7,2) get r_OPERA2 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[7,1],i_size1[7,2];

      @ i_posyx1(8,1),i_posyx1(8,2) say w_CONFR2 picture repl("X",20);
        size i_size1[8,1],i_size1[8,2];
        color (w_t_col004)
      @ i_posyx1(9,1),i_posyx1(9,2) get r_CONG2 function "^  ;E;O";
        size i_size1[9,1],i_size1[9,2];

      @ i_posyx1(10,1),i_posyx1(10,2) say w_FIELD3 picture "!!!!!!!!!!";
        size i_size1[10,1],i_size1[10,2];
        color (w_t_col004)
      @ i_posyx1(11,1),i_posyx1(11,2) get r_OPERA3 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[11,1],i_size1[11,2];

      @ i_posyx1(12,1),i_posyx1(12,2) say w_CONFR3 picture repl("X",20);
        size i_size1[12,1],i_size1[12,2];
        color (w_t_col004)
      @ i_posyx1(13,1),i_posyx1(13,2) get r_CONG3 function "^  ;E;O";
        size i_size1[13,1],i_size1[13,2];

      @ i_posyx1(14,1),i_posyx1(14,2) say w_FIELD4 picture "!!!!!!!!!!";
        size i_size1[14,1],i_size1[14,2];
        color (w_t_col004)
      @ i_posyx1(15,1),i_posyx1(15,2) get r_OPERA4 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[15,1],i_size1[15,2];

      @ i_posyx1(16,1),i_posyx1(16,2) say w_CONFR4 picture repl("X",20);
        size i_size1[16,1],i_size1[16,2];
        color (w_t_col004)
      @ i_posyx1(17,1),i_posyx1(17,2) get r_CONG4 function "^  ;E;O";
        size i_size1[17,1],i_size1[17,2];

      @ i_posyx1(18,1),i_posyx1(18,2) say w_FIELD5 picture "!!!!!!!!!!";
        size i_size1[18,1],i_size1[18,2];
        color (w_t_col004)
      @ i_posyx1(19,1),i_posyx1(19,2) get r_OPERA5 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[19,1],i_size1[19,2];

      @ i_posyx1(20,1),i_posyx1(20,2) say w_CONFR5 picture repl("X",20);
        size i_size1[20,1],i_size1[20,2];
        color (w_t_col004)
      @ i_posyx1(22,1),i_posyx1(22,2) get r_INDSTA function "*RH Residenza;Domicilio Profess.;Corrispondenza";
        color ,,,,,,,,&w_t_col005;

      @ i_posyx1(23,1),i_posyx1(23,2) get r_ORDINE function "*RH Codice;Cognome e Nome;Cap";
        color ,,,,,,,,&w_t_col005;

      @ i_posyx1(24,1),i_posyx1(24,2) edit w_INTSTA;
        size i_size1[24,1],i_size1[24,2] disable scroll;
        color (w_t_col004)
      clear gets
  endcase
  activate window "gast_sel" same
  * --- Area Manuale = Paint End
  * --- Fine Area Manuale
  return

* === F_Replace
function F_Replace
  * --- Area Manuale = Func Replace Init
  * --- Fine Area Manuale
  * --- Area Manuale = Func Replace End
  * --- Fine Area Manuale
  return

* === F_Blank
function F_Blank
  * --- Area Manuale = Func Blank Init
  * --- Fine Area Manuale
  w_FILTRO1 = space(10)
  w_FIELD1 = space(9)
  w_OPERA1 = space(2)
  w_CONFR1 = space(20)
  w_CONG1 = space(5)
  w_FIELD2 = space(9)
  w_OPERA2 = space(2)
  w_CONFR2 = space(20)
  w_CONG2 = space(5)
  w_FIELD3 = space(9)
  w_OPERA3 = space(2)
  w_CONFR3 = space(20)
  w_CONG3 = space(5)
  w_FIELD4 = space(9)
  w_OPERA4 = space(2)
  w_CONFR4 = space(20)
  w_CONG4 = space(5)
  w_FIELD5 = space(9)
  w_OPERA5 = space(2)
  w_CONFR5 = space(20)
  w_INDSTA = space(1)
  w_ORDINE = space(1)
  w_INTSTA = space(0)
  w_FILTRO2 = space(10)
  w_FILTRO3 = space(10)
  w_FILTRO4 = space(10)
  w_FILTRO1 = ".T."
  w_OPERA1 = "="
  w_CONG1 = ""
  w_CONG2 = ""
  w_CONG3 = ""
  w_CONG4 = ""
  w_INDSTA = 'R'
  w_ORDINE = 'C'
  w_FILTRO2 = ".T."
  w_FILTRO3 = ".T."
  w_FILTRO4 = ".T."
  * --- Area Manuale = Func Blank End
  * --- Fine Area Manuale
  do Set_Radio
  return

function F_Edit
  private i_esci, i_upda
  i_upda = .f.
  i_help = "gast_sel edit"
  if i_vidgrf
    if i_op=OP_EDITMOD
      modify window "gast_sel" title "STAMPA CON SELEZIONE LIBERA / Varia"
    endif
  endif
  * --- Area Manuale = Func Edit Init
  * --- Fine Area Manuale
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.SetEdit()
    i_shx = 1/fontmetric(6)
    i_shsz = -3/fontmetric(6)
  #endif
  * ---
  do while i_op=OP_EDITMOD .or. i_op=OP_EDITLOAD
    i_function = ""
    i_zoomprg  = ""
    if i_zbrow
      i_function = "Zoom"
    else
      activate window "gast_sel"
      * --- FP3
      #if .not. (left(version(),13)="Visual FoxPro")
        do cplu_bar with i_op, .f.
      #endif
      * ---
      do case
        case i_pag=1
      @ i_posyx1[2,1],i_posyx1[2,2]+i_shx get w_FIELD1 picture "!!!!!!!!!!";
        size i_size1[2,1],i_size1[2,2]+i_shsz;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_FIELD1",;
                space(9)) .and.;
              F_Calc(.f.)
      @ i_posyx1(3,1),i_posyx1(3,2) get r_OPERA1 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[3,1],i_size1[3,2];
            when;
              (!empty(w_FIELD1)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_OPERA1",;
                space(2)) .and.;
              F_Calc(.f.)
      @ i_posyx1[4,1],i_posyx1[4,2]+i_shx get w_CONFR1 picture repl("X",20);
        size i_size1[4,1],i_size1[4,2]+i_shsz;
            when;
              (!empty(w_FIELD1)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONFR1",;
                space(20)) .and.;
              F_Calc(.f.)
      @ i_posyx1(5,1),i_posyx1(5,2) get r_CONG1 function "^  ;E;O";
        size i_size1[5,1],i_size1[5,2];
            when;
              (!empty(w_FIELD1)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONG1",;
                space(5)) .and.;
              F_Calc(.f.)
      @ i_posyx1[6,1],i_posyx1[6,2]+i_shx get w_FIELD2 picture "!!!!!!!!!!";
        size i_size1[6,1],i_size1[6,2]+i_shsz;
            when;
              (!empty(w_FIELD1)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_FIELD2",;
                space(9)) .and.;
              F_Calc(.f.)
      @ i_posyx1(7,1),i_posyx1(7,2) get r_OPERA2 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[7,1],i_size1[7,2];
            when;
              (!empty(w_FIELD2)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_OPERA2",;
                space(2)) .and.;
              F_Calc(.f.)
      @ i_posyx1[8,1],i_posyx1[8,2]+i_shx get w_CONFR2 picture repl("X",20);
        size i_size1[8,1],i_size1[8,2]+i_shsz;
            when;
              (!empty(w_FIELD2)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONFR2",;
                space(20)) .and.;
              F_Calc(.f.)
      @ i_posyx1(9,1),i_posyx1(9,2) get r_CONG2 function "^  ;E;O";
        size i_size1[9,1],i_size1[9,2];
            when;
              (!empty(w_FIELD2)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONG2",;
                space(5)) .and.;
              F_Calc(.f.)
      @ i_posyx1[10,1],i_posyx1[10,2]+i_shx get w_FIELD3 picture "!!!!!!!!!!";
        size i_size1[10,1],i_size1[10,2]+i_shsz;
            when;
              (!empty(w_FIELD2)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_FIELD3",;
                space(9)) .and.;
              F_Calc(.f.)
      @ i_posyx1(11,1),i_posyx1(11,2) get r_OPERA3 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[11,1],i_size1[11,2];
            when;
              (!empty(w_FIELD3)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_OPERA3",;
                space(2)) .and.;
              F_Calc(.f.)
      @ i_posyx1[12,1],i_posyx1[12,2]+i_shx get w_CONFR3 picture repl("X",20);
        size i_size1[12,1],i_size1[12,2]+i_shsz;
            when;
              (!empty(w_FIELD3)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONFR3",;
                space(20)) .and.;
              F_Calc(.f.)
      @ i_posyx1(13,1),i_posyx1(13,2) get r_CONG3 function "^  ;E;O";
        size i_size1[13,1],i_size1[13,2];
            when;
              (!empty(w_FIELD3)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONG3",;
                space(5)) .and.;
              F_Calc(.f.)
      @ i_posyx1[14,1],i_posyx1[14,2]+i_shx get w_FIELD4 picture "!!!!!!!!!!";
        size i_size1[14,1],i_size1[14,2]+i_shsz;
            when;
              (!empty(w_FIELD3)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_FIELD4",;
                space(9)) .and.;
              F_Calc(.f.)
      @ i_posyx1(15,1),i_posyx1(15,2) get r_OPERA4 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[15,1],i_size1[15,2];
            when;
              (!empty(w_FIELD4)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_OPERA4",;
                space(2)) .and.;
              F_Calc(.f.)
      @ i_posyx1[16,1],i_posyx1[16,2]+i_shx get w_CONFR4 picture repl("X",20);
        size i_size1[16,1],i_size1[16,2]+i_shsz;
            when;
              (!empty(w_FIELD4)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONFR4",;
                space(20)) .and.;
              F_Calc(.f.)
      @ i_posyx1(17,1),i_posyx1(17,2) get r_CONG4 function "^  ;E;O";
        size i_size1[17,1],i_size1[17,2];
            when;
              (!empty(w_FIELD4)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONG4",;
                space(5)) .and.;
              F_Calc(.f.)
      @ i_posyx1[18,1],i_posyx1[18,2]+i_shx get w_FIELD5 picture "!!!!!!!!!!";
        size i_size1[18,1],i_size1[18,2]+i_shsz;
            when;
              (!empty(w_FIELD4)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_FIELD5",;
                space(9)) .and.;
              F_Calc(.f.)
      @ i_posyx1(19,1),i_posyx1(19,2) get r_OPERA5 function "^ =;>;<;>=;<=;<>;Contiene;Lista;E' vuoto;Non � vuoto";
        size i_size1[19,1],i_size1[19,2];
            when;
              (!empty(w_FIELD5)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_OPERA5",;
                space(2)) .and.;
              F_Calc(.f.)
      @ i_posyx1[20,1],i_posyx1[20,2]+i_shx get w_CONFR5 picture repl("X",20);
        size i_size1[20,1],i_size1[20,2]+i_shsz;
            when;
              (!empty(w_FIELD5)) .and.;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_CONFR5",;
                space(20)) .and.;
              F_Calc(.f.)
            @ i_posyx1[21,1],i_posyx1[21,2] get i_button picture '@* Verifica';
              size i_size1[21,1],i_size1[21,2];
              when !empty(w_FIELD1) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      @ i_posyx1(22,1),i_posyx1(22,2) get r_INDSTA function "*RH Residenza;Domicilio Profess.;Corrispondenza";
        color ,,,,,,,,&w_t_col005;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_INDSTA",;
                space(1)) .and.;
              F_Calc(.f.)
      @ i_posyx1(23,1),i_posyx1(23,2) get r_ORDINE function "*RH Codice;Cognome e Nome;Cap";
        color ,,,,,,,,&w_t_col005;
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              Get_Radio() .and.;
              F_Check(;
                .t.,;
                .f.,;
                "w_ORDINE",;
                space(1)) .and.;
              F_Calc(.f.)
      @ i_posyx1[24,1],i_posyx1[24,2] edit w_INTSTA;
        size i_size1[24,1],i_size1[24,2] scroll;
       color (w_t_col004);
            when;
              iif(empty(i_function),;
                F_dep(.f.,.f.);
              ,.t.);
            valid;
              F_Check(;
                .t.,;
                .f.,;
                "w_INTSTA",;
                space(0)) .and.;
              F_Calc(.f.)
            @ i_posyx1[25,1],i_posyx1[25,2] get i_button picture iif(i_vidgrf,'@*B T_OK.BMP','@* OK');
              size i_size1[25,1],i_size1[25,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Save");

            @ i_posyx1[26,1],i_posyx1[26,2] get i_button picture iif(i_vidgrf,'@*B T_CANCEL.BMP','@* CANCEL');
              size i_size1[26,1],i_size1[26,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_fcs("Quit");

            @ i_posyx1[37,1],i_posyx1[37,2] get i_button picture '@* SQL';
              size i_size1[37,1],i_size1[37,2];
              when !empty(w_FIELD1) .and. ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

            @ i_posyx1[38,1],i_posyx1[38,2] get i_button picture '@* Pulisci';
              size i_size1[38,1],i_size1[38,2];
              when ;
              iif(empty(i_function),F_dep(.f.,.f.),.t.);
              valid cplu_cpc("");

      endcase
      _screen.ActiveForm.lockscreen=.t.
      _screen.ActiveForm.lockscreen=.f.
      read object i_campo deactivate cplu_kwf("gast_sel")
      * --- Area Manuale = Func Edit Chkread2
      * --- Fine Area Manuale
    endif
    do case
      * --- Area Manuale = Func Edit Funckeys
      * --- Fine Area Manuale
      case .not. empty(i_todo)
        i_oldop = i_op
        i_op = OP_INTR
        do Get_Radio
        clear read
      case i_function="Repaint"
        do F_Paint with 0
      case i_function="Btn"
        i_oldop = i_op
        i_op = OP_ZOOM
      case i_function="Save"
        i_esci = .f.
        do case
          * --- Area Manuale = Func Edit Confirm
          * --- Fine Area Manuale
          * --- Controllo dei campi obbligatori nelle righe del corpo
          case F_ChkAutoLock()
            i_esci = .t.
            * --- Area Manuale = Func Edit Save
            * --- Fine Area Manuale
        endcase
        if i_esci
          do F_Replace
          * --- Event = Mask Confirmed
          * --- End Event
          * --- Area Manuale = Print Init
          * --- gast_sel
          if !empty(w_FIELD1)
             do CPLU_MES with "Elaborazione in corso . . . Attendere!"
             *
             w_FILTRO1 = DecoSQL(w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1)
             w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2)
             w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD3,w_OPERA3,w_CONFR3,w_CONG3)
             w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD4,w_OPERA4,w_CONFR4,w_CONG4)
             w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD5,w_OPERA5,w_CONFR5,"")
             w_FILTRO2 = ".T."
             w_FILTRO3 = ".T."
             w_FILTRO4 = ".T."
             * Creo cursore temporaneo
             do case
             case w_ORDINE="R"
                do CPI_QRY with "QUERY\GAST3SR1.VQR","__TMP__"
             case w_ORDINE="P"
                do CPI_QRY with "QUERY\GAST3SR2.VQR","__TMP__"
             case w_ORDINE="C"
                do CPI_QRY with "QUERY\GAST3SR3.VQR","__TMP__"
             endcase
             *
             if _TALLY>0
                private i_bFox26
                i_bFox26=.t.
                i_cBmpPath=''
                i_cStdIcon='prog.ico'
                *
                do cp_chprn with "QUERY\GAST3SER.FRX"
             else
                do CPLU_ERM with "Non esistono dati per la selezione effettuata !"
             endif
             *
             if used("__TMP__")
                select __TMP__
                use
             endif
          else
             do CPLU_ERM with "Specificare le condizioni di selezione !!!",48
          endif
          * --- Fine Area Manuale
          * --- Area Manuale = Print End
          * --- gast_sel
          LOOP
          * --- Fine Area Manuale
  i_op = OP_QUIT
else
  do F_Paint with 0
endif
      case i_function="Prior" .or. i_function="Next"
      case i_function="Delete"
      case i_function="Zoom"
        i_oldop = i_op
        i_op = OP_ZOOM
        do case
          case i_pag=1
            do case
              case i_campo=20+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do VerificaSQL'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=30+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do StampaSQL'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
              case i_campo=31+i_nbtntbar
                if .not. i_zbrow
                  i_zoomprg = 'do SvuotaFiltri'
                  i_zbrow = .t.
                else
                  i_zbrow = .f.
                  i_op = i_oldop
                endif
            endcase
        endcase
        if .not. i_zbrow
          do F_Calc with .t.
          i_op = i_oldop
        endif
      case i_function="Quit" .or. ((readkey()=12 .or. readkey()=268) .and. readkey(1)=1)
i_op = OP_QUIT
        * --- Event = Mask Rejected
        * --- End Event
    endcase
  enddo
  * --- Area Manuale = Func Edit End
  * --- Fine Area Manuale
  return

function F_dep
  parameter i_skip,i_zoom
  if _curobj>i_nbtntbar
    i_campo = _curobj
  endif
  i_accpt = .t.
  if .not. chrsaw()
    * --- FP3
    #if .not. (left(version(),13)="Visual FoxPro")
      show object 4 disable
      if i_skip
        show object 6 enable
        show object 7 enable
      else
        show object 6 disable
        show object 7 disable
      endif
      if i_zoom
        show object 8 enable
      else
        show object 8 disable
      endif
      if i_pag<>1
        show object 9 enable
      else
        show object 9 disable
      endif
      if i_pag<>1
        show object 10 enable
      else
        show object 10 disable
      endif
    #else
      * --- Parte per FoxPro3
      if i_skip
        oCPToolBar.b7.enabled = .t.
        oCPToolBar.b8.enabled = .t.
      else
        oCPToolBar.b7.enabled = .f.
        oCPToolBar.b8.enabled = .f.
      endif
      if i_zoom
        oCPToolBar.b9.enabled = .t.
      else
        oCPToolBar.b9.enabled = .f.
      endif
    #endif
    * ---
  endif
  * --- Area Manuale = Function Dep
  * --- Fine Area Manuale
  return .t.

function F_calc
  parameter i_upd
  * --- Area Manuale = Func Edit Calc Alws
  * --- gast_sel
  if empty(w_FIELD1)
     w_OPERA1 = ""
     w_CONFR1 = ""
     w_CONG1 = ""
  endif
  if empty(w_FIELD2)
     w_OPERA2 = ""
     w_CONFR2 = ""
     w_CONG2 = ""
  endif
  if empty(w_FIELD3)
     w_OPERA3 = ""
     w_CONFR3 = ""
     w_CONG3 = ""
  endif
  if empty(w_FIELD4)
     w_OPERA4 = ""
     w_CONFR4 = ""
     w_CONG4 = ""
  endif
  if empty(w_FIELD5)
     w_OPERA5 = ""
     w_CONFR5 = ""
  endif
  * --- Fine Area Manuale
  if updated() .or. i_upd .or. i_upda
    * --- Area Manuale = Func Edit Calc
    * --- Fine Area Manuale
    do Set_Radio
    show gets
  endif
  i_upda = .f.
  return .t.

function Set_Radio
  w_OPERA1=trim(w_OPERA1)
  r_OPERA1 = ;
    iif(w_OPERA1=="=",1,;
    iif(w_OPERA1==">",2,;
    iif(w_OPERA1=="<",3,;
    iif(w_OPERA1==">=",4,;
    iif(w_OPERA1=="<=",5,;
    iif(w_OPERA1=="#",6,;
    iif(w_OPERA1=="LI",7,;
    iif(w_OPERA1=="IN",8,;
    iif(w_OPERA1=="EM",9,;
    iif(w_OPERA1=="!E",10,;
    0))))))))))
  w_CONG1=trim(w_CONG1)
  r_CONG1 = ;
    iif(w_CONG1=="",1,;
    iif(w_CONG1==".AND.",2,;
    iif(w_CONG1==".OR.",3,;
    0)))
  w_OPERA2=trim(w_OPERA2)
  r_OPERA2 = ;
    iif(w_OPERA2=="=",1,;
    iif(w_OPERA2==">",2,;
    iif(w_OPERA2=="<",3,;
    iif(w_OPERA2==">=",4,;
    iif(w_OPERA2=="<=",5,;
    iif(w_OPERA2=="#",6,;
    iif(w_OPERA2=="LI",7,;
    iif(w_OPERA2=="IN",8,;
    iif(w_OPERA2=="EM",9,;
    iif(w_OPERA2=="!E",10,;
    0))))))))))
  w_CONG2=trim(w_CONG2)
  r_CONG2 = ;
    iif(w_CONG2=="",1,;
    iif(w_CONG2==".AND.",2,;
    iif(w_CONG2==".OR.",3,;
    0)))
  w_OPERA3=trim(w_OPERA3)
  r_OPERA3 = ;
    iif(w_OPERA3=="=",1,;
    iif(w_OPERA3==">",2,;
    iif(w_OPERA3=="<",3,;
    iif(w_OPERA3==">=",4,;
    iif(w_OPERA3=="<=",5,;
    iif(w_OPERA3=="#",6,;
    iif(w_OPERA3=="LI",7,;
    iif(w_OPERA3=="IN",8,;
    iif(w_OPERA3=="EM",9,;
    iif(w_OPERA3=="!E",10,;
    0))))))))))
  w_CONG3=trim(w_CONG3)
  r_CONG3 = ;
    iif(w_CONG3=="",1,;
    iif(w_CONG3==".AND.",2,;
    iif(w_CONG3==".OR.",3,;
    0)))
  w_OPERA4=trim(w_OPERA4)
  r_OPERA4 = ;
    iif(w_OPERA4=="=",1,;
    iif(w_OPERA4==">",2,;
    iif(w_OPERA4=="<",3,;
    iif(w_OPERA4==">=",4,;
    iif(w_OPERA4=="<=",5,;
    iif(w_OPERA4=="#",6,;
    iif(w_OPERA4=="LI",7,;
    iif(w_OPERA4=="IN",8,;
    iif(w_OPERA4=="EM",9,;
    iif(w_OPERA4=="!E",10,;
    0))))))))))
  w_CONG4=trim(w_CONG4)
  r_CONG4 = ;
    iif(w_CONG4=="",1,;
    iif(w_CONG4==".AND.",2,;
    iif(w_CONG4==".OR.",3,;
    0)))
  w_OPERA5=trim(w_OPERA5)
  r_OPERA5 = ;
    iif(w_OPERA5=="=",1,;
    iif(w_OPERA5==">",2,;
    iif(w_OPERA5=="<",3,;
    iif(w_OPERA5==">=",4,;
    iif(w_OPERA5=="<=",5,;
    iif(w_OPERA5=="#",6,;
    iif(w_OPERA5=="LI",7,;
    iif(w_OPERA5=="IN",8,;
    iif(w_OPERA5=="EM",9,;
    iif(w_OPERA5=="!E",10,;
    0))))))))))
  w_INDSTA=trim(w_INDSTA)
  r_INDSTA = ;
    iif(w_INDSTA=='R',1,;
    iif(w_INDSTA=='D',2,;
    iif(w_INDSTA=='C',3,;
    0)))
  w_ORDINE=trim(w_ORDINE)
  r_ORDINE = ;
    iif(w_ORDINE=='C',1,;
    iif(w_ORDINE=='R',2,;
    iif(w_ORDINE=='P',3,;
    0)))
  return .t.

function Get_Radio
  w_OPERA1 = iif(r_OPERA1=1,"=",;
    iif(r_OPERA1=2,">",;
    iif(r_OPERA1=3,"<",;
    iif(r_OPERA1=4,">=",;
    iif(r_OPERA1=5,"<=",;
    iif(r_OPERA1=6,"#",;
    iif(r_OPERA1=7,"LI",;
    iif(r_OPERA1=8,"IN",;
    iif(r_OPERA1=9,"EM",;
    iif(r_OPERA1=10,"!E",;
    space(2)))))))))))
  w_CONG1 = iif(r_CONG1=1,"",;
    iif(r_CONG1=2,".AND.",;
    iif(r_CONG1=3,".OR.",;
    "")))
  w_OPERA2 = iif(r_OPERA2=1,"=",;
    iif(r_OPERA2=2,">",;
    iif(r_OPERA2=3,"<",;
    iif(r_OPERA2=4,">=",;
    iif(r_OPERA2=5,"<=",;
    iif(r_OPERA2=6,"#",;
    iif(r_OPERA2=7,"LI",;
    iif(r_OPERA2=8,"IN",;
    iif(r_OPERA2=9,"EM",;
    iif(r_OPERA2=10,"!E",;
    space(2)))))))))))
  w_CONG2 = iif(r_CONG2=1,"",;
    iif(r_CONG2=2,".AND.",;
    iif(r_CONG2=3,".OR.",;
    "")))
  w_OPERA3 = iif(r_OPERA3=1,"=",;
    iif(r_OPERA3=2,">",;
    iif(r_OPERA3=3,"<",;
    iif(r_OPERA3=4,">=",;
    iif(r_OPERA3=5,"<=",;
    iif(r_OPERA3=6,"#",;
    iif(r_OPERA3=7,"LI",;
    iif(r_OPERA3=8,"IN",;
    iif(r_OPERA3=9,"EM",;
    iif(r_OPERA3=10,"!E",;
    space(2)))))))))))
  w_CONG3 = iif(r_CONG3=1,"",;
    iif(r_CONG3=2,".AND.",;
    iif(r_CONG3=3,".OR.",;
    "")))
  w_OPERA4 = iif(r_OPERA4=1,"=",;
    iif(r_OPERA4=2,">",;
    iif(r_OPERA4=3,"<",;
    iif(r_OPERA4=4,">=",;
    iif(r_OPERA4=5,"<=",;
    iif(r_OPERA4=6,"#",;
    iif(r_OPERA4=7,"LI",;
    iif(r_OPERA4=8,"IN",;
    iif(r_OPERA4=9,"EM",;
    iif(r_OPERA4=10,"!E",;
    space(2)))))))))))
  w_CONG4 = iif(r_CONG4=1,"",;
    iif(r_CONG4=2,".AND.",;
    iif(r_CONG4=3,".OR.",;
    "")))
  w_OPERA5 = iif(r_OPERA5=1,"=",;
    iif(r_OPERA5=2,">",;
    iif(r_OPERA5=3,"<",;
    iif(r_OPERA5=4,">=",;
    iif(r_OPERA5=5,"<=",;
    iif(r_OPERA5=6,"#",;
    iif(r_OPERA5=7,"LI",;
    iif(r_OPERA5=8,"IN",;
    iif(r_OPERA5=9,"EM",;
    iif(r_OPERA5=10,"!E",;
    space(2)))))))))))
  w_INDSTA = iif(r_INDSTA=1,'R',;
    iif(r_INDSTA=2,'D',;
    iif(r_INDSTA=3,'C',;
    space(1))))
  w_ORDINE = iif(r_ORDINE=1,'C',;
    iif(r_ORDINE=2,'R',;
    iif(r_ORDINE=3,'P',;
    space(1))))
  return .t.

function at_x
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(6)
  else
    i_pos = i_pos / fontmetric(6,i_fnt,i_h,i_s)
  endif
  return i_pos

function at_y
  parameters i_pos, i_fnt, i_h, i_s
  if parameters()=1 .or. empty(i_fnt)
    i_pos = i_pos / fontmetric(1)
  else
    i_pos = i_pos / fontmetric(1,i_fnt,i_h,i_s)
  endif
  return i_pos

function F_Check
  parameter i_chk, i_obbl, i_var, i_value, i_msg
  i_accpt = i_chk .and. (.not. i_obbl .or. &i_var<>i_value)
  if .not. i_accpt
    if wontop()<>'BUTTONS'
      _curobj = _curobj
    endif
    if .not.("|"+i_function+"|"$"|Zoom|Prior|Next|")
      do cplu_erm with iif(empty(i_msg),iif(.not.i_chk,w_t_mseerr,w_t_mseobl),i_msg)
    endif
    &i_var = i_value
    if i_function = "Save"
      i_function = ""
    endif
  endif
  return .t.

procedure F_ChkAutoLock
  private i_rsp
  i_rsp = .t.
  return i_rsp

procedure Paint_Pag
  if i_pag>1
    i_pag = 1
    do F_Paint with 0
  else
    do F_Paint with 1
  endif
  return

procedure cplu_pn
  if i_function="Next"
    if .not. eof()
      skip
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    else
      do cplu_erm with w_t_msqefl
      i_loaded = .f.
      i_docreco = 0
    endif
  else
    if .not. bof()
      skip -1
    endif
    if .not. bof()
      i_loaded = .t.
      i_docreco = recno()
    else
      do cplu_erm with w_t_msqsfl
      if eof()
        i_loaded = .f.
        i_docreco = 0
      else
        i_loaded = .t.
        i_docreco = recno()
      endif
    endif
  endif
  do F_Read
  do F_Paint with 1
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  return

procedure f_r
  #if left(version(),13)="Visual FoxPro"
  _curobj = _curobj
  #endif
  if .not. found()
    do cplu_erm with w_t_msmnr
    i_loaded = .f.
    i_docreco = 0
  else
    i_docreco = recno()
    i_loaded = .t.
    do F_Read
    do F_Paint with 1
  endif
  * --- FP3
  #if left(version(),13)="Visual FoxPro"
    oCPToolBar.b2.enabled = i_loaded
    oCPToolBar.b5.enabled = i_loaded
  #endif
  * ---
  clear read
  return

procedure cplu_3d
  parameter i_y,i_x,i_h,i_w,rilievo,fontn,fontp,fonts
  private i_color1,i_color2,i_ww,i_hh,i_olderror
  if parameters()>4 .and. rilievo
    i_color2 =  "rgb(92,92,92,92,92,92)"
    i_color1 =  "rgb(255,255,255,255,255,255)"
  else
    i_color1 =  "rgb(92,92,92,92,92,92)"
    i_color2 =  "rgb(255,255,255,255,255,255)"
  endif
  if parameters()>5
    i_h = i_h*fontmetric(1,fontn,fontp,fonts)/fontmetric(1)
    i_w = i_w*fontmetric(6,fontn,fontp,fonts)/fontmetric(6)
  endif
  i_olderror=on('ERROR')
  on error =.f.
  i_hh = 1/fontmetric(1)
  i_ww = 1/fontmetric(6)
  @ i_y-i_hh,i_x-i_ww     to i_y-i_hh,i_x+i_w+i_ww pen 1 color (i_color1)
  @ i_y-i_hh,i_x-i_ww     to i_y+i_h+i_hh,i_x-i_ww pen 1 color (i_color1)
  @ i_y+i_h+i_hh,i_x-i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  @ i_y-i_hh,i_x+i_w+i_ww to i_y+i_h+i_hh,i_x+i_w+i_ww pen 1 color (i_color2)
  on error &i_olderror
  return

function cplu_tag
  param p
  i_pag=p
  i_campo = i_nbtntbar+1
  i_function="Repaint"
  return(.t.)

procedure gettab
  param wh,ntab
  private TABSZ,i,cwh,cntab,ci
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ci=alltrim(str(i))
    @ 0.4,TABSZ*(i-1)+1 get i_button size 1,TABSZ-2 pict "@*IT" valid cplu_tag(&ci)
  next
  return

procedure paintcurrtab
  param wh,ntab,ct
  private TABSZ
  TABSZ=min(int(wh/ntab),20)
  ct=ct-1
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  @ 1.5,ct*TABSZ to 1.5,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  @ 1.6,ct*TABSZ to 1.6,ct*TABSZ+TABSZ-0.2 color rgb(192,192,192)
  return

procedure painttab
  param wh,ntab
  private i,TABSZ
  TABSZ=min(int(wh/ntab),20)
  @ 1.5,0 to 1.5,wh color rgb(64,64,64)
  @ 1.6,0 to 1.6,wh color rgb(255,255,255)
  for i=1 to ntab
    * --- linea orizzontale
    @ 0,(i-1)*TABSZ to 0,i*TABSZ-0.5 color rgb(255,255,255)
    * --- linee vericali
    @ 0,(i-1)*TABSZ to 1.5,(i-1)*TABSZ color rgb(255,255,255)
    @ 0.1,i*TABSZ-0.4 to 1.5,i*TABSZ-0.4
  next
  return

procedure painttabtitle
  param wh,ntab,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10
  private TABSZ,i,ii
  TABSZ=min(int(wh/ntab),20)
  for i=1 to ntab
    ii=alltrim(str(i))
    @ 0.3,TABSZ*(i-1)+1 say t&ii size 1,TABSZ-2 pict "@I"
  next
  return

* --- Area Manuale = Functions & Procedures
* --- gast_sel
PROCEDURE VerificaSQL
w_FILTRO1 = DecoSQL(w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD3,w_OPERA3,w_CONFR3,w_CONG3)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD4,w_OPERA4,w_CONFR4,w_CONG4)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD5,w_OPERA5,w_CONFR5,"")
w_FILTRO2 = ".T."
w_FILTRO3 = ".T."
w_FILTRO4 = ".T."
*
do CPLU_MES with "Verifica selezioni in corso . . . Attendere!"
* Creo cursore temporaneo
do CPI_QRY with "QUERY\GAST3SR1.VQR","__TMP__"
if used("__TMP__")
   select __TMP__
   use
   *
   do CPLU_ERM with "Verifica effettuata con successo"
endif
RETURN

FUNCTION DecoSQL()
PARAMETER p_FLD,p_OPZ,p_CFR,p_CON
private w_SQL
w_SQL = ""
p_FLD = Alltrim(p_FLD)
p_CFR = Alltrim(p_CFR)
do case
case p_OPZ=="EM"
   w_SQL = "empty("+p_FLD+")"+p_CFR+p_CON
case p_OPZ=="!E"
   w_SQL = "!empty("+p_FLD+")"+p_CFR+p_CON
case p_OPZ=="LI"
   w_SQL = p_FLD+" LIKE "+p_CFR+p_CON
case p_OPZ=="IN"
   w_SQL = p_FLD+" INLIST("+p_CFR+")"+p_CON
otherwise
   w_SQL = p_FLD+p_OPZ+p_CFR+p_CON
endcase
RETURN (Alltrim(Upper(w_SQL)))

PROCEDURE StampaSQL
w_FILTRO1 = DecoSQL(w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD3,w_OPERA3,w_CONFR3,w_CONG3)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD4,w_OPERA4,w_CONFR4,w_CONG4)
w_FILTRO1 = w_FILTRO1 + DecoSQL(w_FIELD5,w_OPERA5,w_CONFR5,"")
w_FILTRO2 = ".T."
w_FILTRO3 = ".T."
w_FILTRO4 = ".T."
*
do CPLU_ERM with "Impostazioni filtri:"+chr(13)+"1["+w_FILTRO1+"]"+chr(13)+"2["+w_FILTRO2+"]"+chr(13)+"3["+w_FILTRO3+"]"+chr(13)+"4["+w_FILTRO4+"]"
RETURN

PROCEDURE SvuotaFiltri
store "" to w_FIELD1,w_OPERA1,w_CONFR1,w_CONG1
store "" to w_FIELD2,w_OPERA2,w_CONFR2,w_CONG2
store "" to w_FIELD3,w_OPERA3,w_CONFR3,w_CONG3
store "" to w_FIELD4,w_OPERA4,w_CONFR4,w_CONG4
store "" to w_FIELD5,w_OPERA5,w_CONFR5
store "" to w_FILTRO1, w_FILTRO2, w_FILTRO3, w_FILTRO4
RETURN
* --- Fine Area Manuale
